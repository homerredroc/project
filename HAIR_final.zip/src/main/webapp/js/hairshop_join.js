
	/*아이디 중복검사*/
	function idCheck(){
	var hairshop_id = document.all.hairshop_id.value;
	var idCheck = /[a-zA-Z0-9]/;
	
	if(hairshop_id.length == 0 || hairshop_id == null){
		document.getElementById('div_hairshop_id').innerHTML='아이디를 입력 해주세요';
		document.getElementById('div_hairshop_id').style.color='red';
		
		validation[0] = 0;
	}
	if(hairshop_id.length >= 1){
		if(idCheck.test(hairshop_id) == false){
			document.getElementById('div_hairshop_id').innerHTML='한글 및 특수기호는 사용할 수 없습니다.';
			document.getElementById('div_hairshop_id').style.color='red';
			validation[0] = 0;
		}else if(hairshop_id.length > 5){
			sendRequest('idCheck.do','id='+hairshop_id,idCheck_Result,'POST');
		}else if(hairshop_id.length < 6){
			document.getElementById('div_hairshop_id').innerHTML='6글자 이상 입력 해주세요.';
			document.getElementById('div_hairshop_id').style.color='red';
			validation[0] = 0;
		}
	}
}

	function idCheck_Result(){
		if(XHR.readyState == 4){
			if(XHR.status == 200){
				var idck = XHR.responseText;
				if(idck == 0){
					document.getElementById('div_hairshop_id').innerHTML = '사용 가능한 ID 입니다.';
					document.getElementById('div_hairshop_id').style.color='green';
					validation[0] = 1;
				}else if(idck == 1){
					document.getElementById('div_hairshop_id').innerHTML = '사용 불가능한 ID 입니다.';
					document.getElementById('div_hairshop_id').style.color='red';
					validation[0] = 0;
				}
			}
		}
	}
	
	/*패스워드 중복 검사*/
	function pwdCheck(){
		var hairshop_pwd = document.all.hairshop_pwd.value;
		var hairshop_pwd2 = document.all.hairshop_pwd2.value;
		
		if(hairshop_pwd == null || hairshop_pwd.length == 0){
			document.getElementById('div_hairshop_pwd').innerHTML = '비밀번호를 입력 해주세요';
			validation[1] = 0;
			
			}else if(hairshop_pwd.length >= 1 && hairshop_pwd.length < 6){
				document.getElementById('div_hairshop_pwd').style.color = 'red';
				document.getElementById('div_hairshop_pwd').innerHTML = '비밀번호는 6자리 이상 입력 해주세요.';
				validation[1] = 0;
			}else{
				document.getElementById('div_hairshop_pwd').innerHTML ='';
			}
		
		if(hairshop_pwd2.length >= 1){
			if(hairshop_pwd != hairshop_pwd2){
				document.getElementById('div_hairshop_pwd').style.color = 'red';
				document.getElementById('div_hairshop_pwd').innerHTML = '비밀번호가 동일하지 않습니다.';
				validation[1] = 0;
				if(hairshop_pwd.length >= 1 && hairshop_pwd.length < 6){
					document.getElementById('div_hairshop_pwd').style.color = 'red';
					document.getElementById('div_hairshop_pwd').innerHTML = '비밀번호는 6자리 이상 입력 해주세요.';
					validation[1] = 0;
				}
			}else{
				document.getElementById('div_hairshop_pwd').style.color = 'green';
				document.getElementById('div_hairshop_pwd').innerHTML = '비밀번호가 동일합니다.';
				validation[1] = 1;
			}
		}
		if(hairshop_pwd.length >= 1 && hairshop_pwd2.length >= 1 && hairshop_pwd.length < 6 && hairshop_pwd2.length < 6){
			document.getElementById('div_hairshop_pwd').style.color = 'red';
			document.getElementById('div_hairshop_pwd').innerHTML = '비밀번호는 6자리 이상 입력 해주세요.';
			validation[1] = 0;
		}
	}
	
	/*상호명 */
	function nameCheck(obj){
		var hairshop_name = obj.value;
		var nameck = /[^a-zA-Z가-힣ㄱ-ㅎㅏ-ㅣ!*@#$%&~`?<>,.=+-_:;"''"]/gi;

		if(hairshop_name == null || hairshop_name.length == 0){
			document.getElementById('div_hairshop_name').innerHTML = '상호명을 입력 해주세요.';
			document.getElementById('div_hairshop_name').style.color = 'red';
				validation[2] = 0;
			
		}
		
		if(hairshop_name.length >= 1){
			if(nameck.test(hairshop_name) == false){
				document.getElementById('div_hairshop_name').innerHTML = '';				
					validation[2] = 1;
			}else{
				document.getElementById('div_hairshop_name').innerHTML = '올바르지 못한 입력방식 입니다';
				document.getElementById('div_hairshop_name').style.color = 'red';
					validation[2] = 0;
			}
		}
		
	}
	
	/*대표자성함*/ 
	function ceoCheck(obj){
		var hairshop_ceo = obj.value;
		var ceock = /[^a-zA-Z가-힣ㄱ-ㅎㅏ-ㅣ]/gi;
		
		if(hairshop_ceo == null || hairshop_ceo.length == 0){
			document.getElementById('div_hairshop_ceo').innerHTML = '대표자명을 입력 해주세요';
			document.getElementById('div_hairshop_ceo').style.color = 'red';
				validation[3] = 0;
		}
		if(hairshop_ceo.length >= 1){
			if(ceock.test(hairshop_ceo) == false){
				document.getElementById('div_hairshop_ceo').innerHTML = '';
					validation[3] = 1;
			}else{
				document.getElementById('div_hairshop_ceo').innerHTML = '올바르지 못한 입력방식 입니다';
				document.getElementById('div_hairshop_ceo').style.color = 'red';
					validation[3] = 0;
			}
		}
	}
	
	/*이메일*/
	function emailCheck(obj){
		var hairshop_email = obj.value;
		var emailCheck = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/;       
		
		if(hairshop_email.length == 0 || hairshop_email == null){
			document.getElementById('div_hairshop_email').innerHTML = '이메일을 입력 해주세요';
			document.getElementById('div_hairshop_email').style.color = 'red';
			validation[4] = 0;
		}else{
			document.getElementById('div_hairshop_email').innerHTML = '';
			validation[4] = 0;
		}
		
		if(hairshop_email.length >= 1){
			if(emailCheck.test(hairshop_email) == false){
				document.getElementById('div_hairshop_email').style.color = 'red';
				document.getElementById('div_hairshop_email').innerHTML = "정확한 메일주소를 입력 해주세요.";
				validation[4] = 0;
			}else{
				document.getElementById('div_hairshop_email').innerHTML = '';
				validation[4] = 1;
				
			}
 		}
	}
	
	/*이메일인증번호 체크*/
	function email_Cf_Check(){
		var hairshop_email_Cf_id = document.getElementById('hairshop_email_Cf_id').value;
		if(hairshop_email_Cf_id == ranValue){
			validation[12] = 1;
			document.getElementById('div_hairshop_email_Cf').style.color = 'green';
			document.getElementById('div_hairshop_email_Cf').innerHTML = '올바른 인증번호 입니다.'
		}else{
			validation[12] = 0;
			document.getElementById('div_hairshop_email_Cf').style.color = 'red';
			document.getElementById('div_hairshop_email_Cf').innerHTML = '인증번호가 틀렸습니다.'
		}
	}
	
	/*기업정보*/
	function infoCheck(obj){
		var hairshop_info = obj.value;
		if(hairshop_info.length == 0 || hairshop_info == null){
			validation[5] = 0;
		}else{
			validation[5] = 1;
		}
	}
	
	/*사업자번호*/
	function numberCheck(obj){ 
		var hairshop_number = obj.value;
		var numck1 = hairshop_number.replace(/^(\d{3})(\d{2})(\d{5})$/, "$1-$2-$3");
		var numck2 = /^(\d{3})-(\d{2})-(\d{5})$/;
		var numck3 = hairshop_number.replace(/^(\d{3})-(\d{2})(\d{5})$/, "$1-$2-$3");
		var numck4 = /^(\d{3})-(\d{2})(\d{5})$/;
		
		hairshop_number = numck1;
		
		if (hairshop_number.length >= 1) {
			if (numck2.test(hairshop_number) == true) {
				document.getElementById('hairshop_number_id').value = hairshop_number;
				document.getElementById('div_hairshop_number').innerHTML = '';
				validation[6] = 1;
			} else if (numck2.test(hairshop_number) == false) {
				document.getElementById('div_hairshop_number').innerHTML = "올바른 번호를 입력 해주세요.";
				document.getElementById('div_hairshop_number').style.color = 'red';
				validation[6] = 0;
				if(hairshop_number.indexOf('-') == 3){
					if(hairshop_number.length >= 3 || numck4.test(hairshop_number) == true){
						hairshop_number = numck3;
						document.getElementById('hairshop_number_id').value = hairshop_number;
						document.getElementById('div_hairshop_number').innerHTML = "올바른 번호를 입력 해주세요.";
						document.getElementById('div_hairshop_number').style.color = 'red';
						validation[6] = 0;
					}
				}
			}
			
		} else if (hairshop_number.length == 0 || hairshop_number == null) {
			document.getElementById('div_hairshop_number').style.color = 'red';
			document.getElementById('div_hairshop_number').innerHTML = "사업자번호를 입력하세요";
			validation[6] = 0;
		}
		
	}
	
	/*기업주소*/
	function jusoCheck(obj){
		var hairshop_addr = obj.value;
		if(hairshop_addr == null || hairshop_addr.length == 0){
			validation[7] = 0;
		}else{
			validation[7] = 1;
		}
	}
	function telCheck(str, field){
		  var str;
		  str = checkDigit(str);
		  len = str.length;
		  
		  		if(len==8){
			   if(str.substring(0,2)==02){
			    error_numbr(str, field);
			   }else{
			    field.value  = phone_format(1,str);
			   }   
			  }else if(len==9){
				  
			   if(str.substring(0,2)==02){
			    field.value = phone_format(2,str);
			   }else{
			    error_numbr(str, field);
			   }
			  }else if(len==10){
				  
			   if(str.substring(0,2)==02){
			    field.value = phone_format(2,str);
			   }else{
			    field.value = phone_format(3,str);
			   }
			  }else if(len==11){
				  
			   if(str.substring(0,2)==02){
			    error_numbr(str, field);
			   }else{
			    field.value  = phone_format(3,str);
			   }
			  }else{
			   error_numbr(str, field);
			  }
			 }

	function checkDigit(num){
		  var Digit = "1234567890";
		  var string = num;
		  var len = string.length
		  var retVal = "";
		  
		  for (i = 0; i < len; i++){
		   if (Digit.indexOf(string.substring(i, i+1)) >= 0){
		    retVal = retVal + string.substring(i, i+1);
		   }
		  }
		  return retVal;
		 }
		 function phone_format(type, num){
		  if(type==1){
			  validation[8] = 1;
			  document.getElementById('div_hairshop_tel').innerHTML = '';
			  return num.replace(/([0-9]{4})([0-9]{4})/,"$1-$2");
		  }else if(type==2){
			  validation[8] = 1;
			  document.getElementById('div_hairshop_tel').innerHTML = '';
			  return num.replace(/([0-9]{2})([0-9]+)([0-9]{4})/,"$1-$2-$3");
		  }else{
			  validation[8] = 1;
			  document.getElementById('div_hairshop_tel').innerHTML = '';
			  return num.replace(/(^01.{1}|[0-9]{3})([0-9]+)([0-9]{4})/,"$1-$2-$3");
		  }
		 }

		 function error_numbr(str, field){
			  validation[8] = 0;
			  document.getElementById('div_hairshop_tel').innerHTML = '잘못된 입력 방식입니다.';
			  document.getElementById('div_hairshop_tel').style.color = 'red';
			  
			  return;
			 }
		 
	/*기업추가정보*/
	function addinfoCheck(){
		var hairshop_addinfo = document.getElementsByName('hairshop_addinfo');
		
		for(var i=0; i<hairshop_addinfo.length; i++){
			if(hairshop_addinfo[i].checked == false){
				validation[9] = 0; 
			}else if(hairshop_addinfo[i].checked == true){
				validation[9] = 1; 
				return;
			}
		}
	}
	
	/*오픈시간*/
	function openCheck(obj){ 
		var hairshop_open = obj.value;
		var opck1 = hairshop_open.replace(/^([01][0-9]|2[0-3])([012345][0-9])([01][0-9]|2[0-3])([012345][0-9])$/, "$1:$2-$3:$4");
		var opck2 = /^([01][0-9]|2[0-3]):([012345][0-9])-([01][0-9]|2[0-3]):([012345][0-9])$/; 
		
		var opck3 = hairshop_open.replace(/^([01][0-9]|2[0-3]):([012345][0-9])([01][0-9]|2[0-3])([012345][0-9])$/, "$1:$2-$3:$4");
		var opck4 = /^([01][0-9]|2[0-3]):([012345][0-9])([01][0-9]|2[0-3])([012345][0-9])$/;
		
		var opck5 = hairshop_open.replace(/^([01][0-9]|2[0-3]):([012345][0-9])-([01][0-9]|2[0-3])([012345][0-9])$/, "$1:$2-$3:$4");
		var opck6 = /^([01][0-9]|2[0-3]):([012345][0-9])-([01][0-9]|2[0-3])([012345][0-9])$/; 
		 
		var opck7 = hairshop_open.replace(/^([01][0-9]|2[0-3]):([012345][0-9])-([01][0-9]|2[0-3]):([012345][0-9])$/, "$1:$2-$3:$4");
		var opck8 = /^([01][0-9]|2[0-3]):([012345][0-9])-([012345][0-9]):([012345][0-9])$/;
		
		hairshop_open = opck1;
		
		if(hairshop_open.length >= 1){
			if(opck2.test(hairshop_open) == true){
				document.getElementById('hairshop_open_id').value = hairshop_open;
				document.getElementById('div_hairshop_open').innerHTML = '';
				validation[10] = 1;
			}else if(opck2.test(hairshop_open) == false){
				document.getElementById('div_hairshop_open').innerHTML = "올바르게 입력 해주세요"
				document.getElementById('div_hairshop_open').style.color = 'red';
				validation[10] = 0;
				
				if(hairshop_open.indexOf(':') == 2){
					if(hairshop_open.length >= 2 && opck4.test(hairshop_open) == true){
						hairshop_open = opck3;
						document.getElementById('hairshop_open_id').value = hairshop_open;
						document.getElementById('div_hairshop_open').innerHTML = '';
						validation[10] = 1;
					}else if(hairshop_open.length >= 2 && opck6.test(hairshop_open) == true){
						hairshop_open = opck5;
						document.getElementById('hairshop_open_id').value = hairshop_open;
						document.getElementById('div_hairshop_open').innerHTML = '';
						validation[10] = 1;
					}	
				}
			}
		}
	}
	
	/*쉬는날 체크*/
	function offCheck(){
		var hairshop_off = document.getElementsByName('hairshop_off');
		
		for(var i=0; i<hairshop_off.length; i++){
			if(hairshop_off[i].checked == false){
				validation[11] = 0;
			}else if(hairshop_off[i].checked == true){
				validation[11] = 1;
				return;
			}
		}
	}
	/*자동삭제 관련 코드*/
	/*아이디는 영어 및 숫자만 가능*/
	function onlyEngNum(obj) { 
	    var val = obj.value;
	    var pattern = /[^a-zA-Z0-9]/gi; 
	    if(pattern.test(val)){ 
	        obj.value = val.replace(pattern,""); 
	    } 
	}
	
	 /*대표자성함은 한글 및 영어만 가능*/
	function onlyKorEng(obj){
		var val = obj.value;
		var pattern = /[^a-zA-Z가-힣ㄱ-ㅎㅏ-ㅣ]/gi;
		if(pattern.test(val)){ 
	        obj.value = val.replace(pattern,""); 
	    } 
	}
	
	 /*영어,숫자,문자,특수기호 가능  제외: ()[]{}는 안됨.*/
	function allOk(obj){
		var val = obj.value;
		var pattern = /[^a-zA-Z가-힣ㄱ-ㅎㅏ-ㅣ!*@#$%&~`?<>,.=+-_:;"''"]/gi;
		if(pattern.test(val)){ 
	        obj.value = val.replace(pattern,""); 
	    } 
	}
	
	/*이메일 체크*/
	function hairshop_email_Ok(obj){
		var val = obj.value;
		var pattern = /[^a-zA-Z@.0-9]/gi;
		if(pattern.test(val)){ 
	        obj.value = val.replace(pattern,""); 
	    } 
	}
	
	/*상호명,대표자성함 체크*/
	function hairshop_NumTel_Ok(obj){
		var val = obj.value;
		var pattern = /[^0-9-]/gi;
		if(pattern.test(val)){ 
	        obj.value = val.replace(pattern,""); 
	    } 
	}
	
	/*오픈체크*/
	function hairshop_open_Ok(obj){
		var val = obj.value;
		var pattern = /[^0-9-:]/gi;
		if(pattern.test(val)){ 
	        obj.value = val.replace(pattern,""); 
	    } 
	}
	
	/*스페이스 하면 자동 삭제*/
	function noSpace(obj){
	    var space=/\s/;
	    if(space.exec(obj.value)){
	       obj.focus();
	       obj.value=obj.value.replace(' ','');
	       return false;
	    }
	 }
	
	
	
	
		
		
		
		