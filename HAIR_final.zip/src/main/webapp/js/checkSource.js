//아이디 유효성검사

		
//비밀번호 유효성 검사
	function pwdcheck() {
		
	      var pwd1 = document.all.member_pwd.value; 
	      var pwd2 = document.all.member_pwd_check.value;
	      var pattern = /[^a-zA-Z가-힣ㄱ-ㅎㅏ-ㅣ!*@#$%&~`?<>,.=+-_:;"''"]/gi;
	      
	      if(pwd1 == ''|| pwd1.length == 0){
	          document.getElementById('pwd_msg').innerHTML = '비밀번호를 입력하세요.';
	          validation[2] = 0; //return false;
		  }else{
				  if(pattern.test(pwd1)){ 
			    	  document.all.member_pwd.value = pwd1.replace(pattern,""); 
			    	  document.getElementById('pwd_msg').innerHTML = '(),[],{} 사용불가.';		
			    	  
				  }
				 
				  if(pwd1.length < 6){
					   document.getElementById('pwd_msg').innerHTML = '비밀번호는 6자리 이상 기입하세요';
					   document.getElementById('pwd_msg').style.color = 'red';
					   validation[2] = 0;  //return false;
				  }else{
				       document.getElementById('pwd_msg').innerHTML = '';
				  }
		  }
		  	      
	      if(pwd2 == '' || pwd2.length == 0){
	    	  validation[2] = 0;  //return false;
	      }else{
			      if(pwd1!=pwd2){
			          document.getElementById('pwd_msg').innerHTML = '비밀번호가 동일하지 않습니다.';
			          document.getElementById('pwd_msg').style.color = 'red';
			          validation[2] = 0;  //return false;
			      }else{
			    	  document.getElementById('pwd_msg').innerHTML = '비밀번호가 동일합니다.';
			    	  document.getElementById('pwd_msg').style.color = 'blue';
			    	  validation[2] = 1; //return true;
			      }
	      }	      
	 }
	
//이름 유효성검사
	function nameck(obj){
		   var member_name = obj.value;
		   var pattern = /[^a-zA-Z가-힣ㄱ-ㅎㅏ-ㅣ]/gi;
		   
		   if(member_name == '' || member_name.length == 0){
		    	document.getElementById('name_msg').innerHTML='이름을 입력하세요.';
		    	document.getElementById('name_msg').style.color='red';
		    	 validation[3] = 0; //return false;
	    	}else {
	    		if(pattern.test(member_name)){ 	        
			        document.getElementById('name_msg').innerHTML='특수문자 사용불가.';
		            document.getElementById('name_msg').style.color='red';
		            obj.value = member_name.replace(pattern,""); 
		            validation[3] = 0; //return false;
			    }else{
			    	document.getElementById('name_msg').innerHTML='';
			    	 validation[3] = 1; //return true;
			    }
	    	}
		}

//성별 체크여부 검사
	 function sexck(obj){

		 var radioBtn =  obj.value
		 for(var i=0; i<radioBtn.length; i++){
			 if(radioBtn[i].checked == false){
				 validation[4] = 0; //return false;
			 }else{
				 validation[4] = 1; //return true;
			 }
		 
		 }			 
	}

//생년월일 유효성검사
	function birthcheck(obj){
		var pattern = /[^0-9.]/gi;
		var member_birth =  obj.value;
		var birthck1 = member_birth.replace(/^(19[0-9]{2}|20[0-9]{2})(0[1-9]|1[0-2])(0[1-9]|[1,2][0-9]|3[0,1])$/, "$1.$2.$3");
		var birthck2 = /^(19[0-9]{2}|20[0-9]{2}).(0[1-9]|1[0-2]).(0[1-9]|[1,2][0-9]|3[0,1])$/ ;
		var birthck3 = member_birth.replace(/^(19[0-9]{2}|20[0-9]{2}).(0[1-9]|1[0-2])(0[1-9]|[1,2][0-9]|3[0,1])$/, "$1.$2.$3");

		 member_birth = birthck1; 
		 
			 if(pattern.test(member_birth)){ 
			        obj.value = member_birth.replace(pattern,""); } 
			 
			  if(member_birth.length>=1){	              
		           if(birthck2.test(member_birth) == true){       	   
		                document.getElementById('birth').value=member_birth;
		                document.getElementById('birth_msg').innerHTML='생년월일OK';
		                document.getElementById('birth_msg').style.color = 'blue';	
		                validation[5] = 1; //return true;
		           }else if(birthck2.test(member_birth) == false){	   	        	   
		               	document.getElementById('birth_msg').innerHTML='숫자 6자리를 입력해주세요.';      
			            document.getElementById('birth_msg').style.color = 'red';
			            validation[5] = 0; //return false;
			               if(member_birth.indexOf('.')==2&&member_birth.length>=7){
			            	   member_birth = birthck3;
		                		document.getElementById('birth').value=member_birth
				                document.getElementById('birth_msg').innerHTML='숫자 6자리를 입력해주세요.';
		                		validation[5] = 0; //return false;
		                		if(birthck2.test(member_birth) == true){
		                			document.getElementById('birth_msg').innerHTML='생년월일OK';
		     		                document.getElementById('birth_msg').style.color = 'blue'
		     		                validation[5] = 1; //return true;
		                		}
			                }	               	 
		           }
			  }else if(member_birth == '' || member_birth.length == 0){
		         document.getElementById('birth_msg').innerHTML='생년월일을 입력하세요.';
	             document.getElementById('birth_msg').style.color = 'green';
	             validation[5] = 0; //return false;
			  }
	}
	  
//주소 유효성검사
  function addrcheck()	{
		  
		  var postCode = document.all.postcode.value;
		  var address = document.all.address.value;
		  var address2 = document.all.address2.value; 
		  //window.alert(postCode+'+'+address+'+'+address2);
		   
		  if(postCode != '' && address != '' && address2 != ''){
			  //window.alert('ok~~~~');
			  validation[8] = 1;
		  }else{
			  //window.alert('null');
			  validation[8] = 0;
		  } 
	  }
	  
	  
//전화번호 유효성검사 (회원가입 시)
	  function telcheck(obj) {
		  var pattern = /[^0-9-]/gi;
		  var member_tel = obj.value;
		  var telck1 = member_tel.replace(/^(010)(\d{4})(\d{4})$/, "$1-$2-$3");
		  var telck2 = /^(010)-(\d{4})-(\d{4})$/ ;
		  var telck3 = member_tel.replace(/^(010)-(\d{4})(\d{4})$/, "$1-$2-$3");
		   
			member_tel = telck1; 
		  
			 if(pattern.test(member_tel)){ 
			        obj.value = member_tel.replace(pattern,""); } 
			 
			
		  if(member_tel.length>=1){	              
	           if(telck2.test(member_tel) == true){       	   
	                document.getElementById('tel').value=member_tel;
	                document.getElementById('tel_msg').innerHTML='휴대폰번호OK';
	                document.getElementById('tel_msg').style.color = 'blue';
	                validation[9] = 1; //return true;
	           }else if(telck2.test(member_tel) == false  ){	   	        	   
	               	document.getElementById('tel_msg').innerHTML='숫자 11자리를 입력해주세요.';      
		            document.getElementById('tel_msg').style.color = 'red'; 
		            validation[9] = 0; //return false;
		               if(member_tel.match(/-/g)=='-'){ 
		                		member_tel = telck3;
		                		document.getElementById('tel').value=member_tel;
		                		if(telck2.test(member_tel) == true){
		                			document.getElementById('tel').value=member_tel;
		                			document.getElementById('tel_msg').innerHTML='휴대폰번호OK';
		        	                document.getElementById('tel_msg').style.color = 'blue';
		        	                validation[9] = 1; //return true;
		                		}
		                }	               	 
	           }
		  }else if(member_tel == ''|| member_tel.length == 0){
	         document.getElementById('tel_msg').innerHTML='휴대폰번호를 입력하세요.';
            document.getElementById('tel_msg').style.color = 'green';
            validation[9] = 0; //return false;
		  }
} 
	  
//전화번호 유효성검사(정보수정 시 )
	  function telcheck2(obj){
			var pattern = /[^0-9-]/gi;
			  var member_tel = obj.value;
			  var telck1 = member_tel.replace(/^(010)(\d{4})(\d{4})$/, "$1-$2-$3");
			  var telck2 = /^(010)-(\d{4})-(\d{4})$/ ;
			  var telck3 = member_tel.replace(/^(010)-(\d{4})(\d{4})$/, "$1-$2-$3");
			   
				member_tel = telck1; 
			  
				 if(pattern.test(member_tel)){ 
				        obj.value = member_tel.replace(pattern,""); } 
				 
				
			  if(member_tel.length>=1){	              
		           if(telck2.test(member_tel) == true){       	   
		                document.getElementById('tel').value=member_tel;
		                document.getElementById('tel_msg').innerHTML='';
		                validation[9] = 1; //return true;
		           }else if(telck2.test(member_tel) == false  ){	   	        	   
		               	document.getElementById('tel_msg').innerHTML='숫자 11자리를 입력해주세요.';      
			            document.getElementById('tel_msg').style.color = 'red'; 
			            validation[9] = 0; //return false;
			               if(member_tel.match(/-/g)=='-'){ 
			                		member_tel = telck3;
			                		document.getElementById('tel').value=member_tel;
			                		if(telck2.test(member_tel) == true){
			                			document.getElementById('tel').value=member_tel;
			                			document.getElementById('tel_msg').innerHTML='';
			        	                validation[9] = 1; //return true;
			                		}
			                }	               	 
		           }
			  }else if(member_tel == ''|| member_tel.length == 0){
		         document.getElementById('tel_msg').innerHTML='휴대폰번호를 입력하세요.';
	            document.getElementById('tel_msg').style.color = 'green';
	            validation[9] = 0; //return false;
			  }
	} 
	 
	  
	  
	  
	  
	  