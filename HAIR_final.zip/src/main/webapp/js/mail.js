/* 메일함수  */
var ranValue;
var check;

function mailForm(){
	ranValue = Math.floor(Math.random() * 88888888)+111111111;
 	var hairshop_email = document.getElementById('hairshop_email_id').value;
	var param = 'tomail='+hairshop_email+'&content='+ranValue;
	var emailCheck = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/;
	
	if(emailCheck.test(hairshop_email) == false || hairshop_email.length == 0 || hairshop_email == null){
		document.getElementById('div_hairshop_email').innerHTML = '정확한 메일주소를 입력 해주세요.';
		document.getElementById('div_hairshop_email').style.color = 'red';
		check = 0;
	}else{
		check = 1;
		window.alert('입력하신 이메일로 인증번호를 전송 하였습니다.');
		sendRequest('mailSending.do',param,resultmail(),'POST');
	}
}

/*메일 콜백함수*/
function resultmail(){
	
}
