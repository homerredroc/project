/*주소 API*/
function juso() {  
	
	var juso = document.getElementById('roadAddrPart1');

	var mapContainer = document.getElementById('map'); // 지도를 표시할 div.
	mapOption = {
		center : new daum.maps.LatLng(37.49899300000001, 127.03290900000002), // 지도의 중심좌표.
		level : 2 // 지도의 확대 레벨.
	};	
	// 지도를 생성합니다.
	var map = new daum.maps.Map(mapContainer, mapOption);
	// 주소-좌표 변환 객체를 생성합니다.
	var geocoder = new daum.maps.services.Geocoder();
	// 주소로 좌표를 검색합니다.
	geocoder.addressSearch(juso.value,function(result, status) {
	// 정상적으로 검색이 완료됐으면.
	if (status === daum.maps.services.Status.OK) {
		var y_coords = result[0].y;
		var x_coords = result[0].x;
		document.getElementById('y_coords').value = y_coords;
		document.getElementById('x_coords').value = x_coords;
		
		var coords = new daum.maps.LatLng(result[0].y,result[0].x);
	// 결과값으로 받은 위치를 마커로 표시합니다.
	var marker = new daum.maps.Marker({map : map,position : coords});
	// 인포윈도우로 장소에 대한 설명을 표시합니다.
	var infowindow = new daum.maps.InfoWindow
		({content : '<div style="width:150px;text-align:center;padding:2px 0;">헤어샵위치</div>'});
			infowindow.open(map, marker);
	// 지도의 중심을 결과값으로 받은 위치로 이동시킵니다
	map.setCenter(coords);
	}});
}

/*주소검색 API*/
function goJusoApi() {

	var pop = window.open("goJusoApiPopup.do", "JAP",
			"width=570,height=420, scrollbars=yes, resizable=yes");
}

/*주소 콜백함수*/
function jusoCallBack(roadFullAddr, roadAddrPart1, addrDetail,
		roadAddrPart2, engAddr, jibunAddr, zipNo, admCd, rnMgtSn, bdMgtSn,
		detBdNmList, bdNm, bdKdcd, siNm, sggNm, emdNm, liNm, rn, udrtYn,
		buldMnnm, buldSlno, mtYn, lnbrMnnm, lnbrSlno, emdNo) {

	document.hairshop_join_form.roadAddrPart1.value = roadAddrPart1;
	document.hairshop_join_form.roadAddrPart2.value = roadAddrPart2;
	document.hairshop_join_form.addrDetail.value = addrDetail;
	document.hairshop_join_form.zipNo.value = zipNo;
}