//회원가입_주소검색 API//
	function JusoApi() {
        new daum.Postcode({
            oncomplete: function(data) {
                // 팝업에서 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.

                // 각 주소의 노출 규칙에 따라 주소를 조합한다.
                // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
                var fullAddr = ''; // 최종 주소 변수
                var extraAddr = ''; // 조합형 주소 변수

                // 사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.
                if (data.userSelectedType === 'R') { // 사용자가 도로명 주소를 선택했을 경우
                    fullAddr = data.roadAddress;

                } else { // 사용자가 지번 주소를 선택했을 경우(J)
                    fullAddr = data.jibunAddress;
                }

                // 사용자가 선택한 주소가 도로명 타입일때 조합한다.
                if(data.userSelectedType === 'R'){
                    //법정동명이 있을 경우 추가한다.
                    if(data.bname !== ''){
                        extraAddr += data.bname;
                    }
                    // 건물명이 있을 경우 추가한다.
                    if(data.buildingName !== ''){
                        extraAddr += (extraAddr !== '' ? '/ ' + data.buildingName : data.buildingName);
                    }
                    // 조합형주소의 유무에 따라 양쪽에 괄호를 추가하여 최종 주소를 만든다.
                    fullAddr += (extraAddr !== '' ? ' ('+ extraAddr +')' : '');
                }

                // 우편번호와 주소 정보를 해당 필드에 넣는다.
                document.getElementById('postcode').value = data.zonecode; //5자리 새우편번호 사용
                document.getElementById('address').value = fullAddr;

                // 커서를 상세주소 필드로 이동한다.
                document.getElementById('address2').focus();
            }
        }).open();
    }

//회원가입_인증 이메일 유효성검사&API//
	
	//이메일유효성검사,메일발송 메소드 실행
	var ranValue;
	var check;
	function mailForm(obj){
	   ranValue = Math.floor(Math.random() * 88888888)+111111111;
	   var member_email = obj.value;
	   window.alert(member_email);
	   var param = 'tomail='+member_email+'&content='+ranValue;
	   var emailCheck = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/;
	   
	   if(emailCheck.test(member_email) == false || member_email.length == 0 || member_email == null){
		   check = 0;
		   validation[6] = 0; //return false;
		   document.getElementById('email_msg').innerHTML = '메일주소를 정확히 입력 해주세요.';
	       document.getElementById('email_msg').style.color = 'red';      
	   }else{
	      check = 1;
	      validation[6] = 1; //return true;
	      if(member_email != 'emailAddr2'){
	      window.alert('입력하신 '+member_email+' 로 인증번호 발송,\n이메일을 확인해 주세요.');
		   document.getElementById('email_msg').innerHTML = '';
	      sendRequest('/hair/mailSending.do',param,resultmail(),'POST');
	   
	      
	   }
	}
	}

	//메일 콜백함수
	function resultmail(){
	}

	//인증번호 타이머_msg_time() 함수를 1초에한번씩 실행하게함
	var SetTime;
	var tid;
	
	function TimerStart() {
	   SetTime = 180;

		   if (tid != null) {
		      clearInterval(tid);
		   }
		   
		   if (check == 1) {
		      tid = setInterval('msg_time()', 1000);
		   } else if (check == 0) {
		      document.getElementById('email_check_msg').innerHTML = '';
		   }

	}
	
	//인증번호 타이머_시간을 나타냄
	function msg_time() {

	   var msg = Math.floor(SetTime / 60) + "분 " + (SetTime % 60) + "초";
	   document.getElementById('email_check_msg').innerHTML = msg;

	   SetTime--; // 1초씩 감소

	   if (SetTime < 0) {
	      clearInterval(tid); // 타이머 해제
	      ranValue = 'expiration'; //인증만료된 인증번호   
	      document.getElementById('email_check_msg').innerHTML = '인증번호가 만료되었습니다.';
	   }

	}
	
	//인증번호 일치확인
	function vfcCodeck(obj){
				
		var inputCode = obj.value;
	
		if(inputCode.length>=9 && inputCode != ranValue ){
			validation[7] = 0;
			document.getElementById('email_check_msg').innerHTML='인증번호가 일치하지 않습니다.';
	        document.getElementById('email_check_msg').style.color = 'red'; 
	        
			if(ranValue == 'expiration'){
				validation[7] = 0;
				document.getElementById('email_check_msg').innerHTML='만료된 인증번호입니다.';
		        document.getElementById('email_check_msg').style.color = 'red'; 
			}
			
		}else if(inputCode == ranValue){
			validation[7] = 1;
			document.getElementById('email_check_msg').innerHTML='인증번호가 일치합니다.';
			document.getElementById('email_check_msg').style.color = 'blue'; 
			clearInterval(tid);
			document.getElementById('email_check_msg').innerHTML='';
		}else {
			validation[7] = 0;
			document.getElementById('email_check_msg').innerHTML='인증번호를 정확히 입력하세요.';
			document.getElementById('email_check_msg').style.color = 'red';		
		}	
	}
	
