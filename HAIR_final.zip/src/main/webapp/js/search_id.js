//기업아이디찾기 유효성 검사
function search_ceo(){
      var hairshop_ceo = document.all.hairshop_ceo.value;
      
      if(hairshop_ceo.length == 0 || hairshop_ceo == null){
         validation[0] = 0;
      }else{
         validation[0] = 1;
      }
   }
   
   function search_name(){
      var hairshop_name = document.all.hairshop_name.value;
      
      if(hairshop_name.length == 0 || hairshop_name == null){
         validation[1] = 0;
      }else{
         validation[1] = 1;
      }
   }
   
   function search_email(){
      var hairshop_email = document.all.hairshop_email.value;
      
      if(hairshop_email.length == 0 || hairshop_email == null){
         validation[2] = 0;
      }else{
         validation[2] = 1;
      }
   }
   
//개인회원 아이디찾기 유효성 검사
   function search_member_name(){
	      var member_name = document.all.member_name.value;
	      
	      if(member_name.length == 0 || member_name == null){
	         validation[0] = 0;
	      }else{
	         validation[0] = 1;
	      }
	   }
	   
	   function search_member_tel(){
	      var member_tel = document.all.member_tel.value;
	      
	      if(member_tel.length == 0 || member_tel == null){
	         validation[1] = 0;
	      }else{
	         validation[1] = 1;
	      }
	   }
	   
	   function search_member_email(){
	      var member_email = document.all.member_email.value;
	      
	      if(member_email.length == 0 || member_email == null){
	         validation[2] = 0;
	      }else{
	         validation[2] = 1;
	      }
	   }