var XHR=null;

function getXHR() {
	
	if(window.ActiveXObject){
		
		return new ActiveXObject('Msxml2.XMLHTTP');
		
	}else if(window.XMLHttpRequest){
		
		return new XMLHttpRequest();
	
	}else{
		
		return null;
	}
}

function sendRequest(url,param,callBack,method) {
	
	XHR=getXHR();
	
	//메소드 전송방식의 유효성 검사
	var httpMethod=method?method:'GET'; //1차 검증 - 메소드 방식의 유무
	
	if(httpMethod!='GET' && httpMethod!='POST'){ //2차 검증 - 오타일 경우
		
		httpMethod='GET';
	}
	
	var httpParam=(param==null || param=='')?null:param; //파라미터의 유무
	var httpUrl=url;
	
	if(httpMethod=='GET' && httpParam!=null){
		
		httpUrl=httpUrl+'?'+httpParam;
	}
	
	XHR.onreadystatechange=callBack;
	XHR.open(httpMethod,httpUrl,true);
	XHR.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	XHR.send(httpMethod=='POST'?httpParam:null);
}



















