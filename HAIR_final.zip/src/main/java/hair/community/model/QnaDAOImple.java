package hair.community.model;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;

public class QnaDAOImple implements QnaDAO {

	private SqlSessionTemplate sqlMap;

	public QnaDAOImple(SqlSessionTemplate sqlMap) {
		super();
		this.sqlMap = sqlMap;
	}
	
	/**
	 * qna 본문 정보를 가져오는 메서드
	 * @param qna_idx 가져올 글의 idx
	 */	
	public QnaDTO qna_content(int qna_idx) {
		return sqlMap.selectOne("qna_content",qna_idx);
	}
	
	/**
	 * qna 글을 등록하는 메서드
	 * @param dto 해당하는 글의 정보를 담고 있는 dto
	 */	
	public int qna_write(QnaDTO dto) {
		return sqlMap.insert("qna_write", dto);
	}
	
	/**
	 * qna 글 리스트를 가져오는 메서드
	 * @param dto 해당하는 글의 정보를 담고 있는 dto
	 */	
	public List<QnaDTO> qna_list() {
		List<QnaDTO> list = sqlMap.selectList("qna_list");
		return list;
	}
	
	/**
	 * qna 글 을 삭제하는 메서드
	 * @param qna_idx 삭제할 글의 idx
	 */	
	public int qna_del(int qna_idx) {
		return sqlMap.update("qna_del",qna_idx);
	}
	
	/**
	 * qna 글 을 수정하는 메서드
	 * @param dto 수정할 글의 정보를 담고있는
	 */	
	public int qna_update(QnaDTO dto) {
		return sqlMap.update("qna_update",dto);
	}

}

