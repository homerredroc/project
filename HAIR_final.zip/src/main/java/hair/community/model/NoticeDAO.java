package hair.community.model;

import java.util.List;

public interface NoticeDAO {
	public int notice_write(NoticeDTO dto);
	public List<NoticeDTO> notice_list();
	public NoticeDTO notice_content(int notice_idx);
	public int notice_del(int notice_idx);
	public int notice_update(NoticeDTO dto);
}
