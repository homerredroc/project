package hair.community.model;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;

public class NoticeDAOImple implements NoticeDAO {

	private SqlSessionTemplate sqlMap;

	public NoticeDAOImple(SqlSessionTemplate sqlMap) {
		super();
		this.sqlMap = sqlMap;
	}
	
	
	/**
	 * 공지쓰기를 실행하는 메서드
	 * @param dto 글의 모든 정보를 담고 있는
	 */	
	public int notice_write(NoticeDTO dto) {
		return sqlMap.insert("notice_write",dto);
	}
	
	/**
	 * 공지 리스트를 받아오는 메서드
	 */	
	public List<NoticeDTO> notice_list() {
		List<NoticeDTO> list = sqlMap.selectList("notice_list");
		return list;
	}
	
	/**
	 * 공지 본문을 받아오는 메서드
	 * @param notice_idx 가져올 글의 idx
	 */	
	public NoticeDTO notice_content(int notice_idx) {
		return sqlMap.selectOne("notice_content",notice_idx);
	}
	
	/**
	 * 공지를 삭제하는 메서드
	 * @param notice_idx 삭제할 글의 idx
	 */	
	public int notice_del(int notice_idx) {
		return sqlMap.update("notice_del",notice_idx);
	}
	
	/**
	 * 공지를 업데이트 하는 메서드
	 * @param dto 글의 정보를 담고 있는
	 */	
	public int notice_update(NoticeDTO dto) {
		return sqlMap.update("notice_update",dto);
	}
}
