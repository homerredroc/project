package hair.community.model;

import java.util.List;

public interface QnaDAO {
	public int qna_write(QnaDTO dto);
	public List<QnaDTO> qna_list();
	public QnaDTO qna_content(int qna_idx);
	public int qna_del(int qna_idx);
	public int qna_update(QnaDTO dto);
	}
