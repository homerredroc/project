package hair.community.model;

import java.sql.Date;

public class QnaDTO {

	private int qna_idx;
	private String qna_q;
	private String qna_a;
	private Date qna_writedate;
	private int qna_state;
	private String qna_subject;
	
	public QnaDTO() {
		super();
	}

	public QnaDTO(int qna_idx, String qna_q, String qna_a, Date qna_writedate, int qna_state, String qna_subject) {
		super();
		this.qna_idx = qna_idx;
		this.qna_q = qna_q;
		this.qna_a = qna_a;
		this.qna_writedate = qna_writedate;
		this.qna_state = qna_state;
		this.qna_subject = qna_subject;
	}

	public int getQna_idx() {
		return qna_idx;
	}

	public void setQna_idx(int qna_idx) {
		this.qna_idx = qna_idx;
	}

	public String getQna_q() {
		return qna_q;
	}

	public void setQna_q(String qna_q) {
		this.qna_q = qna_q;
	}

	public String getQna_a() {
		return qna_a;
	}

	public void setQna_a(String qna_a) {
		this.qna_a = qna_a;
	}

	public Date getQna_writedate() {
		return qna_writedate;
	}

	public void setQna_writedate(Date qna_writedate) {
		this.qna_writedate = qna_writedate;
	}

	public int getQna_state() {
		return qna_state;
	}

	public void setQna_state(int qna_state) {
		this.qna_state = qna_state;
	}

	public String getQna_subject() {
		return qna_subject;
	}

	public void setQna_subject(String qna_subject) {
		this.qna_subject = qna_subject;
	}

	
}
