package hair.reservation.model;


import hair.hair.model.HairDTO;
import hair.hairshop.designer.model.DesignerDTO;
import hair.hairshop.model.HairShopDTO;
import hair.member.model.MemberDTO;

public class ReservationDTO {

	private int reservation_idx;
	private String reservation_date;
	private int member_coupon_idx;
	private int reservation_price;
	private int member_idx;
	private int hairshop_idx;
	private int hair_idx;
	private int designer_idx;
	private int reservation_state;
	private int hairoption_idx;
	private String reservation_number;
	
/**
 *    resultmap 에서 사용하는 변수
 **/
	private DesignerDTO designer;
	private HairDTO hair;
	private MemberDTO member;
	private HairShopDTO hairshop;
	
	

	public HairShopDTO getHairshop() {
		return hairshop;
	}

	public void setHairshop(HairShopDTO hairshop) {
		this.hairshop = hairshop;
	}

	public DesignerDTO getDesigner() {
		return designer;
	}

	public void setDesigner(DesignerDTO designer) {
		this.designer = designer;
	}

	public HairDTO getHair() {
		return hair;
	}

	public void setHair(HairDTO hair) {
		this.hair = hair;
	}

	public MemberDTO getMember() {
		return member;
	}

	public void setMember(MemberDTO member) {
		this.member = member;
	}
	
	

	public String getReservation_number() {
		return reservation_number;
	}

	public void setReservation_number(String reservation_number) {
		this.reservation_number = reservation_number;
	}

	public ReservationDTO() {
		super();
	}
	

	public ReservationDTO(int reservation_idx, String reservation_date, int member_coupon_idx, int reservation_price,
			int member_idx, int hairshop_idx, int hair_idx, int designer_idx, int reservation_state, int hairoption_idx,
			String reservation_number, DesignerDTO designer, HairDTO hair, MemberDTO member) {
		super();
		this.reservation_idx = reservation_idx;
		this.reservation_date = reservation_date;
		this.member_coupon_idx = member_coupon_idx;
		this.reservation_price = reservation_price;
		this.member_idx = member_idx;
		this.hairshop_idx = hairshop_idx;
		this.hair_idx = hair_idx;
		this.designer_idx = designer_idx;
		this.reservation_state = reservation_state;
		this.hairoption_idx = hairoption_idx;
		this.reservation_number = reservation_number;
		this.designer = designer;
		this.hair = hair;
		this.member = member;
	}

	public int getReservation_idx() {
		return reservation_idx;
	}

	public void setReservation_idx(int reservation_idx) {
		this.reservation_idx = reservation_idx;
	}

	public String getReservation_date() {
		return reservation_date;
	}

	public void setReservation_date(String reservation_date) {
		this.reservation_date = reservation_date;
	}

	public int getMember_coupon_idx() {
		return member_coupon_idx;
	}

	public void setMember_coupon_idx(int member_coupon_idx) {
		this.member_coupon_idx = member_coupon_idx;
	}

	public int getReservation_price() {
		return reservation_price;
	}

	public void setReservation_price(int reservation_price) {
		this.reservation_price = reservation_price;
	}

	public int getMember_idx() {
		return member_idx;
	}

	public void setMember_idx(int member_idx) {
		this.member_idx = member_idx;
	}

	public int getHairshop_idx() {
		return hairshop_idx;
	}

	public void setHairshop_idx(int hairshop_idx) {
		this.hairshop_idx = hairshop_idx;
	}

	public int getHair_idx() {
		return hair_idx;
	}

	public void setHair_idx(int hair_idx) {
		this.hair_idx = hair_idx;
	}

	public int getDesigner_idx() {
		return designer_idx;
	}

	public void setDesigner_idx(int designer_idx) {
		this.designer_idx = designer_idx;
	}

	public int getReservation_state() {
		return reservation_state;
	}

	public void setReservation_state(int reservation_state) {
		this.reservation_state = reservation_state;
	}

	public int getHairoption_idx() {
		return hairoption_idx;
	}

	public void setHairoption_idx(int hairoption_idx) {
		this.hairoption_idx = hairoption_idx;
	}
}
