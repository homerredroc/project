package hair.reservation.model;

import java.util.List;

import hair.hairshop.designer.model.DesignerDTO;
import hair.hairshop.model.HairShop_CouponDTO;
import hair.member.model.MemberDTO;

public interface ReservationDAO {
	//선택한 디자이너 스케줄
	public List<DesignerDTO> reser_desig_sch_list(int designer_idx , String nowdate);
	//다른 디자이너 스캐줄
	public List<DesignerDTO> reser_desig_list(int hair_idx , String nowdate,int designer_idx);
	//예약 등록
	public int reser_ok(ReservationDTO dto);
	//예약 정보
	public ReservationDTO reser_info(int reservation_idx);
	   //상태 변화
	   public int reser_state_update(int reservation_idx ,int state);
	//결제 창에서 보여줄 쿠폰 리스트
	public List<HairShop_CouponDTO> reser_member_coupon_list(int hairshop_idx, int member_idx);
	
	//예약시 넘겨줄 회원정보
	public MemberDTO reser_member_info(int member_idx);
}
