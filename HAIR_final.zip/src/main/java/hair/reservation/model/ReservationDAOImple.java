package hair.reservation.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;

import hair.hairshop.designer.model.DesignerDTO;
import hair.hairshop.model.HairShop_CouponDTO;
import hair.member.model.MemberDTO;

public class ReservationDAOImple implements ReservationDAO {

	private SqlSessionTemplate sqlMap;
	
	public ReservationDAOImple(SqlSessionTemplate sqlMap) {
		super();
		this.sqlMap = sqlMap;
	}

	//예약시 선택한 디자이너 스케줄
	public List<DesignerDTO> reser_desig_sch_list(int designer_idx, String nowdate) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("designer_idx", designer_idx);
		map.put("nowdate",nowdate);
		List<DesignerDTO> list = sqlMap.selectList("reser_desig_sche", map);
		return list;
	}
	
	
	//예약시 다른 디자이너 선택시 나오는 리스트
	public List<DesignerDTO> reser_desig_list(int hair_idx, String nowdate,int designer_idx) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("designer_idx",designer_idx);
		map.put("hair_idx", hair_idx);
		map.put("nowdate",nowdate);
		List<DesignerDTO> list = sqlMap.selectList("reser_order_desig_sche", map);
		return list;
	}

	//결제후 예약 드옭
	public int reser_ok(ReservationDTO dto) {
		dto.getReservation_date();
		int count = sqlMap.insert("reser_reg", dto);
		return count;
	}

	//스케줄에서 예약 정보
	public ReservationDTO reser_info(int reservation_idx) {
		ReservationDTO dto = sqlMap.selectOne("reser_info",reservation_idx);
		return dto;
	}

	   //예약 상태 변화
	   public int reser_state_update(int reservation_idx , int state) {
	      Map<String, Integer> map = new HashMap<String, Integer>();
	      map.put("reservation_idx", reservation_idx);
	      map.put("state", state);
	      
	      int count = sqlMap.update("reser_state_update", map);
	      return count;
	   }
   // 예약 페이지에서 보여줄 멤버 쿠폰 리스트
	public List<HairShop_CouponDTO> reser_member_coupon_list(int hairshop_idx, int member_idx) {
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("hairshop_idx", hairshop_idx);
		map.put("member_idx", member_idx);
		List<HairShop_CouponDTO> list = sqlMap.selectList("payment_member_coupon_list", map);
		return list;
	}

	//예약한 맴버의 정보
	public MemberDTO reser_member_info(int member_idx) {
	    MemberDTO dto = sqlMap.selectOne("reser_member_info", member_idx);
		return dto;
	}
	

}
