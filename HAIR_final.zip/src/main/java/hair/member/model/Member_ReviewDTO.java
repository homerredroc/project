package hair.member.model;

import java.sql.Date;

import hair.hairshop.model.HairShopDTO;

public class Member_ReviewDTO {

	private int member_review_idx;
	private String member_review_subject;
	private String member_review_content;
	private Date member_review_writedate;
	private int member_review_grade;
	private int member_review_state;
	private String member_review_hashtag;
	private int member_idx;
	private int hairshop_idx;
	private int reservation_idx;
	private String member_review_thumb;
	private String hairshop_name;

	
	private HairShopDTO hairshop;
	private MemberDTO memberDTO;
	
	
	public MemberDTO getMemberDTO() {
		return memberDTO;
	}

	public void setMemberDTO(MemberDTO memberDTO) {
		this.memberDTO = memberDTO;
	}

	public String getHairshop_name() {
		return hairshop_name;
	}

	public void setHairshop_name(String hairshop_name) {
		this.hairshop_name = hairshop_name;
	}

	public HairShopDTO getHairshop() {
		return hairshop;
	}

	public void setHairshop(HairShopDTO hairshop) {
		this.hairshop = hairshop;
	}

	public Member_ReviewDTO() {
		super();
	}

	public Member_ReviewDTO(int member_review_idx, String member_review_subject, String member_review_content,
			Date member_review_writedate, int member_review_grade, int member_review_state,
			String member_review_hashtag, int member_idx, int hairshop_idx, int reservation_idx,String member_review_thumb) {
		super();
		this.member_review_idx = member_review_idx;
		this.member_review_subject = member_review_subject;
		this.member_review_content = member_review_content;
		this.member_review_writedate = member_review_writedate;
		this.member_review_grade = member_review_grade;
		this.member_review_state = member_review_state;
		this.member_review_hashtag = member_review_hashtag;
		this.member_idx = member_idx;
		this.hairshop_idx = hairshop_idx;
		this.reservation_idx = reservation_idx;
		this.member_review_thumb = member_review_thumb;
	}

	public int getMember_review_idx() {
		return member_review_idx;
	}

	public void setMember_review_idx(int member_review_idx) {
		this.member_review_idx = member_review_idx;
	}

	public String getMember_review_subject() {
		return member_review_subject;
	}

	public void setMember_review_subject(String member_review_subject) {
		this.member_review_subject = member_review_subject;
	}

	public String getMember_review_content() {
		return member_review_content;
	}

	public void setMember_review_content(String member_review_content) {
		this.member_review_content = member_review_content;
	}

	public Date getMember_review_writedate() {
		return member_review_writedate;
	}

	public void setMember_review_writedate(Date member_review_writedate) {
		this.member_review_writedate = member_review_writedate;
	}

	public int getMember_review_grade() {
		return member_review_grade;
	}

	public void setMember_review_grade(int member_review_grade) {
		this.member_review_grade = member_review_grade;
	}

	public int getMember_review_state() {
		return member_review_state;
	}

	public void setMember_review_state(int member_review_state) {
		this.member_review_state = member_review_state;
	}

	public String getMember_review_hashtag() {
		return member_review_hashtag;
	}

	public void setMember_review_hashtag(String member_review_hashtag) {
		this.member_review_hashtag = member_review_hashtag;
	}

	public int getMember_idx() {
		return member_idx;
	}

	public void setMember_idx(int member_idx) {
		this.member_idx = member_idx;
	}

	public int getHairshop_idx() {
		return hairshop_idx;
	}

	public void setHairshop_idx(int hairshop_idx) {
		this.hairshop_idx = hairshop_idx;
	}

	public int getReservation_idx() {
		return reservation_idx;
	}

	public void setReservation_idx(int reservation_idx) {
		this.reservation_idx = reservation_idx;
	}

	public String getMember_review_thumb() {
		return member_review_thumb;
	}

	public void setMember_review_thumb(String member_review_thumb) {
		this.member_review_thumb = member_review_thumb;
	}
	
	
}
