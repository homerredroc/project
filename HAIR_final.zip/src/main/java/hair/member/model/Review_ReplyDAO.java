package hair.member.model;

import java.util.List;

public interface Review_ReplyDAO {
	public Review_ReplyDTO review_reply_write(Review_ReplyDTO dto);
	public List<Review_ReplyDTO> review_reply(int member_review_idx);
	public void review_reply_delete(int member_review_idx);
	public Review_ReplyDTO review_reply_rewrite(int review_reply_idx, String review_reply_content);
}
