package hair.member.model;

public class Member_Review_PhotoDTO {

	private int member_review_idx;
	private String photo_name;
	
	public Member_Review_PhotoDTO() {
		super();
	}

	public Member_Review_PhotoDTO(int member_review_idx, String photo_name) {
		super();
		this.member_review_idx = member_review_idx;
		this.photo_name = photo_name;
	}

	public int getMember_review_idx() {
		return member_review_idx;
	}

	public void setMember_review_idx(int member_review_idx) {
		this.member_review_idx = member_review_idx;
	}

	public String getPhoto_name() {
		return photo_name;
	}

	public void setPhoto_name(String photo_name) {
		this.photo_name = photo_name;
	}	
}
