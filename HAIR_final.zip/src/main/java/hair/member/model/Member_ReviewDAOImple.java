package hair.member.model;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;

public class Member_ReviewDAOImple implements Member_ReviewDAO {

   private SqlSessionTemplate sqlMap;
   
   public Member_ReviewDAOImple(SqlSessionTemplate sqlMap) {
      super();
      this.sqlMap = sqlMap;
   }

   /**
    * 리뷰쓰기를 실행하는 메서드
    * @param dto 글의 모든 정보를 담고 있는
    */   
   public int memberReviewWrite(Member_ReviewDTO dto) {
      return sqlMap.insert("memberReviewWrite",dto);
   }

   public int memberReviewUpdate(Member_ReviewDTO dto) {
      return sqlMap.update("memberReviewUpdate",dto);
   }
   
   public int memberReviewDel(int member_review_idx) {
      return sqlMap.update("memberReviewDel",member_review_idx);
   }
   
   /**
    * 리뷰 검색시 글의 개수를 알기 위한 메서드
    * @param search_option 어떤 검색을 했는 지 알기 위해
    * @param search_value 어떤 키워드로 검색을 했는지
    */   
   public int memberReviewTotalCnt(String search_option, String search_value) {
      HashMap<String, Object> hm = new HashMap<String, Object>();
      hm.put("search_option", search_option);
      if(search_option.equals("subject")) {
         hm.put("subjectvalue", search_value);
         hm.put("ar", "and");
      }else if(search_option.equals("content")) {
         hm.put("contentvalue", search_value);
         hm.put("ar", "and");
      }else if(search_option.equals("subtent")) {
         hm.put("contentvalue", search_value);
         hm.put("subjectvalue", search_value);
         hm.put("ar", "or");
      }else if(search_option.equals("hairshopname")) {
         hm.put("namevalue", search_value);
         hm.put("ar", "and");
      }else if(search_option.equals("hashtag")) {
         hm.put("hashvalue", search_value);
         hm.put("ar", "and");
      }
      return sqlMap.selectOne("memberReviewTotalCnt",hm);
   }
   
   /**
    * 리뷰검색시 정보를 가져오는 메서드
    * @param cp 사용자의 현재 위치
    * @param ls 불러올 글들의 사이즈
    * @param search_option 어떤 검색을 했는 지 알기 위해
    * @param search_value 어떤 키워드로 검색을 했는지
    * @param order 어떤 정렬을 했는지
    */   
   public List<Member_ReviewDTO> memberReviewList(int cp, int ls, String search_option, String search_value,
         String order) {
      
      HashMap<String, Object> hm = new HashMap<String, Object>();
      List<Member_ReviewDTO> list=null;
      int startnum=(cp-1)*ls+1;
      int endnum=cp*ls;
      hm.put("startnum", startnum);
      hm.put("endnum", endnum);
      hm.put("search_option", search_option);
      hm.put("order", order);
      if(search_option.equals("subject")) {
         hm.put("subjectvalue", search_value);
         hm.put("ar", "and");
      }else if(search_option.equals("content")) {
         hm.put("contentvalue", search_value);
         hm.put("ar", "and");
      }else if(search_option.equals("subtent")) {
         hm.put("contentvalue", search_value);
         hm.put("subjectvalue", search_value);
         hm.put("ar", "or");
      }else if(search_option.equals("hairshopname")) {
         hm.put("namevalue", search_value);
         hm.put("ar", "and");
      }else if(search_option.equals("hashtag")) {
         hm.put("hashvalue", search_value);
         hm.put("ar", "and");
      }
      list=sqlMap.selectList("memberReviewList",hm);
      return list;
   }
   
   public Member_ReviewDTO memberReviewContent(int idx) {
      return sqlMap.selectOne("memberReviewContent",idx);
   }
   
   
   /**
    * 사용자가 헤어샵 페이지에서 리뷰를 불러오는 메서드
    * @param cp 사용자의 현재 위치
    * @param ls 불러올 글들의 사이즈
    * @param hairshop_idx 들어간 페이지의 idx
    */   
   public List<Member_ReviewDTO> member_member_review_list(int cp, int ls, int hairshop_idx) {
      HashMap<String, Object> hm = new HashMap<String, Object>();
      int startnum=(cp-1)*ls+1;
      int endnum=cp*ls;
      hm.put("startnum", startnum);
      hm.put("endnum", endnum);
      hm.put("hairshop_idx", hairshop_idx);
      List<Member_ReviewDTO> list=sqlMap.selectList("member_member_review_list",hm);
      return list;
   }
   /**
    * 사용자가 헤어샵 페이지에서 리뷰의 갯수를 불러오는 메서드
    * @param hairshop_idx 들어간 페이지의 idx
    */   
   public int member_member_review_totalcnt(int hairshop_idx) {
      // TODO Auto-generated method stub
      return sqlMap.selectOne("member_member_review_totalcnt",hairshop_idx);
   }
}