package hair.member.model;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;

import hair.hairshop.model.HairShopDTO;
import hair.hairshop.model.HairShop_CouponDTO;
import hair.message.model.MessageDTO;
import hair.reservation.model.ReservationDTO;

public class MemberDAOImple implements MemberDAO {
	
	private SqlSessionTemplate sqlMap; 
	
	public MemberDAOImple(SqlSessionTemplate sqlMap) {
		this.sqlMap = sqlMap;
	}
		
	//
	public int member_sendMessage_TotalCnt(int member_idx) {
			
		int count=sqlMap.selectOne("member_sendMessage_TotalCnt", member_idx);
		
			return count;
		}
	
	//
	public int member_receiveMessage_TotalCnt(int member_idx) {
			
		int count=sqlMap.selectOne("member_receiveMessage_TotalCnt", member_idx);
		
			return count;
		}
	
	//아이디찾기
	public List<MemberDTO> member_search_id(String member_name, String member_tel, String member_email) {
		
		HashMap hm = new HashMap();
		hm.put("member_name", member_name);
		hm.put("member_tel", member_tel);
		hm.put("member_email", member_email);
		
		
		List<MemberDTO> member_search_id =sqlMap.selectList("member_search_id", hm);
		return member_search_id;
	}
	
	
	//비밀번호찾기
	public List<MemberDTO> member_search_pwd(String member_id, String member_name, String member_email){
		
		HashMap hm = new HashMap();
		hm.put("member_id", member_id);
		hm.put("member_name", member_name);
		hm.put("member_email", member_email);
		
		List<MemberDTO> member_search_pwd = sqlMap.selectList("member_search_pwd", hm);
		return member_search_pwd;
	}
	
	//비밀번호 변경
	public int member_pwd_update(String member_idx, String member_pwd) {
		
		HashMap hm = new HashMap();
		hm.put("member_idx", member_idx);
		hm.put("member_pwd", member_pwd);
		
		int count = sqlMap.update("member_pwd_update", hm);
		return count;
	}
	
	
	//회원가입 
	public int member_join(MemberDTO mdto) {
		
		int count = sqlMap.insert("member_join", mdto); 
		return count;
	}
	
	 //마이페이지_결제금액 확인하기
	 public int member_total_reservation_Price(int member_idx) {
		 
		 int resPrice = sqlMap.selectOne("member_total_resPrice", member_idx);
		 return resPrice;
	 }
		
	 
	 //마이페이지_쿠폰 갯수 확인하기
	   public int member_coupon_count(int member_idx) {
		
		   int count = sqlMap.selectOne("member_couponCount", member_idx);
		   return count;
	   }
	   
	 //마이페이지_메세지 갯수 확인하기
	   public int member_message_Count(int member_idx) {
		   
		  int count = sqlMap.selectOne("member_messageCount", member_idx);
		  return count;
	   }
	 
	 
		//비밀번화 확인
		public String member_pwd_Check(int member_idx){
			
	
			String result = sqlMap.selectOne("member_pwdCheck", member_idx);
			return result;
		}
	    

		//마이페이지_회원탈퇴
		public int member_Leave(int member_idx, int member_state){
			
			HashMap<String ,Integer> hm = new HashMap<String, Integer>();
		      hm.put("member_idx", member_idx);
		      hm.put("member_state", member_state);
			
			int count = sqlMap.update("memberLeave", hm); 
			return count;
		}
	 
	 
	 
		//마이페이지_회원정보 가져오기 
		public MemberDTO member_Info(String member_id){
			
			MemberDTO dto = sqlMap.selectOne("memberInfo", member_id);
			return dto;
		}
		
		
		//마이페이지_회원 정보 수정하기
		 public int member_Update(String member_id,String member_pwd,String member_email, String member_addr, String member_tel) {
			 
			 HashMap<String,String> hm = new HashMap<String, String>();
			  hm.put("member_id", member_id);
		      hm.put("member_pwd", member_pwd);
		      hm.put("member_email", member_email);
		      hm.put("member_addr", member_addr);
		      hm.put("member_tel", member_tel);
		       
			 int count =  sqlMap.update("memberUpdate", hm);
			 return count;
		 }
		
		
		  //마이페이지_예약리스트
		   public List<ReservationDTO> member_reservation_List(int member_idx) {
			   
			   List<ReservationDTO> reservationList = sqlMap.selectList("member_reservationList", member_idx);
			   return reservationList;   
		   }
		
		
		   //마이페이지_예약리스트_예약취소
		   public int member_reservation_Cancle (int reservation_idx) {
			   
			   int resCancle = sqlMap.update("member_reservation_Cancle", reservation_idx);
			   return resCancle;
		   }
		 
		
		
		   
		   //마이페이지_리뷰리스트
		   public List<Member_ReviewDTO> member_review_List(int member_idx){
			   
			   List<Member_ReviewDTO> reviewList = sqlMap.selectList("member_review_List", member_idx);
			   return reviewList;   
		   }
		   
		   
		   //마이페이지_관심헤어샵 정보
		   public List<HairShopDTO> member_goodShop_hairshop_Info(int member_idx){
			   
			   List<HairShopDTO> goodShop_hairshopInfo = sqlMap.selectList("member_goodShop_hairshop_Info", member_idx);
			   return goodShop_hairshopInfo;
		   }
		   
		   	   
			 //마이페이지_관심헤어샵 리뷰수, 평점 평균
			   public  HashMap<String, Object> member_goodShop_avg_count_Review(int hairshop_idx){
				   	   
				   HashMap<String, Object> goodShop_avg_countReview = sqlMap.selectOne("member_goodShop_avg_count_Review", hairshop_idx);	  	    
				   return goodShop_avg_countReview;
			   }
		   
				 //마이페이지_관심헤어샵 예약 수
			   public int member_goodShop_count_Reservation(int hairshop_idx){
				   
				   int goodShop_countReservation = sqlMap.selectOne("member_goodShop_count_Reservation", hairshop_idx);
				   return goodShop_countReservation;
			   }
			
			   //마이페이지_관심헤어샵 좋아요 총 수 
			   public int member_goodShop_count_Favorite(int hairshop_idx){
				   
				   int goodShop_countFavorite = sqlMap.selectOne("member_goodShop_count_Favorite", hairshop_idx);
				   return goodShop_countFavorite;
			   }
		      		   
			   //마이페이지_관심 헤어스타일 
			   public  List<HashMap<String, Object>> member_good_Style (int member_idx){
				   List<HashMap<String, Object>> goodStyle = sqlMap.selectList("member_good_Style", member_idx);	  	    
				   return goodStyle;
			   }
			   		   
			   //마이페이지_관심헤어삽 취소
			   public int member_goodshop_Cancle (int member_idx, int hairshop_idx) {
				   
				   HashMap<String, Integer> shopIdx = new HashMap<String, Integer>();
				   shopIdx.put("member_idx", member_idx);
				   shopIdx.put("hairshop_idx", hairshop_idx);
				   
				   int goodshopCancle = sqlMap.delete("member_goodshop_Cancle", shopIdx);
				   return goodshopCancle;
			   } 
			   
			   //마이페이지_관심스타일 취소
			   public int member_good_style_Cancle(int member_idx, int hairshop_bbs_idx ) {
				   
				   HashMap<String,Integer> styleIdx = new HashMap<String, Integer>();
				   styleIdx.put("member_idx", member_idx);
				   styleIdx.put("hairshop_bbs_idx", hairshop_bbs_idx);
			   
				   int goodstyleCancle = sqlMap.delete("member_good_style_Cancle", styleIdx);
				   return goodstyleCancle;
			   }
			     
			   public List<MessageDTO> sendlist(int member_idx , int cp, int ls) {
					
					int startnum=(cp-1)*ls+1;
				    int endnum=cp*ls;
				      
				    Map<String, Integer> map=new HashMap<String, Integer>();
				    map.put("member_idx", member_idx);
				    map.put("startnum", startnum);
				    map.put("endnum", endnum);
					
					List<MessageDTO> list = sqlMap.selectList("member_sendMessage", map);
					return list;
				}
				
				public List<MessageDTO> receivelist(int member_idx, int cp, int ls) {
					
					int startnum=(cp-1)*ls+1;
				    int endnum=cp*ls;
				      
				    Map<String, Integer> map=new HashMap<String, Integer>();
				    map.put("member_idx", member_idx);
				    map.put("startnum", startnum);
				    map.put("endnum", endnum);
					
					List<MessageDTO> list = sqlMap.selectList("member_receiveMessage", map);
						return list;
				}
			   
			   public MessageDTO member_message_Info(int message_idx) {
					MessageDTO dto = sqlMap.selectOne("member_message_Info",message_idx);
						return dto;
					}
			   
			   public int member_msg_Check(int message_idx) {
					int result = sqlMap.update("member_msg_Check", message_idx);
					return result;
					}
			   
			   public int member_remessage( int sender_idx, int receiver_idx, String message_content ) {
					Map<String,Object> hm = new HashMap<String, Object>();
						hm.put("member_idx", sender_idx);
						hm.put("receiver_idx", receiver_idx);
						hm.put("message_content", message_content);
						
						int result = sqlMap.insert("member_message", hm);
						return result;
					}
			   
				//로그인
				public MemberDTO member_login(String member_id, String member_pwd) {
				      
				      HashMap<String,Object> hm = new HashMap<String, Object>();
				      hm.put("member_id", member_id);
				      hm.put("member_pwd", member_pwd);
				      
				      MemberDTO count = sqlMap.selectOne("member_login", hm);
				      return count;
				      
				   }
				
				
				public int member_del_Msg(int message_idx) {
					int result = sqlMap.update("member_del_Msg", message_idx);
						return result;
					}
				
				//회원가입_아이디 중복체크 
				public boolean member_idcheck(String member_id) {
					//System.out.println(member_id); 	넘어온 member_id 확인
					String idcheck = sqlMap.selectOne("member_idcheck", member_id); 

					boolean result = false;
					
					 if(idcheck==null||idcheck.equals("")) {
				         result=true;
				      }else {
				    	 result=false;
				      }
					
					return result;            
				}
				
				
				//마이페이지_예약리스트_hairshop_idx 값 가져오기
				   public int getHairshop_idx(int member_idx) {
					   
					    int hairshop_idx = sqlMap.selectOne("getHairshop_idx", member_idx);
					    return hairshop_idx;
				   }
				
				
				//마이페이지 쿠폰 리스트 가져오기

				   public List<HairShop_CouponDTO> member_coupon_list(int member_idx)
				   {
					   List<HairShop_CouponDTO> list = sqlMap.selectList("member_coupon_list", member_idx);
					   return list;
				   }
				   
				   

	   ////////////////////////////////////////////////////////관리자//////////////////////////////////////
	 //관리자 페이지 - 개인회원목록 보기
		public List<MemberDTO> memberList(int cp,int ls) {
			
			int startnum=(cp-1)*ls+1;
			int endnum=cp*ls;
			
			Map<String, Integer> map=new HashMap<String, Integer>();
			map.put("startnum", startnum);
			map.put("endnum", endnum);
			
			List<MemberDTO> list=sqlMap.selectList("memberList", map);
			
			return list;
		}
		
		//관리자 페이지 - 블랙회원목록 보기
		public List<MemberDTO> blackMemberList(int cp,int ls) {
			
			int startnum=(cp-1)*ls+1;
			int endnum=cp*ls;
			
			Map<String, Integer> map=new HashMap<String, Integer>();
			map.put("startnum", startnum);
			map.put("endnum", endnum);
			
			List<MemberDTO> blackList=sqlMap.selectList("blackMemberList", map);
			
			return blackList;
		}
		
		//관리자 페이지 - 탈퇴회원목록 보기
		public List<MemberDTO> outMemberList(int cp,int ls) {
			
			int startnum=(cp-1)*ls+1;
			int endnum=cp*ls;
			
			Map<String, Integer> map=new HashMap<String, Integer>();
			map.put("startnum", startnum);
			map.put("endnum", endnum);
			
			List<MemberDTO> outList=sqlMap.selectList("outMemberList", map);
			
			return outList;
		}
		
		//관리자 페이지 - 정상회원 totalCnt
		public int normalTotalCnt() {
			
			int count=sqlMap.selectOne("normalTotalCnt");
			
			return count;
		}
		
		//관리자 페이지 - 블랙회원 totalCnt
		public int blackTotalCnt() {
			
			int count=sqlMap.selectOne("blackTotalCnt");
			
			return count;
		}
		
		//관리자 페이지 - 탈퇴회원 totalCnt
		public int outTotalCnt() {
			
			int count=sqlMap.selectOne("outTotalCnt");
			
			return count;
		}
		
		//관리자 페이지 - 회원 탈퇴처리하기
		public int makeMemberOut(String members_id) {
			
			int count=sqlMap.update("makeMemberOut", members_id);
			
			return count;
		}
		
		//관리자 페이지 - 회원 블랙처리하기
		public int makeMemberBlack(String members_id) {
			
			int count=sqlMap.update("makeMemberBlack", members_id);
			
			return count;
		}
		
		//관리자 페이지 - 레벨 바꾸기
		public int setMemberLevel(String member_level, String members_id) {
			
			Map<String, String> map=new HashMap<String, String>();
			map.put("member_level", member_level);
			map.put("members_id", members_id);
			
			int count=sqlMap.update("setMemberLevel", map);
			
			return count;
		}
		
		//관리자 페이지 - 회원 탈퇴,블랙 취소하기
		public int makeMemberNormal(String members_id) {
			
			int count=sqlMap.update("makeMemberNormal", members_id);
			
			return count;
		}
		
		//관리자 페이지 - 회원 검색하기
		public List<MemberDTO> memberSearch(String member_id) {
			
			List<MemberDTO> list=sqlMap.selectList("memberSearch", member_id);
			
			return list;
		}


		public void member_coupon_state(int member_coupon_idx, int state) {
			Map<String, Integer>map =  new HashMap<String, Integer>();
			map.put("member_coupon_idx", member_coupon_idx);
			map.put("state", state);
			sqlMap.update("member_coupon_state", map);
		}
	 

}

