package hair.member.model;

import java.util.HashMap;
import java.util.List;

import hair.hairshop.model.HairShopDTO;
import hair.hairshop.model.HairShop_CouponDTO;
import hair.message.model.MessageDTO;
import hair.reservation.model.ReservationDTO;

public interface MemberDAO {
	

	
public void member_coupon_state(int member_coupon_idx,int state);
	
public int member_join(MemberDTO mdto);
	
public int member_coupon_count (int member_idx);

public int member_message_Count(int member_idx);

public int member_total_reservation_Price(int member_idx);

public String member_pwd_Check(int member_idx);

public int member_Leave(int member_idx, int member_state);

public MemberDTO member_Info(String member_id);


public int member_Update(String member_id,String member_pwd,String member_email, String member_addr, String member_tel);


public List<ReservationDTO> member_reservation_List(int member_idx);


public int member_reservation_Cancle (int reservation_idx);


public List<Member_ReviewDTO> member_review_List(int member_idx);

public List<HairShopDTO> member_goodShop_hairshop_Info(int member_idx);

public  HashMap<String, Object> member_goodShop_avg_count_Review(int hairshop_idx);


public int member_goodShop_count_Reservation(int hairshop_idx);

public int member_goodShop_count_Favorite(int hairshop_idx);

public List<HashMap<String, Object>> member_good_Style (int member_idx);

public int member_goodshop_Cancle (int member_idx, int hairshop_idx);

public int member_good_style_Cancle (int member_idx, int hairshop_bbs_idx );


//보낸 메세지 페이징
public int member_sendMessage_TotalCnt(int member_idx);

//받은 메세지 페이징
public int member_receiveMessage_TotalCnt(int member_idx);

//보낸메세지 리스트 불러오기
	public List<MessageDTO> sendlist(int member_idx, int cp, int ls);
	
	//받은 메세지 리스트 불러오기
	public List<MessageDTO> receivelist(int member_idx, int cp, int ls);
//메세지 정보 가져오기
public MessageDTO member_message_Info(int message_idx);

//메세지 수신확인상태 바꾸기
public int member_msg_Check(int message_idx);

//답장(메세지)보내기
public int member_remessage(int sender_idx, int receiver_idx, String message_content);

//메세지 버리기
public int member_del_Msg(int message_idx);


public MemberDTO member_login(String member_id, String member_pwd);


public boolean member_idcheck(String member_id);


public int getHairshop_idx(int member_idx); 
   

public List<HairShop_CouponDTO> member_coupon_list(int member_idx);


/*개인회원 아이디 찾기*/
public List<MemberDTO> member_search_id(String member_name, String member_tel, String member_email);
/*개인회원 비밀번호 찾기*/
public List<MemberDTO> member_search_pwd(String member_id, String member_name, String member_email);
/*개인회원 비밀번호 바꾸기*/
public int member_pwd_update(String member_idx, String member_pwd);


    


  

    

    

    


    

   

    

    ////////////////////////////////////////////////////관리자 //////////////////////////////////////
  //관리자 페이지 - 개인회원목록 보기
  	public List<MemberDTO> memberList(int cp,int ls);
  	
  	//관리자 페이지 - 블랙회원목록 보기
  	public List<MemberDTO> blackMemberList(int cp,int ls);
  		
  	//관리자 페이지 - 탈퇴회원목록 보기
  	public List<MemberDTO> outMemberList(int cp,int ls);
  	
  	//관리자 페이지 - 정상회원 totalCnt
  	public int normalTotalCnt();
  	
  	//관리자 페이지 - 블랙회원 totalCnt
  	public int blackTotalCnt();
  	
  	//관리자 페이지 - 탈퇴회원 totalCnt
  	public int outTotalCnt();
  	
  	//관리자 페이지 - 회원 탈퇴시키기
  	public int makeMemberOut(String members_id);
  	
  	//관리자 페이지 - 회원 블랙처리하기
  	public int makeMemberBlack(String members_id);
  	
  	//관리자 페이지 - 레벨 바꾸기
  	public int setMemberLevel(String member_level,String members_id);
  	
  	//관리자 페이지 - 회원 탈퇴,블랙 취소하기
  	public int makeMemberNormal(String members_id);
  	
  	//관리자 페이지 - 회원 검색하기
  	public List<MemberDTO> memberSearch(String member_id);
  	/////////////////////////////////////////////
  	
  	


	
	
	

	
}
