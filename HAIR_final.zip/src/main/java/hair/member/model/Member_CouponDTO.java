package hair.member.model;

import hair.hairshop.model.HairShopDTO;

public class Member_CouponDTO {

	private int member_coupon_idx;
	private String member_coupon_deadline;
	private int member_idx;
	private int hairshop_coupon_idx;
	private int member_coupon_state;
	
	private HairShopDTO	hairshopdto;
	
	
	public HairShopDTO getHairshopdto() {
		return hairshopdto;
	}

	public void setHairshopdto(HairShopDTO hairshopdto) {
		this.hairshopdto = hairshopdto;
	}

	public Member_CouponDTO() {
		super();
	}

	public Member_CouponDTO(int member_coupon_idx, String member_coupon_deadline, int member_idx,
			int hairshop_coupon_idx, int member_coupon_state) {
		super();
		this.member_coupon_idx = member_coupon_idx;
		this.member_coupon_deadline = member_coupon_deadline;
		this.member_idx = member_idx;
		this.hairshop_coupon_idx = hairshop_coupon_idx;
		this.member_coupon_state = member_coupon_state;
	}

	public int getMember_coupon_idx() {
		return member_coupon_idx;
	}

	public void setMember_coupon_idx(int member_coupon_idx) {
		this.member_coupon_idx = member_coupon_idx;
	}

	public String getMember_coupon_deadline() {
		return member_coupon_deadline;
	}

	public void setMember_coupon_deadline(String member_coupon_deadline) {
		this.member_coupon_deadline = member_coupon_deadline;
	}

	public int getMember_idx() {
		return member_idx;
	}

	public void setMember_idx(int member_idx) {
		this.member_idx = member_idx;
	}

	public int getHairshop_coupon_idx() {
		return hairshop_coupon_idx;
	}

	public void setHairshop_coupon_idx(int hairshop_coupon_idx) {
		this.hairshop_coupon_idx = hairshop_coupon_idx;
	}

	public int getMember_coupon_state() {
		return member_coupon_state;
	}

	public void setMember_coupon_state(int member_coupon_state) {
		this.member_coupon_state = member_coupon_state;
	}
}
