package hair.member.model;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;

public class Review_ReplyDAOImple implements Review_ReplyDAO {

	private SqlSessionTemplate sqlMap;
	
	
	
	public Review_ReplyDAOImple(SqlSessionTemplate sqlMap) {
		super();
		this.sqlMap = sqlMap;
	}


	/**
	 * 리뷰댓글쓰기를 실행하는 메서드
	 * @param dto 댓글의 모든 정보를 담고 있는
	 */	
	public Review_ReplyDTO review_reply_write(Review_ReplyDTO dto) {
		sqlMap.insert("review_reply_write",dto);
		return sqlMap.selectOne("review_reply_return",dto.getMember_idx());
	}
	
	/**
	 * 리뷰댓글을 불러오는 메서드
	 * @param member_review_idx 기준이 되는 글의 idx
	 */	
	public List<Review_ReplyDTO> review_reply(int member_review_idx) {
	List<Review_ReplyDTO> list=sqlMap.selectList("review_reply",member_review_idx);
	return list;
	}
	
	
	/**
	 * 리뷰댓글을 삭제하는 메서드
	 * @param review_reply_idx 기준이 되는 댓글의 idx
	 */	
	public void review_reply_delete(int review_reply_idx) {
		sqlMap.delete("review_reply_delete",review_reply_idx);
	}
	
	/**
	 * 리뷰댓글을 수정하는 메서드
	 * @param review_reply_idx 기준이 되는 댓글의 idx
	 * @param review_reply_content 수정할 내용
	 */	
	public Review_ReplyDTO review_reply_rewrite(int review_reply_idx, String review_reply_content) {
		HashMap<String, Object> map = new HashMap();
		map.put("review_reply_content", review_reply_content);
		map.put("review_reply_idx", review_reply_idx);
		sqlMap.update("review_reply_rewrite",map);
		return sqlMap.selectOne("review_reply_selectone",review_reply_idx);
	}

}
