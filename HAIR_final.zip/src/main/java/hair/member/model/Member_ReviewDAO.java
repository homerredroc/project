package hair.member.model;

import java.util.List;


public interface Member_ReviewDAO {
   public int memberReviewWrite(Member_ReviewDTO dto);
   public List<Member_ReviewDTO> memberReviewList(int cp, int ls, String search_option, String search_value, String order);
   public int memberReviewTotalCnt(String search_option, String search_value);
   public Member_ReviewDTO memberReviewContent(int idx);
   public int memberReviewUpdate(Member_ReviewDTO dto);
   public int memberReviewDel(int member_review_idx);
   public List<Member_ReviewDTO> member_member_review_list(int cp, int ls, int hairshop_idx);
   public int member_member_review_totalcnt(int hairshop_idx);
}