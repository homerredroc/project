package hair.member.model;

import java.sql.Date;

public class Review_ReplyDTO {

	private int review_reply_idx;
	private String review_reply_content;
	private Date review_reply_writedate;
	private int member_idx;
	private int member_review_idx;
	private String member_name;
	private String hairshop_name;
	public Review_ReplyDTO() {
		super();
	}



	public Review_ReplyDTO(int review_reply_idx, String review_reply_content, Date review_reply_writedate,
			int member_idx, int member_review_idx, String member_name, String hairshop_name) {
		super();
		this.review_reply_idx = review_reply_idx;
		this.review_reply_content = review_reply_content;
		this.review_reply_writedate = review_reply_writedate;
		this.member_idx = member_idx;
		this.member_review_idx = member_review_idx;
		this.member_name = member_name;
		this.hairshop_name = hairshop_name;
	}



	public int getReview_reply_idx() {
		return review_reply_idx;
	}

	public void setReview_reply_idx(int review_reply_idx) {
		this.review_reply_idx = review_reply_idx;
	}

	public String getReview_reply_content() {
		return review_reply_content;
	}

	public void setReview_reply_content(String review_reply_content) {
		this.review_reply_content = review_reply_content;
	}

	public Date getReview_reply_writedate() {
		return review_reply_writedate;
	}

	public void setReview_reply_writedate(Date review_reply_writedate) {
		this.review_reply_writedate = review_reply_writedate;
	}

	public int getMember_idx() {
		return member_idx;
	}

	public void setMember_idx(int member_idx) {
		this.member_idx = member_idx;
	}

	public int getMember_review_idx() {
		return member_review_idx;
	}

	public void setMember_review_idx(int member_review_idx) {
		this.member_review_idx = member_review_idx;
	}

	public String getMember_name() {
		return member_name;
	}

	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}


	public String getHairshop_name() {
		return hairshop_name;
	}



	public void setHairshop_name(String hairshop_name) {
		this.hairshop_name = hairshop_name;
	}
	
	
	
}
