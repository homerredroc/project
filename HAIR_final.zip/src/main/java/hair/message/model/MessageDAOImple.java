package hair.message.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;

public class MessageDAOImple implements MessageDAO {

	private SqlSessionTemplate sqlMap;

	public MessageDAOImple(SqlSessionTemplate sqlMap) {
		super();
		this.sqlMap = sqlMap;
	}
	
	//관리자 페이지 - 기업에게 받은 메세지 totalCnt
	public int receiveMsgFromShop_totalCnt() {
		
		int count=sqlMap.selectOne("receiveMsgFromShop_totalCnt");
		
		return count;
	}
	
	//관리자 페이지 - 회원에게 보낸 메세지 totalCnt
	public int sendMsgToMember_totalCnt() {
		
		int count=sqlMap.selectOne("sendMsgToMember_totalCnt");
		
		return count;
	}
	
	//관리자 페이지 - 기업에게 보낸 메세지 totalCnt
	public int sendMsgToShop_totalCnt() {
		
		int count=sqlMap.selectOne("sendMsgToShop_totalCnt");
		
		return count;
	}
	
	//관리자 페이지 - 삭제한 메세지 totalCnt
	public int deleteMsg_totalCnt() {
		
		int count=sqlMap.selectOne("deleteMsg_totalCnt");
		
		return count;
	}
	
	//관리자 페이지 - 개인 전체 메세지 보내기
	public int admin_msgSendMember(String message_content, String select) {
		
		int count=sqlMap.insert("sendMsgAllMember", message_content);
		
		return count;
	}
	
	//관리자 페이지 - 기업 전체 메세지 보내기
	public int admin_msgSendShop(String message_content, String select) {
		
		int count=sqlMap.insert("sendMsgAllShop", message_content);
		
		return count;
	}
	
	//관리자 페이지 - 선택한 개인회원에게 메세지 보내기
	public int admin_eachMemberMsgSend(String message_content, String members_id) {
		
		Map<String, String> map=new HashMap<String, String>();
		map.put("message_content", message_content);
		map.put("members_id", members_id);
		
		int count=sqlMap.insert("sendMsgMemberChecked", map);
		
		return count;
	}
	
	//관리자 페이지 - 선택한 기업회원에게 메세지 보내기
	public int admin_eachHairshopMsgSend(String message_content, String hairshops_id) {
		
		Map<String, String> map=new HashMap<String, String>();
		map.put("message_content", message_content);
		map.put("hairshops_id", hairshops_id);
		
		int count=sqlMap.insert("sendMsgHairshopChecked", map);
		
		return count;
	}
	
	//관리자 페이지 - 기업에게 받은 메세지 목록보기
	public List<MessageDTO> receiveMsgListFromShop(int cp,int ls) {
		
		int startnum=(cp-1)*ls+1;
		int endnum=cp*ls;
		
		Map<String, Integer> map=new HashMap<String, Integer>();
		map.put("startnum", startnum);
		map.put("endnum", endnum);
		
		List<MessageDTO> receiveMsgListFromShop=sqlMap.selectList("receiveMsgListFromShop", map);
		
		return receiveMsgListFromShop;
	}
	
	//관리자 페이지 - 회원에게 보낸 메세지 목록보기
	public List<MessageDTO> sendMsgListToMember(int cp,int ls) {
		
		int startnum=(cp-1)*ls+1;
		int endnum=cp*ls;
		
		Map<String, Integer> map=new HashMap<String, Integer>();
		map.put("startnum", startnum);
		map.put("endnum", endnum);
		
		List<MessageDTO> sendMsgListToMember=sqlMap.selectList("sendMsgListToMember", map);
		
		return sendMsgListToMember;
	}
	
	//관리자 페이지 - 기업에게 보낸 메세지 목록보기
	public List<MessageDTO> sendMsgListToShop(int cp,int ls) {
		
		int startnum=(cp-1)*ls+1;
		int endnum=cp*ls;
		
		Map<String, Integer> map=new HashMap<String, Integer>();
		map.put("startnum", startnum);
		map.put("endnum", endnum);
		
		List<MessageDTO> sendMsgListToShop=sqlMap.selectList("sendMsgListToShop", map);
		
		return sendMsgListToShop;
	}
	
	//관리자 페이지 - 삭제된 메세지 목록보기
	public List<MessageDTO> deleteMsgList(int cp,int ls) {
		
		int startnum=(cp-1)*ls+1;
		int endnum=cp*ls;
		
		Map<String, Integer> map=new HashMap<String, Integer>();
		map.put("startnum", startnum);
		map.put("endnum", endnum);
		
		List<MessageDTO> deleteMsgList=sqlMap.selectList("deleteMsgList", map);
		
		return deleteMsgList;
	}
	
	//관리자 페이지 - 기업에게 받은 메세지 내용보기
	public List<MessageDTO> checkMsgContentFromShop(int message_idx) {
		
		List<MessageDTO> checkMsg=sqlMap.selectList("checkMsgContentFromShop", message_idx);
		
		return checkMsg;
	}
	
	//관리자 페이지 - 회원에게 답장하기
	public int sendReply(int message_idx, String message_content) {
			
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("message_idx", message_idx);
		map.put("message_content", message_content);
			
		int count=sqlMap.insert("sendReply", map);
			
		return count;
	}
	
	//관리자 페이지 - 회원에게 보낸 메세지 내용보기
	public List<MessageDTO> checkMsgContentToMember(int message_idx) {
		
		List<MessageDTO> checkMsg=sqlMap.selectList("checkMsgContentToMember", message_idx);
		
		return checkMsg;
	}
	
	//관리자 페이지 - 기업에게 보낸 메세지 내용보기
	public List<MessageDTO> checkMsgContentToShop(int message_idx) {
		
		List<MessageDTO> checkMsg=sqlMap.selectList("checkMsgContentToShop", message_idx);
		
		return checkMsg;
	}
	
	//관리자 페이지 - 휴지통에 있는 메세지 내용보기
	public List<MessageDTO> checkMsgContentFromDelete(int message_idx) {
		
		List<MessageDTO> checkMsg=sqlMap.selectList("checkMsgContentFromDelete", message_idx);
		
		return checkMsg;
	}
	
	//관리자 페이지 - 메세지 상태 바꾸기(읽음)
	public int makeMsgRead(int message_idx) {
		
		int count=sqlMap.update("makeMsgRead", message_idx);
		
		return count;
	}
	
	//관리자 페이지 - 메세지 상태 바꾸기(삭제)
	public int makeMsgDelete(int message_idx) {
		
		int count=sqlMap.update("makeMsgDelete", message_idx);
		
		return count;
	}
	
	//관리자 페이지 - 메세지 상태 바꾸기(삭제취소)
	public int makeMsgNormal(int message_idx) {
		
		int count=sqlMap.update("makeMsgNormal", message_idx);
		
		return count;
	}
	
	//관리자 페이지 - 메세지 영구삭제하기
	public int makeMsgPermanentlyDelete(int message_idx) {
		
		int count=sqlMap.update("makeMsgPermanentlyDelete", message_idx);
		
		return count;
	}

	public int member_hairshop_masage(int hairshop_idx, int member_idx, String content) {
	    Map<String, Object> map=new HashMap<String, Object>();
	    map.put("hairshop_idx", hairshop_idx);
		map.put("member_idx", member_idx);
	    map.put("content", content);
		return sqlMap.insert("member_hairshop_masage",map);
    }
}

















