package hair.message.model;

import java.sql.Date;

import hair.hairshop.model.HairShopDTO;
import hair.member.model.MemberDTO;

public class MessageDTO {

	private int message_idx;
	private int sender_idx;
	private int receiver_idx;
	private String message_content;
	private Date send_date;
	private int message_state;
	
	private MemberDTO memberDto;
	private HairShopDTO hairshopDto;
	
	public MessageDTO() {
		super();
	}

	public MessageDTO(int message_idx, int sender_idx, int receiver_idx, String message_content, Date send_date,
			int message_state) {
		super();
		this.message_idx = message_idx;
		this.sender_idx = sender_idx;
		this.receiver_idx = receiver_idx;
		this.message_content = message_content;
		this.send_date = send_date;
		this.message_state = message_state;
	}

	public int getMessage_idx() {
		return message_idx;
	}

	public void setMessage_idx(int message_idx) {
		this.message_idx = message_idx;
	}

	public int getSender_idx() {
		return sender_idx;
	}

	public void setSender_idx(int sender_idx) {
		this.sender_idx = sender_idx;
	}

	public int getReceiver_idx() {
		return receiver_idx;
	}

	public void setReceiver_idx(int receiver_idx) {
		this.receiver_idx = receiver_idx;
	}

	public String getMessage_content() {
		return message_content;
	}

	public void setMessage_content(String message_content) {
		this.message_content = message_content;
	}

	public Date getSend_date() {
		return send_date;
	}

	public void setSend_date(Date send_date) {
		this.send_date = send_date;
	}

	public int getMessage_state() {
		return message_state;
	}

	public void setMessage_state(int message_state) {
		this.message_state = message_state;
	}

	public MemberDTO getMemberDto() {
		return memberDto;
	}

	public void setMemberDto(MemberDTO memberDto) {
		this.memberDto = memberDto;
	}

	public HairShopDTO getHairshopDto() {
		return hairshopDto;
	}

	public void setHairshopDto(HairShopDTO hairshopDto) {
		this.hairshopDto = hairshopDto;
	}
}
