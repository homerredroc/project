package hair.message.model;

import java.util.List;

public interface MessageDAO {
	
	//관리자 페이지 - 기업에게 받은 메세지 totalCnt
	public int receiveMsgFromShop_totalCnt();
	
	//관리자 페이지 - 회원에게 보낸 메세지 totalCnt
	public int sendMsgToMember_totalCnt();
	
	//관리자 페이지 - 기업에게 보낸 메세지 totalCnt
	public int sendMsgToShop_totalCnt();
	
	//관리자 페이지 - 삭제한 메세지 totalCnt
	public int deleteMsg_totalCnt();

	//관리자 페이지 - 개인 전체 메세지 보내기
	public int admin_msgSendMember(String message_content,String select);
	
	//관리자 페이지 - 기업 전체 메세지 보내기
	public int admin_msgSendShop(String message_content,String select);
	
	//관리자 페이지 - 선택한 개인회원에게 메세지 보내기
	public int admin_eachMemberMsgSend(String message_content,String members_id);
	
	//관리자 페이지 - 선택한 기업회원에게 메세지 보내기
	public int admin_eachHairshopMsgSend(String message_content,String hairshops_id);
	
	//관리자 페이지 - 기업에게 받은 메세지 목록보기
	public List<MessageDTO> receiveMsgListFromShop(int cp,int ls);
	
	//관리자 페이지 - 회원에게 보낸 메세지 목록보기
	public List<MessageDTO> sendMsgListToMember(int cp,int ls);
	
	//관리자 페이지 - 기업에게 보낸 메세지 목록보기
	public List<MessageDTO> sendMsgListToShop(int cp,int ls);
	
	//관리자 페이지 - 삭제된 메세지 목록보기
	public List<MessageDTO> deleteMsgList(int cp,int ls);
	
	//관리자 페이지 - 기업에게 받은 메세지 내용보기
	public List<MessageDTO> checkMsgContentFromShop(int message_idx);
	
	//관리자 페이지 - 답장하기
	public int sendReply(int message_idx,String message_content);
	
	//관리자 페이지 - 회원에게 보낸 메세지 내용보기
	public List<MessageDTO> checkMsgContentToMember(int message_idx);
	
	//관리자 페이지 - 기업에게 보낸 메세지 내용보기
	public List<MessageDTO> checkMsgContentToShop(int message_idx);
	
	//관리자 페이지 - 휴지통에 있는 메세지 내용보기
	public List<MessageDTO> checkMsgContentFromDelete(int message_idx);
	
	//관리자 페이지 - 메세지 상태 바꾸기(읽음)
	public int makeMsgRead(int message_idx);
	
	//관리자 페이지 - 메세지 상태 바꾸기(삭제)
	public int makeMsgDelete(int message_idx);
	
	//관리자 페이지 - 메세지 상태 바꾸기(삭제취소)
	public int makeMsgNormal(int message_idx);
	
	//관리자 페이지 - 메세지 영구삭제하기
	public int makeMsgPermanentlyDelete(int message_idx);
	public int member_hairshop_masage(int hairshop_idx, int member_idx, String content);
}
