package hair.hair.model;

public class HairListDTO {

	private int hair_idx;
	private int designer_idx;
	
	
	public HairListDTO() {
		super();
	}
	public HairListDTO(int hair_idx, int designer_idx) {
		super();
		this.hair_idx = hair_idx;
		this.designer_idx = designer_idx;
	}
	public int getHair_idx() {
		return hair_idx;
	}
	public void setHair_idx(int hair_idx) {
		this.hair_idx = hair_idx;
	}
	public int getDesigner_idx() {
		return designer_idx;
	}
	public void setDesigner_idx(int designer_idx) {
		this.designer_idx = designer_idx;
	}
	
	
	
}
