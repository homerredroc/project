package hair.hair.model;
import java.util.*;
public interface HairDAO {

	//헤어 등록 
	public int hair_reg(HairDTO dto);
	
	//디자이너가 등록하지 않은 헤어 리스트 출력
	public List<HairDTO> hair_list(int hairshop_idx,int designer_idx);
	//디자이너 헤어 등록
	public int desig_hair_reg(HairListDTO dto);
	//헤어샵 헤어 리스트 출력
	public List<HairDTO> shop_hair_list(int hairshop_idx);
	//추가 부분
	
	public HairDTO HairInfo(int Hair_idx);
	
	
	public int hairoptionprice(int hairshop_idx);
	
	public List<HairDTO> hair_reg_list(int designer_idx);
	
	
	public HairOptionDTO hairoption_select(int hairshop_idx);
	
	public int hairoption_reg(HairOptionDTO dto);
	
	public int hairoption_update(HairOptionDTO dto);
	
	
	
	
	
	
}
