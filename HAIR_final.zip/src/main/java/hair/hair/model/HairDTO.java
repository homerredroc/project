package hair.hair.model;

public class HairDTO {

	private int hair_idx;
	private int hair_sex;
	private String hair_style;			
	private int hair_price;
	private String hair_etc;
	private int hairshop_idx;			
	private int hair_option;
		
	public HairDTO()
	{
	}



	public HairDTO(int hair_idx, int hair_sex, String hair_style, int hair_price, String hair_etc, int hairshop_idx,
			int hair_option) {
		super();
		this.hair_idx = hair_idx;
		this.hair_sex = hair_sex;
		this.hair_style = hair_style;
		this.hair_price = hair_price;
		this.hair_etc = hair_etc;
		this.hairshop_idx = hairshop_idx;
		this.hair_option = hair_option;
	}



	public String getHair_etc() {
		return hair_etc;
	}



	public void setHair_etc(String hair_etc) {
		this.hair_etc = hair_etc;
	}



	public int getHair_idx() {
		return hair_idx;
	}

	public void setHair_idx(int hair_idx) {
		this.hair_idx = hair_idx;
	}

	public int getHair_sex() {
		return hair_sex;
	}

	public void setHair_sex(int hair_sex) {
		this.hair_sex = hair_sex;
	}

	public String getHair_style() {
		return hair_style;
	}

	public void setHair_style(String hair_style) {
		this.hair_style = hair_style;
	}

	public int getHair_price() {
		return hair_price;
	}

	public void setHair_price(int hair_price) {
		this.hair_price = hair_price;
	}

	public int getHairshop_idx() {
		return hairshop_idx;
	}

	public void setHairshop_idx(int hairshop_idx) {
		this.hairshop_idx = hairshop_idx;
	}

	public int getHair_option() {
		return hair_option;
	}

	public void setHair_option(int hair_option) {
		this.hair_option = hair_option;
	}			

	
	
}
