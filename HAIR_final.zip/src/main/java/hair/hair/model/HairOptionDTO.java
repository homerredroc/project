package hair.hair.model;

public class HairOptionDTO {

	private int hairshop_idx;
	private int shorth;
	private int middleh;
	private int longh;
	
	public HairOptionDTO() {
		super();
	}

	public HairOptionDTO(int hairshop_idx, int shorth, int middleh, int longh) {
		super();
		this.hairshop_idx = hairshop_idx;
		this.shorth = shorth;
		this.middleh = middleh;
		this.longh = longh;
	}

	public int getHairshop_idx() {
		return hairshop_idx;
	}

	public void setHairshop_idx(int hairshop_idx) {
		this.hairshop_idx = hairshop_idx;
	}

	public int getShorth() {
		return shorth;
	}

	public void setShorth(int shorth) {
		this.shorth = shorth;
	}

	public int getMiddleh() {
		return middleh;
	}

	public void setMiddleh(int middleh) {
		this.middleh = middleh;
	}

	public int getLongh() {
		return longh;
	}

	public void setLongh(int longh) {
		this.longh = longh;
	}
	
	
}
