package hair.hair.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
public class HairDAOImple implements HairDAO {


	private SqlSessionTemplate sqlMap;

	public HairDAOImple(SqlSessionTemplate sqlMap) {
		this.sqlMap = sqlMap;
	}
	//헤어 등록 
	public int hair_reg(HairDTO dto)
	{
		int result = sqlMap.insert("shop_hair_reg", dto);
		return result;
	}
	
//추가부분
	public HairDTO HairInfo(int Hair_idx) {
		HairDTO dto = sqlMap.selectOne("hairInfo",Hair_idx);
		return dto;
	}
	
	//디자이너가 등록하지 않은 헤어 리스트 출력
	public List<HairDTO> hair_list(int hairshop_idx,int designer_idx) {
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		map.put("hairshop_idx", hairshop_idx);
		map.put("designer_idx",designer_idx);
		List<HairDTO> list = sqlMap.selectList("desig_not_reg_hair_list",map);
		return list;
	}
	
	
	//디자이너 헤어 등록
	public int desig_hair_reg(HairListDTO dto) {
		int result = sqlMap.insert("desig_hair_reg",dto);
		return result;
	}
	 //헤어샵에 등록된 헤어 리스트 출력
	public List<HairDTO> shop_hair_list(int hairshop_idx) {
		List<HairDTO> list  = sqlMap.selectList("shop_hair_list", hairshop_idx);
		return list;
	}
	
	
	
	public int hairoptionprice(int hairshop_idx) {
		HairOptionDTO dto= sqlMap.selectOne("hairoption",40);	
	
			return 0;
		
		
	}
	public List<HairDTO> hair_reg_list(int designer_idx) {

		List<HairDTO> list = sqlMap.selectList("designer_reg_hair_list", designer_idx);
		return list;
	}
	
	//헤어옵션 검색
	public HairOptionDTO hairoption_select(int hairshop_idx) {
		HairOptionDTO dto = sqlMap.selectOne("hairoption",hairshop_idx);
		return dto;
	}
	//등록
	public int hairoption_reg(HairOptionDTO dto) {
		int result = sqlMap.insert("hairoption_reg", dto);
		return result;
	}
	public int hairoption_update(HairOptionDTO dto) {
		int result = sqlMap.update("hairoption_update", dto);
		return result;
	}
	

}
