package hair.hair.model;

import java.util.List;

public interface HairListDAO {
	public List<HairDTO> hair_list(int designer_idx);
}
