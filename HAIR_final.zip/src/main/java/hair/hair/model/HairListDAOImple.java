package hair.hair.model;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;

public class HairListDAOImple implements HairListDAO {

	private SqlSessionTemplate sqlMap;

	public HairListDAOImple(SqlSessionTemplate sqlMap) {
		super();
		this.sqlMap = sqlMap;
	}
	
	/**
	 * 헤어샵 글쓰기시 헤어리스트 불러오는 메서드
	 * @param designer_idx 가져올 디자이너의idx
	 */
	public List<HairDTO> hair_list(int designer_idx) {
	    List<HairDTO> list = sqlMap.selectList("hair_list",designer_idx);
	    return list;
	}

}
