package hair.module;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import hair.hairshop.designer.model.DesignerDTO;
import hair.hairshop.model.HairShopDTO;

public class Timelist {

	public static List<String> timelist(HairShopDTO dto) {
		String [] hairshop_open = dto.getHairshop_open().split("-");
		
		String date_pattern = "1000-01-01T";

		List<String> timelist = new ArrayList<String>();
		LocalDateTime opentime = LocalDateTime.parse(date_pattern + hairshop_open[0]);
		LocalDateTime closetime = LocalDateTime.parse(date_pattern + hairshop_open[1]);
		System.out.println(opentime);
		while (!opentime.isEqual(closetime)) {
			String time;
			String hour;
			String minu;
			if (opentime.getMinute() / 10 == 0)
				minu = ":0" + opentime.getMinute();
			else
				minu = ":" + opentime.getMinute();

			if (opentime.getHour() / 10 == 0)
				hour = "0" + opentime.getHour();
			else
				hour = "" + opentime.getHour();
			time = hour + minu;
			timelist.add(time);
			opentime = opentime.plusMinutes(30);
		}

		return timelist;
	}

	public static Map<Integer, Object> schedule_list(List<DesignerDTO> list, LocalDateTime now, List<String> timelist ,HairShopDTO dto) {
		Map<Integer, Object> desig_map = new HashMap<Integer, Object>();
		List<Object> desig_list;
		String[] day = { "월", "화", "수", "목", "금", "토", "일" };
		List<Integer> schedule_list;
		for (int i = 0; i < list.size(); i++) {
			desig_list = new ArrayList<Object>();
			schedule_list = new ArrayList<Integer>();

	
			System.out.println("헤어샵 쉬는요일"+dto.getHairshop_off() +dto.getHairshop_off().equals(day[now.getDayOfWeek().getValue() - 1]));
			if ((!dto.getHairshop_off().equals(day[now.getDayOfWeek().getValue() - 1]))&&(list.get(i).getSchedules().isEmpty() && !list.get(i).getDesigner_off().equals(day[now.getDayOfWeek().getValue() - 1]))
			|| (!list.get(i).getSchedules().isEmpty() && list.get(i).getSchedules().get(0).getSchedule_state() == 0))
			{
				System.out.println();
					for (int j = 0; j < timelist.size(); j++) // 시간별로 예약 현황 비교
					{
						if (list.get(i).getReservations().isEmpty() || list.get(i).getReservations().size() == 0)// 예약이 없다면
						{
							schedule_list.add(0);
						}
						else
						{
						for (int k = 0; k < list.get(i).getReservations().size(); k++) // 예약 크기만큼 비교
						{
							String date = list.get(i).getReservations().get(k).getReservation_date();
							String[] reser_date = date.split(" ");
	
							if (reser_date[1].equals(timelist.get(j).toString()+":00.0")) {
								System.out.println("들어감");
								schedule_list.add(list.get(i).getReservations().get(k).getReservation_idx());
								break;
							} 
							else if (k == list.get(i).getReservations().size() - 1) {
								schedule_list.add(0);
							}

						}
					}
				}
			} 
			else {
				schedule_list.add(-1);
				desig_list.add(list.get(i));
				desig_list.add(schedule_list);
				desig_map.put(list.get(i).getDesigner_idx(), desig_list);
				continue;
			}
			desig_list.add(list.get(i));
			desig_list.add(schedule_list);
			desig_map.put(list.get(i).getDesigner_idx(), desig_list);
		}
		return desig_map;
	}
}
