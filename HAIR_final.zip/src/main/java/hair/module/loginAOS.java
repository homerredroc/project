package hair.module;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import javax.servlet.http.HttpSession;

import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.web.servlet.ModelAndView;

public class loginAOS {
	

	public Object loginIDSessionChecker(ProceedingJoinPoint joinPoint) throws Throwable {

		String sigString = joinPoint.getSignature().toShortString();

		System.out.println(sigString + " 시작");

		HttpServletRequest request = null;

		HttpServletResponse response = null;
		System.out.println(joinPoint.getArgs().toString());
		ModelAndView mav = new ModelAndView();
		System.out.println("request"+(request==null));
		for (Object object : joinPoint.getArgs()) {
			System.out.println(object.toString());
			if (object instanceof HttpServletRequest) {

				request = (HttpServletRequest) object;
				System.out.println("request"+(request==null));
			}

			if (object instanceof HttpServletResponse) {

				response = (HttpServletResponse) object;
				System.out.println("response"+(response==null));
			}
			System.out.println("request"+(request==null));
		}
		System.out.println("일단 여기까지 실행");
		try {
			System.out.println("일단 여기까지 실행");
			HttpSession session = request.getSession();
			System.out.println("일단 여기까지 실행");
			String loginID = (String) session.getAttribute("member_id");
			System.out.println("일단 여기까지 실행");
			System.out.println("member_id Check: " + loginID);
			System.out.println("일단 여기까지 실행");
			if (loginID == null || loginID.equals("")) {

				mav.setViewName("msg");

				mav.addObject("page_state", "loginForm.do");

				mav.addObject("msg", "로그인을 해야 사용하실 수 있습니다.");

				return mav;

			}

		} catch (Exception e) {
			System.out.println("일단 여기까지 실행ㅁㄴㅇㅁㄴㅇ");
			mav.setViewName("msg");

			mav.addObject("page_state", "loginForm.do");

			mav.addObject("msg", "로그인을 해야 사용하실 수 있습니다.");

			return mav;

		}

		try {

			Object obj = joinPoint.proceed();

			return obj;

		} finally {

			System.out.println(sigString + " 종료");

		}

	}
}
