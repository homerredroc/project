package hair.hairshop.designer.model;

public class Designer_ScheduleDTO {
	private int schedule_idx;
	private String schedule_date;
	private String schedule_time;
	private int designer_idx;
	private int schedule_state;
	
	private DesignerDTO designerDTO;
	
	public DesignerDTO getDesignerDTO() {
		return designerDTO;
	}

	public void setDesignerDTO(DesignerDTO designerDTO) {
		this.designerDTO = designerDTO;
	}

	public Designer_ScheduleDTO() {
		super();
	}

	public Designer_ScheduleDTO(int schedule_idx, String schedule_date, String schedule_time, int designer_idx,
			int schedule_state) {
		super();
		this.schedule_idx = schedule_idx;
		this.schedule_date = schedule_date;
		this.schedule_time = schedule_time;
		this.designer_idx = designer_idx;
		this.schedule_state = schedule_state;
	}



	public int getSchedule_idx() {
		return schedule_idx;
	}



	public void setSchedule_idx(int schedule_idx) {
		this.schedule_idx = schedule_idx;
	}



	public String getSchedule_date() {
		return schedule_date;
	}



	public void setSchedule_date(String schedule_date) {
		this.schedule_date = schedule_date;
	}



	public String getSchedule_time() {
		return schedule_time;
	}



	public void setSchedule_time(String schedule_time) {
		this.schedule_time = schedule_time;
	}



	public int getDesigner_idx() {
		return designer_idx;
	}



	public void setDesigner_idx(int designer_idx) {
		this.designer_idx = designer_idx;
	}



	public int getSchedule_state() {
		return schedule_state;
	}



	public void setSchedule_state(int schedule_state) {
		this.schedule_state = schedule_state;
	}
	
	
	
}
