package hair.hairshop.designer.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;

import hair.hair.model.HairListDTO;

public class DesignerDAOImple implements DesignerDAO {

	SqlSessionTemplate sqlMap;
	
	public DesignerDAOImple(SqlSessionTemplate sqlMap) {
		super();
		this.sqlMap = sqlMap;
	}

	public List<DesignerDTO> desig_list(int hairshop_idx) {
		List<DesignerDTO> list = sqlMap.selectList("hairshop_desig_list", hairshop_idx);
		return list;
	}
	
	public int desig_schedule_reg(Designer_ScheduleDTO dto) {
		int count = sqlMap.insert("designer_on_off_reg", dto);
		return count;
	}
	
	public List<Designer_ScheduleDTO> desig_onoff_list(int hairshop_idx ,String date) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("hairshop_idx",hairshop_idx);
		map.put("nowdate",date);
		List<Designer_ScheduleDTO> list = sqlMap.selectList("hairshop_onoff_list", map);
		return list;
	}
	public int desig_schedule_delete(int schedule_idx) {
		int count = sqlMap.delete("desig_onoff_delete", schedule_idx);
		return count;
	}
	
	public List<DesignerDTO> desig_schedule_list_ajax(int hairshop_idx, String date) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("hairshop_idx",hairshop_idx);
		map.put("nowdate",date);		
		List<DesignerDTO> list = sqlMap.selectList("desig_schedule_lists", map);
		return list;
	}
	
	

	/**
	 * 헤어샵 글쓰기시 디자이너리스트 불러오는 메서드
	 * @param hairshop_idx 가져올 헤어샵의 idx
	 */
	/*
	public List<DesignerDTO> desig_list(int hairshop_idx){
		List<DesignerDTO> list = sqlMap.selectList("designer_list", hairshop_idx);
		return list;
	}
*/
	/**
	 * 디자이너의 정보를 가져오는 메서드
	 * @param designer_idx 가져올 디자이너의 idx
	 */	
	
	public DesignerDTO designerInfo(int designer_idx) {
		DesignerDTO dto = sqlMap.selectOne("designerInfo",designer_idx);
		return dto;
	}
	

	//디자이너 등록하기
		public int addDesigner(DesignerDTO designerDto) {
			int count = sqlMap.insert("addDesigner", designerDto);
			return count;
		}
//		//디자이너 정보 불러오기
//		public List<DesignerDTO> designerInfo(int designer_idx) {
//			List<DesignerDTO> info = sqlMap.selectList("designerInfo", designer_idx);
//			return info;
//		}
		//디자이너 삭제하기
		public int deleteDesigner(int designer_idx) {
			int count = sqlMap.delete("deleteDesigner", designer_idx);
			return count;
		}
		//디자이너 정보 불러오기
		public List<DesignerDTO> designerList(int hairshop_idx) {
			
			List<DesignerDTO> list = sqlMap.selectList("designerList",hairshop_idx);
			return list;
		}
		
		//디자이너 정보 수정하기
		public int updateDesignerInfo(DesignerDTO designerDto) {
			int result = sqlMap.update("updateDesigner", designerDto);
			System.out.println(result);
			return result;
		}
		
		//디자이너가 가능한헤어스타일 넣기
		public int designerAddHairstyle(HairListDTO hairListDto) {
			int count = sqlMap.insert("hairshop_designerAddStyle", hairListDto);
			return count;
		}
	
	

	
}
