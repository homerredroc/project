package hair.hairshop.designer.model;

import java.util.*;

import hair.hair.model.HairListDTO;
public interface DesignerDAO {

	public List<DesignerDTO> desig_list(int hairshop_idx);
	
	public List<DesignerDTO> desig_schedule_list_ajax(int hairshop_idx, String date);
	
	public int desig_schedule_reg(Designer_ScheduleDTO dto);
	
	public List<Designer_ScheduleDTO> desig_onoff_list(int hairshop_idx ,String date);
	
	
	public int desig_schedule_delete(int schedule_idx);
	
     //public List<DesignerDTO> desig_list(int hairshop_idx);
	
	public DesignerDTO designerInfo(int designer_idx);
	
	
	//////////////////////////////////////////////

	public int addDesigner(DesignerDTO designerDto);
	
	/** 헤어샵의 디자이너 삭제 관련메서드
	 * 구현페이지: hairshop_del_designer.jsp*/
	public int deleteDesigner(int designer_idx);
	
	/** 디자이너 리스트 불러오기 관련 메서드
	 *구현페이지 : hairshop_designer.jsp*/
	public List<DesignerDTO> designerList(int hairshop_idx);
	
	/***/
	public int designerAddHairstyle(HairListDTO hairListDto);
	
	/**디자이너 정보 불러오기 관련 메서드*/
	//public List<DesignerDTO> designerInfo(int designer_idx);
	
	/**디자이너 정보 수정하기*/
	public int updateDesignerInfo(DesignerDTO designerDto);
	
	
	
}
