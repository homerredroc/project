package hair.hairshop.designer.model;

import java.util.List;

import hair.reservation.model.ReservationDTO;

public class DesignerDTO {

	private int designer_idx;
	private String designer_name;
	private String designer_photo;
	private int designer_career;
	private String designer_info ;
	private String designer_off;
	private int hairshop_idx;

	private List<Designer_ScheduleDTO> schedules;
	private List<ReservationDTO> reservations;
	
	public DesignerDTO() {
	
	}
	
	public List<ReservationDTO> getReservations() {
		return reservations;
	}



	public void setReservations(List<ReservationDTO> reservations) {
		this.reservations = reservations;
	}



	public List<Designer_ScheduleDTO> getSchedules() {
		return schedules;
	}

	public void setSchedules(List<Designer_ScheduleDTO> schedules) {
		this.schedules = schedules;
	}




	public DesignerDTO(int designer_idx, String designer_name, String designer_photo, int designer_career,
			String designer_info, String designer_off, int hairshop_idx) {
		super();
		this.designer_idx = designer_idx;
		this.designer_name = designer_name;
		this.designer_photo = designer_photo;
		this.designer_career = designer_career;
		this.designer_info = designer_info;
		this.designer_off = designer_off;
		this.hairshop_idx = hairshop_idx;
	}



	public String getDesigner_name() {
		return designer_name;
	}


	public void setDesigner_name(String designer_name) {
		this.designer_name = designer_name;
	}



	public String getDesigner_photo() {
		return designer_photo;
	}





	public void setDesigner_photo(String designer_photo) {
		this.designer_photo = designer_photo;
	}





	public int getDesigner_idx() {
		return designer_idx;
	}


	public void setDesigner_idx(int designer_idx) {
		this.designer_idx = designer_idx;
	}




	public int getDesigner_career() {
		return designer_career;
	}


	public void setDesigner_career(int designer_career) {
		this.designer_career = designer_career;
	}


	public String getDesigner_info() {
		return designer_info;
	}


	public void setDesigner_info(String designer_info) {
		this.designer_info = designer_info;
	}


	public String getDesigner_off() {
		return designer_off;
	}


	public void setDesigner_off(String designer_off) {
		this.designer_off = designer_off;
	}


	public int getHairshop_idx() {
		return hairshop_idx;
	}


	public void setHairshop_idx(int hairshop_idx) {
		this.hairshop_idx = hairshop_idx;
	}
    
	
}
