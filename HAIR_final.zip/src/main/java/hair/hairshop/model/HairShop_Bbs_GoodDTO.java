package hair.hairshop.model;

public class HairShop_Bbs_GoodDTO {

	private int hairshop_bbs_idx;
	private int member_idx;
	
	public HairShop_Bbs_GoodDTO() {
		super();
	}

	public HairShop_Bbs_GoodDTO(int hairshop_bbs_idx, int member_idx) {
		super();
		this.hairshop_bbs_idx = hairshop_bbs_idx;
		this.member_idx = member_idx;
	}

	public int getHairshop_bbs_idx() {
		return hairshop_bbs_idx;
	}

	public void setHairshop_bbs_idx(int hairshop_bbs_idx) {
		this.hairshop_bbs_idx = hairshop_bbs_idx;
	}

	public int getMember_idx() {
		return member_idx;
	}

	public void setMember_idx(int member_idx) {
		this.member_idx = member_idx;
	}
}
