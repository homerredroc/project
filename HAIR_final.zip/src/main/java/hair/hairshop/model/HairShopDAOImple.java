package hair.hairshop.model;

import java.util.*;

import org.mybatis.spring.SqlSessionTemplate;

import hair.hair.model.HairDTO;
import hair.member.model.MemberDTO;
import hair.member.model.Member_ReviewDTO;
import hair.message.model.MessageDTO;
import hair.reservation.model.ReservationDTO;
import hair.spon.model.SponDTO;

public class HairShopDAOImple implements HairShopDAO {
	private SqlSessionTemplate sqlMap;

	public HairShopDAOImple(SqlSessionTemplate sqlMap) {
		super();
		this.sqlMap = sqlMap;
	}

	//받은 메세지 페이징
	public int hairshop_receiveMessageTotalCnt(int hairshop_idx) {
		
		int count=sqlMap.selectOne("hairshop_receiveMessageTotalCnt", hairshop_idx);
		
		return count;
	}
	
	//보낸 메세지 페이징
	public int hairshop_sendMessageTotalCnt(int hairshop_idx) {
		
		int count=sqlMap.selectOne("hairshop_sendMessageTotalCnt", hairshop_idx);
		
		return count;
	}
	
	//예약 회원 페이징
	public int hairshopMember_TotalCnt(int hairshop_idx) {
		
		int count=sqlMap.selectOne("hairshopMember_TotalCnt", hairshop_idx);
		
		return count;
	}

	/**
	 * 헤어샵의 정보를 가져오는 메서드
	 * @param hairshop_idx 가져올 헤어샵의 idx
	 */
	public HairShopDTO hairhsopInfo(int hairshop_idx) {
		HairShopDTO dto = sqlMap.selectOne("hairshopInfo",hairshop_idx);
		return dto;
	}

	
	/**
	 * 헤어샵 검색시 글의 개수를 가져오는 메서드
	 * @param search_option 어떤 검색을 했는 지 알기 위해
	 * @param search_value 어떤 키워드로 검색을 했는지
	 */	
	public int hairshop_totalcnt(String search_option, String search_value) {
		HashMap<String, Object> hm = new HashMap<String, Object>();

		hm.put("search_option", "hairshop_"+search_option);
		hm.put("search_value", search_value);
		System.out.println(sqlMap.selectOne("hairshop_totalcnt",hm));
		return sqlMap.selectOne("hairshop_totalcnt",hm);
	}	

	
	/**
	 * 헤어샵검색시 정보를 가져오는 메서드
	 * @param cp 사용자의 현재 위치
	 * @param ls 불러올 글들의 사이즈
	 * @param search_option 어떤 검색을 했는 지 알기 위해
	 * @param search_value 어떤 키워드로 검색을 했는지
	 * @param order 어떤 정렬을 했는지
	 */	
	public List<HairShop_BbsDTO> hairshop_list(int cp, int ls, String search_option, String search_value, String order) {
		HashMap<String, Object> hm = new HashMap<String, Object>();
		List<HairShop_BbsDTO> list=null;
		int startnum=(cp-1)*ls+1;
		int endnum=cp*ls;
		String fm="";
		hm.put("startnum", startnum);
		hm.put("endnum", endnum);
		hm.put("search_option", "hairshop_"+search_option);
		hm.put("search_value", search_value);
		if(order.equals("")) {
			list= sqlMap.selectList("hairshop_list", hm);				
		}else if(order.equals("reservation")) {
			order="reservation";
			hm.put("fn", "count(*)");
			hm.put("order",order);
			list= sqlMap.selectList("hairshop_list_order", hm);	
		}else if(order.equals("favorite")) {
			order="FAVORITE_HAIRSHOP";
			hm.put("fn", "count(*)");
			hm.put("order",order);
			list= sqlMap.selectList("hairshop_list_order", hm);
		}else if(order.equals("grade")) {
			order="MEMBER_REVIEW";
			hm.put("fn", "AVG(MEMBER_REVIEW_GRADE)");
			hm.put("order",order);
			list= sqlMap.selectList("hairshop_list_order", hm);
		}
		return list;
	}
	
	/**
	 * 헤어샵 지도검색 데이터를 불러오는 메서드
	 * @param hairshop_addr 그 위치의 헤어샵을 가져오기 위한 주소
	 */	
	public List<HairShopDTO> hairshop_map_saerch(String hairshop_addr) {
		HashMap<String, String> hm = new HashMap<String, String>();
		hm.put("hairshop_addr", hairshop_addr);
		List<HairShopDTO> list=sqlMap.selectList("hairshop_map_search",hm);
		return list;
	}
	

	
	/*기업 회원가입*/
	public int hairshop_join_submit(HairShopDTO hsdto) {
		int count = sqlMap.insert("hairshop_join", hsdto);
		return count;
	}
	/*기업 회원가입 아이디 중복확인*/
	public boolean hairshop_join_idCheck(String hairshop_id) {
		
		String idCheck = sqlMap.selectOne("hairshop_join_idCheck", hairshop_id);
		
		boolean result = false; /*초기화*/
		
		if(idCheck==null||idCheck.equals("")) {
			result = true; /*아디중복아님*/
		}else{
			result = false; /*아디중복임*/
		}
		return result;
	}

	/*기업 아이디 찾기*/
	public List<HairShopDTO> hairshop_search_id_submit(String hairshop_ceo, String hairshop_email, String hairshop_name) {
		
		HashMap hm = new HashMap();
		hm.put("hairshop_ceo", hairshop_ceo);
		hm.put("hairshop_email", hairshop_email);
		hm.put("hairshop_name", hairshop_name);
		
		
		List<HairShopDTO> search_id_list = sqlMap.selectList("hairshop_search_id", hm);
		return search_id_list;
	}
	/*기업 비밀번호 찾기*/
	public List<HairShopDTO> hairshop_search_pwd_submit(String hairshop_id, String hairshop_ceo, String hairshop_email){
		
		HashMap hm = new HashMap();
		hm.put("hairshop_id", hairshop_id);
		hm.put("hairshop_ceo", hairshop_ceo);
		hm.put("hairshop_email", hairshop_email);
		
		List<HairShopDTO> search_pwd_list = sqlMap.selectList("hairshop_search_pwd", hm);
		return search_pwd_list;
	}
	/*찾은 비밀번호 다음 바로 업데이트로 비밀번호 바꾸기*/
	public int hairshop_pwd_update(String hairshop_idx, String hairshop_pwd) {
		
		HashMap hm = new HashMap();
		hm.put("hairshop_idx", hairshop_idx);
		hm.put("hairshop_pwd", hairshop_pwd);
		
		int count = sqlMap.update("hairshop_pwd_update", hm);
		return count;
	}
	///////////////////////////////////////////관리자 //////////////////////////////////////////////
	//관리자 페이지 - 가입 승인 전 기업 totalCnt
		public int beforeHairshopTotalCnt() {
			
			int count=sqlMap.selectOne("beforeHairshopTotalCnt");
			
			return count;
		}
		
		//관리자 페이지 - 가입 승인 기업 totalCnt
		public int joinHairshopTotalCnt() {
			
			int count=sqlMap.selectOne("joinHairshopTotalCnt");
			
			return count;
		}
		
		//관리자 페이지 - 가입 미승인 기업 totalCnt
		public int rejectHairshopTotalCnt() {
			
			int count=sqlMap.selectOne("rejectHairshopTotalCnt");
			
			return count;
		}
		
		//관리자 페이지 - 블랙 기업 totalCnt
		public int blackHairshopTotalCnt() {
			
			int count=sqlMap.selectOne("blackHairshopTotalCnt");
			
			return count;
		}
		
		//관리자 페이지 - 탈퇴 기업 totalCnt
		public int outHairshopTotalCnt() {
			
			int count=sqlMap.selectOne("outHairshopTotalCnt");
			
			return count;
		}
		
		//관리자 페이지 - 가입 승인 전 기업목록 보기
		public List<HairShopDTO> beforeHairshopList(int cp,int ls) {
			
			int startnum=(cp-1)*ls+1;
			int endnum=cp*ls;
			
			Map<String, Integer> map=new HashMap<String, Integer>();
			map.put("startnum", startnum);
			map.put("endnum", endnum);
			
			List<HairShopDTO> list=sqlMap.selectList("beforeHairshopList", map);
			
			return list;
		}
		
		//관리자 페이지 - 가입 승인 전 기업 상세정보 보기
		public HairShopDTO hairshopInfo(int hairshop_idx) {
			
			HairShopDTO dto=sqlMap.selectOne("hairshopInfo", hairshop_idx);
			
			return dto;
		}
		
		//관리자 페이지 - 가입 승인시키기
		public int makeHairshopJoin(String hairshops_id,int hairshop_idx) {
			
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("hairshops_id", hairshops_id);
			map.put("hairshop_idx", hairshop_idx);
			
			int count=sqlMap.update("makeHairshopJoin", map);
			
			return count;
		}
		
		//관리자 페이지 - 가입 승인 기업목록 보기
		public List<HairShopDTO> joinHairshopList(int cp,int ls) {
			
			int startnum=(cp-1)*ls+1;
			int endnum=cp*ls;
			
			Map<String, Integer> map=new HashMap<String, Integer>();
			map.put("startnum", startnum);
			map.put("endnum", endnum);
			
			List<HairShopDTO> joinList=sqlMap.selectList("joinHairshopList", map);

			return joinList;
		}
		
		//관리자 페이지 - 가입 미 승인시키기
		public int rejectHairshopJoin(String hairshops_id,int hairshop_idx) {
			
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("hairshops_id", hairshops_id);
			map.put("hairshop_idx", hairshop_idx);
			
			int count=sqlMap.update("rejectHairshopJoin", map);
			
			return count;
		}
		
		//관리자 페이지 - 가입 미승인 기업목록 보기
		public List<HairShopDTO> rejectHairshopList(int cp,int ls) {
			
			int startnum=(cp-1)*ls+1;
			int endnum=cp*ls;
			
			Map<String, Integer> map=new HashMap<String, Integer>();
			map.put("startnum", startnum);
			map.put("endnum", endnum);

			List<HairShopDTO> rejectList=sqlMap.selectList("rejectHairshopList", map);
			
			return rejectList;
		}
		
		//관리자 페이지 - 회원 블랙처리하기
		public int makeHairshopBlack(String hairshops_id) {

			int count=sqlMap.update("makeHairshopBlack", hairshops_id);
			
			return count;
		}
		
		//관리자 페이지 - 블랙기업목록 보기
		public List<HairShopDTO> blackHairshopList(int cp,int ls) {
			
			int startnum=(cp-1)*ls+1;
			int endnum=cp*ls;
			
			Map<String, Integer> map=new HashMap<String, Integer>();
			map.put("startnum", startnum);
			map.put("endnum", endnum);

			List<HairShopDTO> blackList=sqlMap.selectList("blackHairshopList", map);
			
			return blackList;
		}
		
		//관리자 페이지 - 회원 탈퇴시키기
		public int makeHairshopOut(String hairshops_id) {

			int count=sqlMap.update("makeHairshopOut", hairshops_id);
			
			return count;
		}
		
		//관리자 페이지 - 탈퇴기업목록 보기
		public List<HairShopDTO> outHairshopList(int cp,int ls) {
			
			int startnum=(cp-1)*ls+1;
			int endnum=cp*ls;
			
			Map<String, Integer> map=new HashMap<String, Integer>();
			map.put("startnum", startnum);
			map.put("endnum", endnum);
			
			List<HairShopDTO> outList=sqlMap.selectList("outHairshopList", map);
			
			return outList;
		}
		
		//관리자 페이지 - 탈퇴,블랙 취소하기
		public int makeHairshopNormal(String hairshops_id) {
			
			int count=sqlMap.update("makeHairshopNormal", hairshops_id);
			
			return count;
		}
		
		//관리자 페이지 - 레벨 바꾸기
		public int setHairshopLevel(String hairshop_level, String hairshops_id) {
			
			Map<String, String> map=new HashMap<String, String>();
			map.put("hairshop_level", hairshop_level);
			map.put("hairshops_id", hairshops_id);
			
			int count=sqlMap.insert("setHairshopLevel", map);
			
			return count;
		}
		
		//관리자 페이지 - 기업 정보 수정하기
		public int updateHairshopInfo(HairShopDTO dto) {
			
			int count=sqlMap.insert("updateHairshopInfo", dto);
			
			return count;
		}
		
		//관리자 페이지 - 회원 검색하기
		public List<HairShopDTO> hairshopSearch(String hairshop_id) {
			
			List<HairShopDTO> list=sqlMap.selectList("hairshopSearch", hairshop_id);
			
			return list;
		}
		
		/***********************************************************************************************************************************************/
		
		//관리자 페이지 - 정상 게시글 totalCnt
		public int normalHairshop_bbsTotalCnt() {
			
			int count=sqlMap.selectOne("normalHairshop_bbsTotalCnt");
			
			return count;
		}
		
		//관리자 페이지 - 비공개 게시글 totalCnt
		public int notOpenHairshop_bbsTotalCnt() {
			
			int count=sqlMap.selectOne("notOpenHairshop_bbsTotalCnt");
			
			return count;
		}
		
		//관리자 페이지 - 삭제 게시글 totalCnt
		public int deleteHairshop_bbsTotalCnt() {
			
			int count=sqlMap.selectOne("deleteHairshop_bbsTotalCnt");
			
			return count;
		}
		
		//관리자 페이지 - 게시글 목록 보기
		public List<HairShop_BbsDTO> hairshop_bbsList(int cp,int ls) {
			
			int startnum=(cp-1)*ls+1;
			int endnum=cp*ls;
			
			Map<String, Integer> map=new HashMap<String, Integer>();
			map.put("startnum", startnum);
			map.put("endnum", endnum);
			
			List<HairShop_BbsDTO> list=sqlMap.selectList("hairshop_bbsList", map);
			
			return list;
		}
		
		//관리자 페이지 - 비공개 게시글 목록 보기
		public List<HairShop_BbsDTO> notOpenHairshop_bbsList(int cp,int ls) {
			
			int startnum=(cp-1)*ls+1;
			int endnum=cp*ls;
			
			Map<String, Integer> map=new HashMap<String, Integer>();
			map.put("startnum", startnum);
			map.put("endnum", endnum);
			
			List<HairShop_BbsDTO> notOpenList=sqlMap.selectList("notOpenHairshop_bbsList", map);
			
			return notOpenList;
		}
		
		//관리자 페이지 - 삭제 게시글 목록 보기
		public List<HairShop_BbsDTO> deleteHairshop_bbsList(int cp,int ls) {
			
			int startnum=(cp-1)*ls+1;
			int endnum=cp*ls;
			
			Map<String, Integer> map=new HashMap<String, Integer>();
			map.put("startnum", startnum);
			map.put("endnum", endnum);
			
			List<HairShop_BbsDTO> deleteList=sqlMap.selectList("deleteHairshop_bbsList", map);
			
			return deleteList;
		}
		
		//관리자 페이지 - 게시글 내용보기
		public HairShop_BbsDTO hairshop_bbsContent(int hairshop_bbs_idx) {
			
			HairShop_BbsDTO dto=sqlMap.selectOne("hairshop_bbsContent", hairshop_bbs_idx);
			
			return dto;
		}
		
		//관리자 페이지 - 게시글 비공개하기
		public int makeBbsNotOpen(int hairshop_bbs_idx) {
			
			int count=sqlMap.update("makeBbsNotOpen", hairshop_bbs_idx);
			
			return count;
		}
		
		//관리자 페이지 - 게시글 삭제하기
		public int makeBbsDelete(int hairshop_bbs_idx) {
			
			int count=sqlMap.update("makeBbsDelete", hairshop_bbs_idx);
			
			return count;
		}
		
		//관리자 페이지 - 게시글 비공개,삭제 취소하기
		public int makeBbsNormal(int hairshop_bbs_idx) {
			
			int count=sqlMap.update("makeBbsNormal", hairshop_bbs_idx);
			
			return count;
		}
		
		//관리자 페이지 - 게시글 검색하기
		public List<HairShop_BbsDTO> bbsSearch(String select, String bbsSearch) {
			
			List<HairShop_BbsDTO> searchList=null;
			
			if(select.equals("작성자")) {
				
				searchList=sqlMap.selectList("bbsSearch_writer", bbsSearch);
				
			}else {
				
				searchList=sqlMap.selectList("bbsSearch_subject", bbsSearch);
			}
			return searchList;
		}
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		//정보확인 전 비번 체크
		public String pwdCheck(String hairshop_id) {
			
			String dbpwd = sqlMap.selectOne("pwd_Check", hairshop_id);
			
			return dbpwd;
		}
		//헤어샵 정보 불러오기
		public List<HairShopDTO> hairshop_info(String hairshop_id) {
			List<HairShopDTO> hairshopInfo = sqlMap.selectList("hairshop_Info", hairshop_id);
			return hairshopInfo;
		}
		public int hairshop_updateInfo(String hairshop_pwd, String hairshop_info, String hairshop_addinfo,
			String hairshop_open, String hairshop_off,String hairshop_id) {
			Map hm = new HashMap();
			hm.put("hairshop_pwd", hairshop_pwd);
			hm.put("hairshop_info", hairshop_info);
			hm.put("hairshop_addinfo", hairshop_addinfo);
			hm.put("hairshop_open", hairshop_open);
			hm.put("hairshop_off", hairshop_off);
			hm.put("hairshop_id", hairshop_id);
			int result = sqlMap.update("hairshop_updateInfo", hm);
			return result;
	}
		
		//회원목록 불러오기
		public List<MemberDTO> hairshop_Member(int hairshop_idx, int cp, int ls) {
			
			int startnum=(cp-1)*ls+1;
		    int endnum=cp*ls;
		      
		    Map<String, Integer> map=new HashMap<String, Integer>();
		    map.put("hairshop_idx", hairshop_idx);
		    map.put("startnum", startnum);
		    map.put("endnum", endnum);
			
			List<MemberDTO> list = sqlMap.selectList("hairshopMember", map);
			return list;
		}
	
		//아이디로 헤어샵_idx가져오기
		public int hairshop_idx(String hairshop_id) {
			
			int result = sqlMap.selectOne("hairshopInfo", hairshop_id);
			return result;
		}
		//헤어샵 스타일리스트 불러오기
		public List<HairDTO> hairshopStyleList(int hairshop_idx) {

			List<HairDTO> list = sqlMap.selectList("hairshop_hairList",hairshop_idx);
			return list;
		}
		
		//메세지보내기
		public int msgToMember(int sender_idx, int receiver_idx, String message_content) {

			Map hm = new HashMap();
			hm.put("hairshop_idx", sender_idx);
			hm.put("member_idx", receiver_idx);
			hm.put("message_content", message_content);
			
			System.out.println( sender_idx +"  "+receiver_idx+"     "+message_content);
			
			int result = sqlMap.insert("msgToMember",hm);
			
			return result;
		}
		//예약회원 불러오기
		public List<ReservationDTO> reservationAllMember(int hairshop_idx) {
			
			List<ReservationDTO> list = sqlMap.selectList("reservationAllMember",hairshop_idx);
			return list;
		}
		//쿠폰 만들기
		public int addCoupon(int hairshop_coupon_discount, int hairshop_idx) {
			Map hm = new HashMap();
			hm.put("hairshop_coupon_discount", hairshop_coupon_discount);
			hm.put("hairshop_idx", hairshop_idx);
			int result = sqlMap.insert("addCoupon", hm);
			return result;
		}
		//쿠폰목록불러오기
		public List<HairShop_CouponDTO> hairshop_couponList(int hairshop_idx) {
			List<HairShop_CouponDTO> list = sqlMap.selectList("hairshop_couponList",hairshop_idx);
			return list;
		}
		//쿠폰 삭제하기
		public int del_hairshop_coupon(int hairshop_coupon_idx) {
			int result = sqlMap.delete("del_hairshopCoupon", hairshop_coupon_idx);
			return result;
		}
		//회원에게 쿠폰 보내기
		public int sendCouponToMember(String member_coupon_deadline, int member_idx, int hairshop_coupon_idx) {
			Map hm = new HashMap();
			hm.put("member_coupon_deadline", member_coupon_deadline);
			hm.put("member_idx", member_idx);
			hm.put("hairshop_coupon_idx", hairshop_coupon_idx);
			int result = sqlMap.insert("sendCouponToMember", hm);
			return result;
		}
		//보낸메세지 리스트 불러오기
		public List<MessageDTO> sendMessage(int sender_idx, int cp, int ls) {
			
			int startnum=(cp-1)*ls+1;
		    int endnum=cp*ls;
		      
		    Map<String, Integer> map=new HashMap<String, Integer>();
		    map.put("hairshop_idx", sender_idx);
		    map.put("startnum", startnum);
		    map.put("endnum", endnum);
			
			List<MessageDTO> list = sqlMap.selectList("message_sender_id", map);
			return list;
		}
		//메세지 내용불러오기
		public List<MessageDTO> message_content(int message_idx) {
			List<MessageDTO> list = sqlMap.selectList("message_content", message_idx);
			return list;
		}
		//조인없이 메세지 내용 불러오기
		public List<MessageDTO> message_allContent(int message_idx) {
			List<MessageDTO> list = sqlMap.selectList("message_allContent", message_idx);
			return list;
		}
		//관리자_idx 불러오기
		public List<MemberDTO> admin_idx() {
			List<MemberDTO> adminIdx = sqlMap.selectList("admin_idx");
			return adminIdx;
		}
		//받은메세지 리스트 불러오기
		public List<MessageDTO> receiveMessage(int receiver_idx,int cp,int ls) {
			
			int startnum=(cp-1)*ls+1;
		    int endnum=cp*ls;
		      
		    Map<String, Integer> map=new HashMap<String, Integer>();
		    map.put("hairshop_idx", receiver_idx);
		    map.put("startnum", startnum);
		    map.put("endnum", endnum);
			
			List<MessageDTO> list = sqlMap.selectList("message_receiver_id", map);
			return list;
		}
		//메세지 휴지통으로 이동
		public int deleterMessage(int message_idx) {
			int result = sqlMap.update("delete_message", message_idx);
			return result;
		}
		//메세지 수신상태 변화
		public int msgchangeState(int message_idx) {
			int result = sqlMap.update("stateChange_message", message_idx);
			return result;
		}
		//일별 매출통계
		public List<ReservationDTO> dayTotalSales(int hairshop_idx) {
			List<ReservationDTO> sales = sqlMap.selectList("dayTotalSales",hairshop_idx);
			return sales;
		}
		//스폰신청하기
		public int sponApplication(SponDTO sponDto) {
			int result = sqlMap.insert("sponApplication", sponDto);
			return result;
		}
		//매출검색
		public List<ReservationDTO> searchsales(String startDate, String finishDate, int hairshop_idx) {
			
			Map hm = new HashMap();
			hm.put("startDate", startDate);
			hm.put("finishDate", finishDate);
			hm.put("hairshop_idx", hairshop_idx);
			
			List<ReservationDTO> list = sqlMap.selectList("searchForsales", hm);
			return list;
		}
		public List<HashMap> searchsex(String startDate, String finishDate, int hairshop_idx) {
			
			Map hm = new HashMap();
			hm.put("startDate", startDate);
			hm.put("finishDate", finishDate);
			hm.put("hairshop_idx", hairshop_idx);
			List<HashMap> list = sqlMap.selectList("searchForsex", hm);
			return list;
		}
		public List<HashMap> searchage(String startDate, String finishDate, int hairshop_idx) {
			Map hm = new HashMap();
			hm.put("startDate", startDate);
			hm.put("finishDate", finishDate);
			hm.put("hairshop_idx", hairshop_idx);
			List<HashMap> list = sqlMap.selectList("searchForage", hm);
			return list;
		}
		public List<HashMap> searchstyle(String startDate, String finishDate, int hairshop_idx) {
			Map hm = new HashMap();
			hm.put("startDate", startDate);
			hm.put("finishDate", finishDate);
			hm.put("hairshop_idx", hairshop_idx);
			List<HashMap> list = sqlMap.selectList("searchForstyle", hm);
			return list;
		}
		public List<Member_ReviewDTO> hairshop_reviewList(int hairshop_idx) {
			List<Member_ReviewDTO> list = sqlMap.selectList("hairshop_review", hairshop_idx);
			return list;
		}


		public HairShopDTO hairshop_login_submit(String hairshop_id, String hairshop_pwd) {
				Map<String,String> map = new HashMap<String, String>();
				map.put("hairshop_id",hairshop_id );
				map.put("hairshop_pwd",hairshop_pwd);
				 HairShopDTO dto = sqlMap.selectOne("hairshop_login", map);
			return dto;
		}
		

}
