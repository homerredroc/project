package hair.hairshop.model;

public class HairShop_Bbs_PhotoDTO {

	private int hairshop_bbs_idx;
	private String photo_name;
	
	public HairShop_Bbs_PhotoDTO() {
		super();
	}

	public HairShop_Bbs_PhotoDTO(int hairshop_bbs_idx, String photo_name) {
		super();
		this.hairshop_bbs_idx = hairshop_bbs_idx;
		this.photo_name = photo_name;
	}

	public int getHairshop_bbs_idx() {
		return hairshop_bbs_idx;
	}

	public void setHairshop_bbs_idx(int hairshop_bbs_idx) {
		this.hairshop_bbs_idx = hairshop_bbs_idx;
	}

	public String getPhoto_name() {
		return photo_name;
	}

	public void setPhoto_name(String photo_name) {
		this.photo_name = photo_name;
	}
}
