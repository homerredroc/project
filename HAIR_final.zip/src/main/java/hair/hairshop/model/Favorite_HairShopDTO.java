package hair.hairshop.model;

public class Favorite_HairShopDTO {

	private int member_idx;
	private int hairshop_idx;
	
	public Favorite_HairShopDTO() {
		super();
	}

	public Favorite_HairShopDTO(int member_idx, int hairshop_idx) {
		super();
		this.member_idx = member_idx;
		this.hairshop_idx = hairshop_idx;
	}

	public int getMember_idx() {
		return member_idx;
	}

	public void setMember_idx(int member_idx) {
		this.member_idx = member_idx;
	}

	public int getHairshop_idx() {
		return hairshop_idx;
	}

	public void setHairshop_idx(int hairshop_idx) {
		this.hairshop_idx = hairshop_idx;
	}
}
