package hair.hairshop.model;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

public class HairShop_BbsDAOImple implements HairShop_BbsDAO {
	
	private SqlSessionTemplate sqlMap;

	public HairShop_BbsDAOImple(SqlSessionTemplate sqlMap) {
		super();
		this.sqlMap = sqlMap;
	}
	   public List<HairShop_BbsDTO> indextop5() {
		      List<HairShop_BbsDTO> list = sqlMap.selectList("indexTop5");
		      return list;
		   }
	
	/**
	 * 헤어샵 스마트에디터 글쓰기시 파일 업로드
	 */
	public void fileUpload(MultipartFile fileData, String path, String fileName) throws IOException {
		String originalFileName = fileData.getOriginalFilename();
		String contentType = fileData.getContentType();
		long fileSize = fileData.getSize();

		InputStream is = null;
		OutputStream out = null;
		try {
			if (fileSize > 0) {
				is = fileData.getInputStream();
				File realUploadDir = new File(path);
				if (!realUploadDir.exists()) {
					realUploadDir.mkdirs();
				}
				out = new FileOutputStream(path +"/"+ fileName);
				FileCopyUtils.copy(is, out);
			}else{
				new IOException("잘못된 파일을 업로드 하셨습니다.");
			}
		} catch (IOException e) {
			e.printStackTrace();
			new IOException("파일 업로드에 실패하였습니다.");
		}finally{
			if(out != null){out.close();}
			if(is != null){is.close();}
		}		
	}
	
	
	/**
	 * 헤어샵 글쓰기 쿼리인서트 메서드
	 * @param dto 글의 모든 정모를 담고 있는 HairShop_BbsDTO
	 */
	public int hairshopBbsWrite(HairShop_BbsDTO dto) {
		int count=sqlMap.insert("hairshopBbsWrite",dto);
		return count;
	}
	

	/**
	 * 헤어샵 포트폴리오 본문보기를 위한 메서드
	 * @param dto 글의 모든 정모를 담고 있는 HairShop_BbsDTO
	 */
	public HairShop_BbsDTO hairhsopBbs(int hairshop_bbs_idx) {
		HairShop_BbsDTO dto=sqlMap.selectOne("hairshop_Bbs",hairshop_bbs_idx);
		return dto;
	}
	
	/**
	 * 헤어샵 포트폴리오 작성시 헤어샵이 쓴 글을 가져오는 메서드
	 * @param hairshop_idx 어떤 헤어샵이 쓴건지 알기 위한 idx
	 */	
	public List<HairShop_BbsDTO> HairshopRelatedBbsForm(int hairshop_idx) {
		List<HairShop_BbsDTO> list = sqlMap.selectList("HairshopRelatedBbsForm", hairshop_idx);
		return list;
	}

	
	/**
	 * 헤어샵 포트폴리오 본문보기시 글의 관련게시글을 불러오는 메서드
	 * @param hairshop_bbs_idx 어떤 글이 쓴건지 알기 위한 idx
	 */	
	public List<HairShop_BbsDTO> HairshopRelatedBbsList(int hairshop_bbs_idx) {
		List<HairShop_BbsDTO> list = sqlMap.selectList("HairshopRelatedBbsList", hairshop_bbs_idx);
		return list;
	}
	
	/**
	 * 헤어샵 포트폴리오 삭제시 수행되는 메서드
	 * @param hairshop_bbs_idx 어떤 글이 누른건지 알기 위한 idx
	 */		
	public int hairshop_bbs_del(int hairshop_bbs_idx) {
		return sqlMap.update("HairShop_Bbs_Del",hairshop_bbs_idx);
	}
	
	
	/**
	 * 헤어샵 포트폴리오 수정시 관견게시글을 삭제하는 메서드
	 * @param hairshop_bbs_idx 어떤 글이 누른건지 알기 위한 idx
	 */		
	public void hairshopRelatedBbsDel(int hairshop_bbs_idx) {
		sqlMap.delete("hairshopRelatedBbsDel",hairshop_bbs_idx);
	}

	/**
	 * 헤어샵 포트폴리오 수정시 글의 정보를 수정하는 메서드
	 * @param dto 글의 정보를 담고있는 dto
	 */		
	public int hairshop_bbs_update(HairShop_BbsDTO dto) {
		hairshopRelatedBbsDel(dto.getHairshop_bbs_idx());
		return sqlMap.update("hairshop_bbs_update", dto);
	}

	
	/**
	 * 헤어검색시 정보를 가져오는 메서드
	 * @param cp 사용자의 현재 위치
	 * @param ls 불러올 글들의 사이즈
	 * @param hair_style 헤어스타일 검색 옵션
	 * @param hair_price 금액 검색 옵션
	 * @param search_option 어떤 검색을 했는 지 알기 위해
	 * @param search_value 어떤 키워드로 검색을 했는지
	 * @param order 어떤 정렬을 했는지
	 * @param addinfo 어떤 추가 정보를 선택 했는지
	 */	
	public List<HairShop_BbsDTO> hairshop_bbs_list(int cp, int ls, String hair_style, String search_option, String search_value, 
			String hair_price, String order, String[] addinfo) {
		HashMap<String, Object> hm = new HashMap();
		List<HairShop_BbsDTO> list=null;
		int startnum=(cp-1)*ls+1;
		int endnum=cp*ls;
		hm.put("startnum", startnum);
		hm.put("endnum", endnum);
		hm.put("hair_style", hair_style);
		hm.put("hair_price",hair_price);
		hm.put("search_value", search_value);
		hm.put("search_option",search_option);
		if(addinfo!=null) {
			for(int i=0; i<addinfo.length; i++) {
				if(addinfo[i].equals("심야영업"))hm.put("night", addinfo[i]);
				if(addinfo[i].equals("주차가능"))hm.put("park", addinfo[i]);
				if(addinfo[i].equals("애완동물"))hm.put("ani", addinfo[i]);
				if(addinfo[i].equals("연중무휴"))hm.put("day", addinfo[i]);
				if(addinfo[i].equals("바버샵"))hm.put("barber", addinfo[i]);
				if(addinfo[i].equals("지하철역주변"))hm.put("sub", addinfo[i]);
			}			
		}
		
		if(order.equals("price")) {
			hm.put("listsort", "h.hair_price");
			if(!search_option.equals("hairshop_bbs_subtent")) {
				list= sqlMap.selectList("hairshop_bbs_list", hm);	
			}else {
				list= sqlMap.selectList("hairshop_bbs_list_dual", hm);
			}
		}else if(order.equals("writedate")) {
			hm.put("listsort", "hb.hairshop_bbs_writedate desc");
			if(!search_option.equals("hairshop_bbs_subtent")) {
				list= sqlMap.selectList("hairshop_bbs_list", hm);	
			}else {
				list= sqlMap.selectList("hairshop_bbs_list_dual", hm);
			}
		}else if(order.equals("good")) {
			if(!search_option.equals("hairshop_bbs_subtent")) {
				list= sqlMap.selectList("hairshop_bbs_list_good", hm);	
			}else {
				list= sqlMap.selectList("hairshop_bbs_list_good_dual", hm);
			}
		}else if(order.equals("reservation")) {
			if(!search_option.equals("hairshop_bbs_subtent")) {
				list= sqlMap.selectList("hairshop_bbs_list_reservation", hm);	
			}else {
				list= sqlMap.selectList("hairshop_bbs_list_reservation_dual", hm);
			}
		}

		return list;
	}
	
	/**
	 * 헤어검색시 글의 개수를 가져오는 메서드
	 * @param hair_style 헤어스타일 검색 옵션
	 * @param hair_price 금액 검색 옵션
	 * @param search_option 어떤 검색을 했는 지 알기 위해
	 * @param search_value 어떤 키워드로 검색을 했는지
	 * @param addinfo 어떤 추가 정보를 선택 했는지
	 */	
	public int hairshop_bbs_totalcnt(String hair_style, String search_option, String search_value, String hair_price, String[] addinfo) {
		HashMap<String, Object> hm = new HashMap();
		List<HairShop_BbsDTO> list=null;
		hm.put("hair_style", hair_style);
		hm.put("hair_price",hair_price);
		hm.put("search_value", search_value);
		hm.put("search_option",search_option);
		if(addinfo!=null) {
			for(int i=0; i<addinfo.length; i++) {
				if(addinfo[i].equals("심야영업"))hm.put("night", addinfo[i]);
				if(addinfo[i].equals("주차가능"))hm.put("park", addinfo[i]);
				if(addinfo[i].equals("애완동물"))hm.put("ani", addinfo[i]);
				if(addinfo[i].equals("연중무휴"))hm.put("day", addinfo[i]);
				if(addinfo[i].equals("바버샵"))hm.put("barber", addinfo[i]);
				if(addinfo[i].equals("지하철역주변"))hm.put("sub", addinfo[i]);
			}			
		}
		int result;
		if(search_option.equals("hairshop_bbs_subtent")){
			result=sqlMap.selectOne("hairshop_bbs_totalcnt_dual",hm);
		}else {
			result=sqlMap.selectOne("hairshop_bbs_totalcnt",hm);
		}
		return result;
	}
	
	   /**
	    * 헤어샵을 들어갔을때 헤어샵이 쓴 글을 가져오는 메서드
	    * @param hairshop_idx 들어간 헤어샵의 idx
	    * @param cp 현재위치
	    * @param ls 리스트 사이즈
	    */   
	   public List<HairShop_BbsDTO> member_hairshop_bbs_list(int hairshop_idx, int cp, int ls) {
	      HashMap<String, Object> hm = new HashMap();
	      int startnum=(cp-1)*ls+1;
	      int endnum=cp*ls;
	      hm.put("startnum", startnum);
	      hm.put("endnum", endnum);
	      hm.put("hairshop_idx", hairshop_idx);
	      List<HairShop_BbsDTO> list= sqlMap.selectList("member_hairshop_bbs_list",hm);
	      return list;
	   }
	   
	   /**
	    * 헤어샵을 들어갔을때 헤어샵이 쓴 글의 갯수 가져오는 메서드
	    * @param hairshop_idx 들어간 헤어샵의 idx
	    */   
	   public int member_hairshop_bbs_totalcnt(int hairshop_idx) {
	      // TODO Auto-generated method stub
	      return sqlMap.selectOne("member_hairshop_bbs_totalcnt",hairshop_idx);
	   }

}
