package hair.hairshop.model;

import java.sql.Date;

public class HairShopDTO {

	private int hairshop_idx;
	private String hairshop_id;
	private String hairshop_pwd;
	private String hairshop_name;
	private String hairshop_ceo;
	private String hairshop_email;
	private String hairshop_info;
	private String hairshop_number;
	private String hairshop_addr;
	private String hairshop_tel;
	private String hairshop_location;
	private int hairshop_level;
	private int hairshop_state;
	private String hairshop_addinfo;
	private String hairshop_open;
	private String hairshop_off;
	private int hairshop_spon_level;
	private Date hairshop_joindate;
	private String photo_name;
	
	
	public String getPhoto_name() {
		return photo_name;
	}

	public void setPhoto_name(String photo_name) {
		this.photo_name = photo_name;
	}

	public HairShopDTO() {
		super();
	}

	

	public HairShopDTO(int hairshop_idx, String hairshop_id, String hairshop_pwd, String hairshop_name,
			String hairshop_ceo, String hairshop_email, String hairshop_info, String hairshop_number,
			String hairshop_addr, String hairshop_tel, String hairshop_location, int hairshop_level, int hairshop_state,
			String hairshop_addinfo, String hairshop_open, String hairshop_off, int hairshop_spon_level,
			Date hairshop_joindate, String photo_name) {
		super();
		this.hairshop_idx = hairshop_idx;
		this.hairshop_id = hairshop_id;
		this.hairshop_pwd = hairshop_pwd;
		this.hairshop_name = hairshop_name;
		this.hairshop_ceo = hairshop_ceo;
		this.hairshop_email = hairshop_email;
		this.hairshop_info = hairshop_info;
		this.hairshop_number = hairshop_number;
		this.hairshop_addr = hairshop_addr;
		this.hairshop_tel = hairshop_tel;
		this.hairshop_location = hairshop_location;
		this.hairshop_level = hairshop_level;
		this.hairshop_state = hairshop_state;
		this.hairshop_addinfo = hairshop_addinfo;
		this.hairshop_open = hairshop_open;
		this.hairshop_off = hairshop_off;
		this.hairshop_spon_level = hairshop_spon_level;
		this.hairshop_joindate = hairshop_joindate;
		this.photo_name = photo_name;
	}

	public int getHairshop_idx() {
		return hairshop_idx;
	}

	public void setHairshop_idx(int hairshop_idx) {
		this.hairshop_idx = hairshop_idx;
	}

	public String getHairshop_id() {
		return hairshop_id;
	}

	public void setHairshop_id(String hairshop_id) {
		this.hairshop_id = hairshop_id;
	}

	public String getHairshop_pwd() {
		return hairshop_pwd;
	}

	public void setHairshop_pwd(String hairshop_pwd) {
		this.hairshop_pwd = hairshop_pwd;
	}

	public String getHairshop_name() {
		return hairshop_name;
	}

	public void setHairshop_name(String hairshop_name) {
		this.hairshop_name = hairshop_name;
	}

	public String getHairshop_ceo() {
		return hairshop_ceo;
	}

	public void setHairshop_ceo(String hairshop_ceo) {
		this.hairshop_ceo = hairshop_ceo;
	}

	public String getHairshop_email() {
		return hairshop_email;
	}

	public void setHairshop_email(String hairshop_email) {
		this.hairshop_email = hairshop_email;
	}

	public String getHairshop_info() {
		return hairshop_info;
	}

	public void setHairshop_info(String hairshop_info) {
		this.hairshop_info = hairshop_info;
	}

	public String getHairshop_number() {
		return hairshop_number;
	}

	public void setHairshop_number(String hairshop_number) {
		this.hairshop_number = hairshop_number;
	}

	public String getHairshop_addr() {
		return hairshop_addr;
	}

	public void setHairshop_addr(String hairshop_addr) {
		this.hairshop_addr = hairshop_addr;
	}

	public String getHairshop_tel() {
		return hairshop_tel;
	}

	public void setHairshop_tel(String hairshop_tel) {
		this.hairshop_tel = hairshop_tel;
	}

	public String getHairshop_location() {
		return hairshop_location;
	}

	public void setHairshop_location(String hairshop_location) {
		this.hairshop_location = hairshop_location;
	}

	public int getHairshop_level() {
		return hairshop_level;
	}

	public void setHairshop_level(int hairshop_level) {
		this.hairshop_level = hairshop_level;
	}

	public int getHairshop_state() {
		return hairshop_state;
	}

	public void setHairshop_state(int hairshop_state) {
		this.hairshop_state = hairshop_state;
	}

	public String getHairshop_addinfo() {
		return hairshop_addinfo;
	}

	public void setHairshop_addinfo(String hairshop_addinfo) {
		this.hairshop_addinfo = hairshop_addinfo;
	}

	public String getHairshop_open() {
		return hairshop_open;
	}

	public void setHairshop_open(String hairshop_open) {
		this.hairshop_open = hairshop_open;
	}

	public String getHairshop_off() {
		return hairshop_off;
	}

	public void setHairshop_off(String hairshop_off) {
		this.hairshop_off = hairshop_off;
	}

	public int getHairshop_spon_level() {
		return hairshop_spon_level;
	}

	public void setHairshop_spon_level(int hairshop_spon_level) {
		this.hairshop_spon_level = hairshop_spon_level;
	}

	public Date getHairshop_joindate() {
		return hairshop_joindate;
	}

	public void setHairshop_joindate(Date hairshop_joindate) {
		this.hairshop_joindate = hairshop_joindate;
	}
}
