package hair.hairshop.model;

import java.util.List;

public interface Hairshop_PhotoDAO {
	public int hairshop_photo_add(int hairshop_idx, String photo_name);
	public void hairshop_photo_del(int hairshop_idx);
	public List<HairShop_PhotoDTO> hairshop_photo(int hairshop_idx);
}
