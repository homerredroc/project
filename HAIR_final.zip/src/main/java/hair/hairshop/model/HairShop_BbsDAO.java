package hair.hairshop.model;

import java.io.IOException;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;


public interface HairShop_BbsDAO {
   public void fileUpload(MultipartFile fileData, String path, String fileName) throws IOException;
   public int hairshopBbsWrite(HairShop_BbsDTO dto);
   public HairShop_BbsDTO hairhsopBbs(int hairshop_bbs_idx);
   public List<HairShop_BbsDTO> HairshopRelatedBbsForm(int hairshop_idx);
   public List<HairShop_BbsDTO> HairshopRelatedBbsList(int hairshop_bbs_idx);
   public int hairshop_bbs_del(int hairshop_bbs_idx);
   public void hairshopRelatedBbsDel(int hairshop_bbs_idx);
   public int hairshop_bbs_update(HairShop_BbsDTO dto);
   public List<HairShop_BbsDTO> hairshop_bbs_list(int cp, int ls, String hair_style, String search_option, String search_value, String hair_price, String order, String[] addinfo);
   public int hairshop_bbs_totalcnt(String hair_style, String search_option, String search_value, String hair_price, String[] addinfo);
   public List<HairShop_BbsDTO> member_hairshop_bbs_list(int hairshop_idx, int cp, int ls);
   public int member_hairshop_bbs_totalcnt(int hairshop_idx);
   public List<HairShop_BbsDTO> indextop5();
}