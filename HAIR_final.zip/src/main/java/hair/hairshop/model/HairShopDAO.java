package hair.hairshop.model;

import java.util.HashMap;
import java.util.List;

import hair.hair.model.HairDTO;
import hair.member.model.MemberDTO;
import hair.member.model.Member_ReviewDTO;
import hair.message.model.MessageDTO;
import hair.reservation.model.ReservationDTO;
import hair.spon.model.SponDTO;

public interface HairShopDAO {
	public HairShopDTO hairhsopInfo(int hairshop_idx);
	public int hairshop_totalcnt(String search_option, String search_value);
	public List<HairShop_BbsDTO> hairshop_list(int cp, int ls, String search_option, String search_value, String order);
	public List<HairShopDTO> hairshop_map_saerch(String hairshop_addr);
	/*기업로그인*/
	public HairShopDTO hairshop_login_submit(String hairshop_id, String hairshop_pwd);	
	/*기업 회원가입*/
	public int hairshop_join_submit(HairShopDTO hsdto);
	/*기업 회원가입 아이디 중복 체크*/
	public boolean hairshop_join_idCheck(String hairshop_id);
	/*기업 아이디 찾기*/
	public List<HairShopDTO> hairshop_search_id_submit(String hairshop_ceo, String hairshop_email, String hairshop_name);
	/*기업 비밀번호 찾기*/
	public List<HairShopDTO> hairshop_search_pwd_submit(String hairshop_id, String hairshop_ceo, String hairshop_email);
	/*기업 비밀번호 바꾸기*/
	public int hairshop_pwd_update(String hairshop_idx, String hairshop_pwd);
	///////////////////////////////////////관리자///////////////////////////////////////
	//관리자 페이지 - 가입 승인 전 기업 totalCnt
		public int beforeHairshopTotalCnt();
		
		//관리자 페이지 - 가입 승인 기업 totalCnt
		public int joinHairshopTotalCnt();
		
		//관리자 페이지 - 가입 미승인 기업 totalCnt
		public int rejectHairshopTotalCnt();
		
		//관리자 페이지 - 블랙 기업 totalCnt
		public int blackHairshopTotalCnt();
		
		//관리자 페이지 - 탈퇴 기업 totalCnt
		public int outHairshopTotalCnt();
		
		//관리자 페이지 - 가입 승인 전 기업목록 보기
		public List<HairShopDTO> beforeHairshopList(int cp,int ls);
		
		//관리자 페이지 - 가입 승인 전 기업 상세정보 보기
		public HairShopDTO hairshopInfo(int hairshop_idx);
		
		//관리자 페이지 - 가입 승인시키기
		public int makeHairshopJoin(String hairshops_id,int hairshop_idx);
		
		//관리자 페이지 - 가입 승인 기업목록 보기
		public List<HairShopDTO> joinHairshopList(int cp,int ls);
		
		//관리자 페이지 - 가입 미 승인시키기
		public int rejectHairshopJoin(String hairshops_id,int hairshop_idx);
		
		//관리자 페이지 - 가입 미승인 기업목록 보기
		public List<HairShopDTO> rejectHairshopList(int cp,int ls);
		
		//관리자 페이지 - 기업 정보 수정하기	
		public int updateHairshopInfo(HairShopDTO dto);
		
		//관리자 페이지 - 회원 블랙처리하기
		public int makeHairshopBlack(String hairshops_id);
		
		//관리자 페이지 - 블랙기업목록 보기
		public List<HairShopDTO> blackHairshopList(int cp,int ls);
		
		//관리자 페이지 - 회원 탈퇴시키기
		public int makeHairshopOut(String hairshops_id);
			
		//관리자 페이지 - 탈퇴기업목록 보기
		public List<HairShopDTO> outHairshopList(int cp,int ls);

		//관리자 페이지 - 레벨 바꾸기
		public int setHairshopLevel(String hairshop_level,String hairshops_id);
		
		//관리자 페이지 - 탈퇴,블랙 취소하기
		public int makeHairshopNormal(String hairshops_id);
		
		//관리자 페이지 - 회원 검색하기
		public List<HairShopDTO> hairshopSearch(String hairshop_id);
		
		/***********************************************************************************************************************************************/
		
		//관리자 페이지 - 정상 게시글 totalCnt
		public int normalHairshop_bbsTotalCnt();
		
		//관리자 페이지 - 비공개 게시글 totalCnt
		public int notOpenHairshop_bbsTotalCnt();
		
		//관리자 페이지 - 삭제 게시글 totalCnt
		public int deleteHairshop_bbsTotalCnt();
		
		//관리자 페이지 - 게시글 목록 보기
		public List<HairShop_BbsDTO> hairshop_bbsList(int cp,int ls);
		
		//관리자 페이지 - 비공개 게시글 목록 보기
		public List<HairShop_BbsDTO> notOpenHairshop_bbsList(int cp,int ls);
		
		//관리자 페이지 - 삭제 게시글 목록 보기
		public List<HairShop_BbsDTO> deleteHairshop_bbsList(int cp,int ls);
		
		//관리자 페이지 - 게시글 내용보기
		public HairShop_BbsDTO hairshop_bbsContent(int hairshop_bbs_idx);
		
		//관리자 페이지 - 게시글 비공개하기
		public int makeBbsNotOpen(int hairshop_bbs_idx);
		
		//관리자 페이지 - 게시글 삭제하기
		public int makeBbsDelete(int hairshop_bbs_idx);
		
		//관리자 페이지 - 게시글 비공개,삭제 취소하기
		public int makeBbsNormal(int hairshop_bbs_idx);
		
		//관리자 페이지 - 게시글 검색하기
		public List<HairShop_BbsDTO> bbsSearch(String select,String bbsSearch);
		///////////////////////////////////////////////////////////////////////////////////////////////
		

		//헤어샵(기업) 예약회원 불러오기 
		public List<MemberDTO> hairshop_Member(int hairshop_idx, int cp, int ls);
		
		
		//받은 메세지 페이징
		public int hairshop_receiveMessageTotalCnt(int hairshop_idx);
		
		//보낸 메세지 페이징
		public int hairshop_sendMessageTotalCnt(int hairshop_idx);
		
		//예약 회원 페이징
		public int hairshopMember_TotalCnt(int hairshop_idx);
		
		
	
		//헤어샵(기업) 아이디로 idx 추출하기 
		public int hairshop_idx(String hairshop_id);
		
		//정보 수정시 비밀번호 확인하기 
		public String pwdCheck(String hairshop_id);
		
		//헤어샵(기업) 정보 물러오기 
		public List<HairShopDTO> hairshop_info(String hairshop_id);
		
		//헤어샵(기업) 정보 수정 
		public int hairshop_updateInfo(String hairshop_pwd,String hairshop_info,
									String hairshop_addinfo,String hairshop_open,String hairshop_off,String hairshop_id);
		

		
		//헤어샵(기업) 스타일리스트 불러오기
		public List<HairDTO> hairshopStyleList(int hairshop_idx);
		
		//헤어샵(기업) 회원에게 메세지 보내기
		public int msgToMember(int sender_idx,int receiver_idx,String message_content);
		
		//헤어샵(기업) 예약 회원_idx 불러오기
		public List<ReservationDTO> reservationAllMember(int hairshop_idx);
		
		//헤어샵(기업) 쿠폰 만들기
		public int addCoupon(int hairshop_coupon_discount, int hairshop_idx);
		
		//헤어샵(기업) 가지고 있는 쿠폰 목록 불러오기
		public List<HairShop_CouponDTO> hairshop_couponList(int hairshop_idx);
		
		//헤어샵(기업) 쿠폰 삭제하기
		public int del_hairshop_coupon(int hairshop_coupon_idx);
		
		//헤어샵(기업) 회원에게 쿠폰 보내기
		public int sendCouponToMember(String member_coupon_deadline, int member_idx, int hairshop_coupon_idx);
		
		
		
		//헤어샵(기업) 보낸메세지 리스트 불러오기
		public List<MessageDTO> sendMessage(int sender_idx, int cp, int ls);
		
		//헤어샵(기업) 메시지 내용보기
		public List<MessageDTO> message_content(int message_idx);
		
		//메시지_idx로 조건없이 내용보기
		public List<MessageDTO> message_allContent(int message_idx);
		
		//헤어샵(기업) 관리자 idx 불러오기
		public List<MemberDTO> admin_idx();
		
		//헤어샵(기업) 받은 메세지 리스트 불러외
		public List<MessageDTO> receiveMessage(int receiver_idx, int cp, int ls);
		
		//헤어샵(기업) 메세지 삭제하기(상태변환=2)
		public int deleterMessage(int message_idx);
		
		//헤어샵(기업) 메세지 수신확인처리하기(상태변화=1)
		public int msgchangeState(int message_idx);
		
		//헤어샵(기업) 스폰신청
		public int sponApplication(SponDTO sponDto);
		
		//헤어샵(기업) 통계 - 일별 매출 보기
		public List<ReservationDTO> dayTotalSales(int hairshop_idx);
		
		//헤어샵(기업) 통계 - 조회로 매출결과보기
		public List<ReservationDTO> searchsales(String startDate, String finishDate, int hairshop_idx);
		
		//헤어샵(기업) 통계 - 조회로 성별결과보기
		public List<HashMap> searchsex(String startDate, String finishDate, int hairshop_idx);
		
		//헤어샵(기업) 통계 - 조회로 나이결과보기
		public List<HashMap> searchage(String startDate, String finishDate, int hairshop_idx);
		
		//헤어샵(기업) 통계 - 조뢰호 스타일결과보기
		public List<HashMap> searchstyle(String startDate, String finishDate, int hairshop_idx);
		
		//헤어샵(기업) 리뷰 불러오기
		public List<Member_ReviewDTO> hairshop_reviewList(int hairshop_idx);
}

