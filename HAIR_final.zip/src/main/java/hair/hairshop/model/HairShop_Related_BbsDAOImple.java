package hair.hairshop.model;

import java.util.HashMap;

import org.mybatis.spring.SqlSessionTemplate;

public class HairShop_Related_BbsDAOImple implements HairShop_Related_BbsDAO {
	private SqlSessionTemplate sqlMap;
	
	
	public HairShop_Related_BbsDAOImple(SqlSessionTemplate sqlMap) {
		super();
		this.sqlMap = sqlMap;
	}



	/**
	 * 헤어샵 포트폴리오 글쓰기시 관련게시글을 추가하는 메서드
	 * @param hairshop_bbs_Idx 기준이 되는 글의 idx
	 * @param related_bbs_idx 관련글이 되는 idx
	 */
	public int hairshopRelatedBbsWrite(int hairshop_bbs_Idx, int related_bbs_idx) {
		HashMap<String, Integer> map= new HashMap<String, Integer>();
		map.put("hairshop_bbs_Idx", hairshop_bbs_Idx);
		map.put("related_bbs_idx", related_bbs_idx);
		int count=sqlMap.insert("hairshopRelatedBbsWrite",map);
		return count;
	}

	/**
	 * 헤어샵 포트폴리오 글쓰기시 관련게시글을 작성하기 위해 방금 쓴 글의 idx를 가져오는 메서드
	 * @param harshop_idx 내 헤어샵의 idx를 알기 위해
	 */
	public int RelatedRowNum(int harshop_idx) {
		int idx=sqlMap.selectOne("RelatedRowNum",harshop_idx);
		System.out.println("idx="+idx);
		return idx;
	}

}
