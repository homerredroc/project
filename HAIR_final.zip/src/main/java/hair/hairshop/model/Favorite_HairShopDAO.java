package hair.hairshop.model;

public interface Favorite_HairShopDAO {
   public int HairShop_Good(int hairshop_idx, int member_idx);
   public int hairshop_good_check(int hairshop_idx, int member_idx);
}