package hair.hairshop.model;

public interface HairShop_Related_BbsDAO {
	public int hairshopRelatedBbsWrite(int hairshop_idx, int related_bbs_idx);
	public int RelatedRowNum(int hairshop_idx);
}
