package hair.hairshop.model;

public class HairShop_PhotoDTO {

	private int hairshop_idx;
	private String photo_name;
	
	public HairShop_PhotoDTO() {
		super();
	}

	public HairShop_PhotoDTO(int hairshop_idx, String photo_name) {
		super();
		this.hairshop_idx = hairshop_idx;
		this.photo_name = photo_name;
	}

	public int getHairshop_idx() {
		return hairshop_idx;
	}

	public void setHairshop_idx(int hairshop_idx) {
		this.hairshop_idx = hairshop_idx;
	}

	public String getPhoto_name() {
		return photo_name;
	}

	public void setPhoto_name(String photo_name) {
		this.photo_name = photo_name;
	}
}
