package hair.hairshop.model;

public interface HairShop_Bbs_GoodDAO {
	public int HairShop_Bbs_SumGood(int hairshop_bbs_idx);
	public int HairShop_Bbs_Good(int hairshop_bbs_idx, int member_idx);
}
