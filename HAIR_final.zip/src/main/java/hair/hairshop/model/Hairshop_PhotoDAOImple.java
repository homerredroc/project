package hair.hairshop.model;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;

public class Hairshop_PhotoDAOImple implements Hairshop_PhotoDAO {

	private SqlSessionTemplate sqlMap;
	
	public Hairshop_PhotoDAOImple(SqlSessionTemplate sqlMap) {
		super();
		this.sqlMap = sqlMap;
	}

	/**
	 * 헤어샵 사진등록을 하는 메서드
	 * @param hairshop_idx 해당하는 헤어샵의 idx
	 * @param photo_name 저장될 사진의 이름
	 */	
	public int hairshop_photo_add(int hairshop_idx, String photo_name) {
		HashMap<String, Object> map= new HashMap<String, Object>();
		map.put("hairshop_idx", hairshop_idx);
		map.put("photo_name", photo_name);
		return sqlMap.insert("hairshop_photo_add",map);
	}
	
	/**
	 * 헤어샵 사진을 모조리 삭제하는 메서드
	 * @param hairshop_idx 해당하는 헤어샵의 idx
	 */	
	public void hairshop_photo_del(int hairshop_idx) {
		sqlMap.delete("hairshop_photo_del",hairshop_idx);
	}
	
	/**
	 * 헤어샵 사진을 가져오는 메서드
	 * @param hairshop_idx 해당하는 헤어샵의 idx
	 */	
	public List<HairShop_PhotoDTO> hairshop_photo(int hairshop_idx) {
		List<HairShop_PhotoDTO> list=sqlMap.selectList("hairshop_photo",hairshop_idx);
		return list;
	}

}
