package hair.hairshop.model;

import java.util.HashMap;

import org.mybatis.spring.SqlSessionTemplate;

public class HairShop_Bbs_GoodDAOImple implements HairShop_Bbs_GoodDAO {

	private SqlSessionTemplate sqlMap;
	
	public HairShop_Bbs_GoodDAOImple(SqlSessionTemplate sqlMap) {
		super();
		this.sqlMap = sqlMap;
	}
	
	
	/**
	 * 글의 추천수 합을 가져오는 메서드
	 * @param hairshop_bbs_idx 가져올 글의 idx
	 */
	public int HairShop_Bbs_SumGood(int hairshop_bbs_idx) {
		int sum=sqlMap.selectOne("HairShop_Bbs_SumGood",hairshop_bbs_idx);
		return sum;
	}
	
	
	/**
	 * 글의 추천을 눌렀을때 실행되는 메서드
	 * @param hairshop_bbs_idx 눌린 글의 idx
	 * @param member_idx 누른 회원의 idx
	 */
	public int HairShop_Bbs_Good(int hairshop_bbs_idx, int member_idx) {
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		map.put("hairshop_bbs_idx", hairshop_bbs_idx);
		map.put("member_idx", member_idx);
		int result=sqlMap.selectOne("HairShop_Bbs_GoodCk",map);
		
		if(result==0) {
			sqlMap.insert("HairShop_Bbs_GoodOn",map);
		}else {
			sqlMap.delete("HairShop_Bbs_GoodOff",map);
		}	
		return sqlMap.selectOne("HairShop_Bbs_SumGood",hairshop_bbs_idx);
	}

}
