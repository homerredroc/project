package hair.hairshop.model;

public class HairShop_Related_BbsDTO {

	private int hairshop_bbs_idx;
	private int related_bbs_idx;
	
	public HairShop_Related_BbsDTO() {
		super();
	}

	public HairShop_Related_BbsDTO(int hairshop_bbs_idx, int related_bbs_idx) {
		super();
		this.hairshop_bbs_idx = hairshop_bbs_idx;
		this.related_bbs_idx = related_bbs_idx;
	}

	public int getHairshop_bbs_idx() {
		return hairshop_bbs_idx;
	}

	public void setHairshop_bbs_idx(int hairshop_bbs_idx) {
		this.hairshop_bbs_idx = hairshop_bbs_idx;
	}

	public int getRelated_bbs_idx() {
		return related_bbs_idx;
	}

	public void setRelated_bbs_idx(int related_bbs_idx) {
		this.related_bbs_idx = related_bbs_idx;
	}
}
