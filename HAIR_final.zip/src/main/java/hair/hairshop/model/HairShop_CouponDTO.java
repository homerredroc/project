package hair.hairshop.model;

import hair.member.model.Member_CouponDTO;

public class HairShop_CouponDTO {

	private int hairshop_coupon_idx;
	private int hairshop_coupon_discount;
	private int hairshop_idx;
	
	private Member_CouponDTO member_couponDTO;
	private HairShopDTO hairshopDTO;
	
	
	public Member_CouponDTO getMember_couponDTO() {
		return member_couponDTO;
	}

	public HairShopDTO getHairshopDTO() {
		return hairshopDTO;
	}

	public void setMember_couponDTO(Member_CouponDTO member_couponDTO) {
		this.member_couponDTO = member_couponDTO;
	}

	public void setHairshopDTO(HairShopDTO hairshopDTO) {
		this.hairshopDTO = hairshopDTO;
	}

	public HairShop_CouponDTO() {
		super();
	}

	public HairShop_CouponDTO(int hairshop_coupon_idx, int hairshop_coupon_discount, int hairshop_idx) {
		super();
		this.hairshop_coupon_idx = hairshop_coupon_idx;
		this.hairshop_coupon_discount = hairshop_coupon_discount;
		this.hairshop_idx = hairshop_idx;
	}

	public int getHairshop_coupon_idx() {
		return hairshop_coupon_idx;
	}

	public void setHairshop_coupon_idx(int hairshop_coupon_idx) {
		this.hairshop_coupon_idx = hairshop_coupon_idx;
	}

	public int getHairshop_coupon_discount() {
		return hairshop_coupon_discount;
	}

	public void setHairshop_coupon_discount(int hairshop_coupon_discount) {
		this.hairshop_coupon_discount = hairshop_coupon_discount;
	}

	public int getHairshop_idx() {
		return hairshop_idx;
	}

	public void setHairshop_idx(int hairshop_idx) {
		this.hairshop_idx = hairshop_idx;
	}
}
