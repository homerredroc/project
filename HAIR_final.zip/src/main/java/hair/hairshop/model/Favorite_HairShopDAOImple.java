package hair.hairshop.model;

import java.util.HashMap;

import org.mybatis.spring.SqlSessionTemplate;

public class Favorite_HairShopDAOImple implements Favorite_HairShopDAO {

   private SqlSessionTemplate sqlMap;
   
   
   public Favorite_HairShopDAOImple(SqlSessionTemplate sqlMap) {
      super();
      this.sqlMap = sqlMap;
   }


   /**
    * 헤어샵의 관심을 눌렀을때 실행되는 메서드
    * @param hairshop_idx 눌린 글의 idx
    * @param member_idx 누른 회원의 idx
    */
   public int HairShop_Good(int hairshop_idx, int member_idx) {
      HashMap<String, Integer> map = new HashMap<String, Integer>();
      map.put("hairshop_idx", hairshop_idx);
      map.put("member_idx", member_idx);
      int result=sqlMap.selectOne("HairShop_GoodCk",map);
      
      if(result==0) {
         sqlMap.insert("HairShop_GoodOn",map);
         return 1;
      }else {
         sqlMap.delete("HairShop_GoodOff",map);
         return 0;
      }   
   }
   public int hairshop_good_check(int hairshop_idx, int member_idx) {
      HashMap<String, Integer> map = new HashMap<String, Integer>();
      map.put("hairshop_idx", hairshop_idx);
      map.put("member_idx", member_idx);
      int result=sqlMap.selectOne("HairShop_GoodCk",map);
      return result;
   }
}