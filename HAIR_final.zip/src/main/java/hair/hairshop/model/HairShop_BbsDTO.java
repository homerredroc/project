package hair.hairshop.model;

import java.sql.Date;

import hair.hairshop.designer.model.DesignerDTO;

public class HairShop_BbsDTO {

	private int hairshop_bbs_idx;
	private String hairshop_bbs_subject;
	private String hairshop_bbs_content;
	private String hairshop_bbs_hashtag;
	private Date hairshop_bbs_writedate;
	private int hairshop_bbs_state;
	private int hairshop_bbs_level;
	private int hairshop_idx;
	private int hair_idx;
	private int designer_idx;
	private String hairshop_bbs_thumb;
	private String hairshop_name;
	
	public String getHairshop_name() {
		return hairshop_name;
	}

	public void setHairshop_name(String hairshop_name) {
		this.hairshop_name = hairshop_name;
	}

	private DesignerDTO designerDto;
	
	
	public DesignerDTO getDesignerDto() {
		return designerDto;
	}

	public void setDesignerDto(DesignerDTO designerDto) {
		this.designerDto = designerDto;
	}

	public HairShop_BbsDTO() {
		super();
	}

	public HairShop_BbsDTO(int hairshop_bbs_idx, String hairshop_bbs_subject, String hairshop_bbs_content,
			String hairshop_bbs_hashtag, Date hairshop_bbs_writedate, int hairshop_bbs_state, int hairshop_bbs_level,
			int hairshop_idx, int hair_idx, int designer_idx,String hairshop_bbs_thumb) {
		super();
		this.hairshop_bbs_idx = hairshop_bbs_idx;
		this.hairshop_bbs_subject = hairshop_bbs_subject;
		this.hairshop_bbs_content = hairshop_bbs_content;
		this.hairshop_bbs_hashtag = hairshop_bbs_hashtag;
		this.hairshop_bbs_writedate = hairshop_bbs_writedate;
		this.hairshop_bbs_state = hairshop_bbs_state;
		this.hairshop_bbs_level = hairshop_bbs_level;
		this.hairshop_idx = hairshop_idx;
		this.hair_idx = hair_idx;
		this.designer_idx = designer_idx;
		this.hairshop_bbs_thumb=hairshop_bbs_thumb;
	}

	public int getHairshop_bbs_idx() {
		return hairshop_bbs_idx;
	}

	public void setHairshop_bbs_idx(int hairshop_bbs_idx) {
		this.hairshop_bbs_idx = hairshop_bbs_idx;
	}

	public String getHairshop_bbs_subject() {
		return hairshop_bbs_subject;
	}

	public void setHairshop_bbs_subject(String hairshop_bbs_subject) {
		this.hairshop_bbs_subject = hairshop_bbs_subject;
	}

	public String getHairshop_bbs_content() {
		return hairshop_bbs_content;
	}

	public void setHairshop_bbs_content(String hairshop_bbs_content) {
		this.hairshop_bbs_content = hairshop_bbs_content;
	}

	public String getHairshop_bbs_hashtag() {
		return hairshop_bbs_hashtag;
	}

	public void setHairshop_bbs_hashtag(String hairshop_bbs_hashtag) {
		this.hairshop_bbs_hashtag = hairshop_bbs_hashtag;
	}

	public Date getHairshop_bbs_writedate() {
		return hairshop_bbs_writedate;
	}

	public void setHairshop_bbs_writedate(Date hairshop_bbs_writedate) {
		this.hairshop_bbs_writedate = hairshop_bbs_writedate;
	}

	public int getHairshop_bbs_state() {
		return hairshop_bbs_state;
	}

	public void setHairshop_bbs_state(int hairshop_bbs_state) {
		this.hairshop_bbs_state = hairshop_bbs_state;
	}

	public int getHairshop_bbs_level() {
		return hairshop_bbs_level;
	}

	public void setHairshop_bbs_level(int hairshop_bbs_level) {
		this.hairshop_bbs_level = hairshop_bbs_level;
	}

	public int getHairshop_idx() {
		return hairshop_idx;
	}

	public void setHairshop_idx(int hairshop_idx) {
		this.hairshop_idx = hairshop_idx;
	}

	public int getHair_idx() {
		return hair_idx;
	}

	public void setHair_idx(int hair_idx) {
		this.hair_idx = hair_idx;
	}

	public int getDesigner_idx() {
		return designer_idx;
	}

	public void setDesigner_idx(int designer_idx) {
		this.designer_idx = designer_idx;
	}

	public String getHairshop_bbs_thumb() {
		return hairshop_bbs_thumb;
	}

	public void setHairshop_bbs_thumb(String hairshop_bbs_thumb) {
		this.hairshop_bbs_thumb = hairshop_bbs_thumb;
	}
	

	
}
