package hair.statistics.model;

public class Week_StatisticsDTO {

	private int week_price;
	private String week_sex;
	private String week_age;
	private String week_style;
	private String week_designer;
	private int hairshop_idx;
	
	public Week_StatisticsDTO() {
		super();
	}

	public Week_StatisticsDTO(int week_price, String week_sex, String week_age, String week_style, String week_designer,
			int hairshop_idx) {
		super();
		this.week_price = week_price;
		this.week_sex = week_sex;
		this.week_age = week_age;
		this.week_style = week_style;
		this.week_designer = week_designer;
		this.hairshop_idx = hairshop_idx;
	}

	public int getWeek_price() {
		return week_price;
	}

	public void setWeek_price(int week_price) {
		this.week_price = week_price;
	}

	public String getWeek_sex() {
		return week_sex;
	}

	public void setWeek_sex(String week_sex) {
		this.week_sex = week_sex;
	}

	public String getWeek_age() {
		return week_age;
	}

	public void setWeek_age(String week_age) {
		this.week_age = week_age;
	}

	public String getWeek_style() {
		return week_style;
	}

	public void setWeek_style(String week_style) {
		this.week_style = week_style;
	}

	public String getWeek_designer() {
		return week_designer;
	}

	public void setWeek_designer(String week_designer) {
		this.week_designer = week_designer;
	}

	public int getHairshop_idx() {
		return hairshop_idx;
	}

	public void setHairshop_idx(int hairshop_idx) {
		this.hairshop_idx = hairshop_idx;
	}
}
