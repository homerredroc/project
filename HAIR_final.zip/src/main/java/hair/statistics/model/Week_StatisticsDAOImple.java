package hair.statistics.model;

import java.util.HashMap;
import java.util.List;


import org.mybatis.spring.SqlSessionTemplate;

public class Week_StatisticsDAOImple implements Week_StatisticsDAO {

	private SqlSessionTemplate sqlMap;

	public Week_StatisticsDAOImple(SqlSessionTemplate sqlMap) {
		super();
		this.sqlMap = sqlMap;
	}
	
	//관리자 페이지 - 개인 이용 회원(전체)
	public int memberTotal() {
		
		int count=sqlMap.selectOne("memberTotal");
		
		return count;
	}
	
	//관리자 페이지 - 개인 이용 회원(성별:남자)
	public int maleTotal() {
		
		int count=sqlMap.selectOne("maleTotal");
		
		return count;
	}
	
	//관리자 페이지 - 개인 이용 회원(성별:여자)
	public int femaleTotal() {
		
		int count=sqlMap.selectOne("femaleTotal");
		
		return count;
	}
	
	//관리자 페이지 - 개인 이용 회원(나이별)
	public List<HashMap<String,Integer>> eachAge() {
		
		List<HashMap<String,Integer>> list=sqlMap.selectList("eachAge");
					
		return list;
	}
	
	//관리자 페이지 - 총 예약 건수
	public int reservationTotal() {
		
		int count=sqlMap.selectOne("reservationTotal");
		
		return count;
	}
	
	//관리자 페이지 - 총 예약 금액
	public int reservationPriceTotal() {
		
		int count=sqlMap.selectOne("reservationPriceTotal");
		
		return count;
	}
	
	//관리자 페이지 - 월별 총 예약 건수 및 금액
	public List<HashMap<String, Object>> eachReservation() {
		
		List<HashMap<String, Object>> list=sqlMap.selectList("eachReservation");
		
		return list;
	}
}
