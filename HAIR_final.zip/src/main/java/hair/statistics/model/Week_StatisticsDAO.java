package hair.statistics.model;

import java.util.HashMap;
import java.util.List;

public interface Week_StatisticsDAO {

	//관리자 페이지 - 개인 이용 회원(전체)
	public int memberTotal();
	
	//관리자 페이지 - 개인 이용 회원(성별:남자)
	public int maleTotal();
	
	//관리자 페이지 - 개인 이용 회원(성별:여자)
	public int femaleTotal();
	
	//관리자 페이지 - 개인 이용 회원(나이별)
	public List<HashMap<String,Integer>> eachAge();
	
	//관리자 페이지 - 총 예약 건수
	public int reservationTotal();
	
	//관리자 페이지 - 총 예약 금액
	public int reservationPriceTotal();
	
	//관리자 페이지 - 월별 총 예약 건수 및 금액
	public List<HashMap<String, Object>> eachReservation();
}
