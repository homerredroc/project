package hair.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import hair.community.model.*;
import hair.hairshop.model.*;
import hair.member.model.MemberDAO;
import hair.member.model.MemberDTO;
import hair.message.model.MessageDAO;
import hair.message.model.MessageDTO;
import hair.spon.model.SponDAO;
import hair.spon.model.SponDTO;
import hair.statistics.model.Week_StatisticsDAO;

@Controller
public class AdminController {
   
   @Autowired
   private NoticeDAO NoticeDao;
   @Autowired
   private QnaDAO QnaDao;
   @Autowired
   private SponDAO SponDao;
   
   @Autowired
	private MessageDAO msgDao;
	
	@Autowired
	private MemberDAO memberDao;
	
	@Autowired
	private HairShopDAO hairshopDao;
	
	@Autowired
	private SponDAO sponDao;
	
	@Autowired
	private Week_StatisticsDAO statisticsDao;
   

	//nain페이지 이동
	@RequestMapping("/admin_main.do")
	public ModelAndView admin_main(){
		
		int memberTotal=statisticsDao.memberTotal(); //개인 이용 회원(전체)
   		int maleTotal=statisticsDao.maleTotal(); //개인 이용 회원(성별:남자)
   		int femaleTotal=statisticsDao.femaleTotal(); //개인 이용 회원(성별:여자)
   		
   		List<HashMap<String,Integer>> ageList=statisticsDao.eachAge(); //개인 이용 회원(나이별)
   		
   		int[] agecount=new int[4]; 
   		
   					
   			for(int i=0;i<ageList.size();i++) {
   				
   				if(ageList.get(i).get("age")==10) {
   					
   					agecount[0]=ageList.get(i).get("count");
   					
   				}else if(ageList.get(i).get("age")==20) {
   					
   					agecount[1]=ageList.get(i).get("count");
   					
   				}else if(ageList.get(i).get("age")==30) {
   					
   					agecount[2]=ageList.get(i).get("count");
   					
   				}else if(ageList.get(i).get("age")==40) {
   					
   					agecount[3]=ageList.get(i).get("count");
   				}
   			}
   		String agecount_s=agecount[0]+","+agecount[1]+","+agecount[2]+","+agecount[3];
   	      
   	    System.out.println(agecount_s);
   		
   		int reservationTotal=statisticsDao.reservationTotal(); //총 예약 건수
   		int reservationPriceTotal=statisticsDao.reservationPriceTotal(); //총 예약 금액
   		
   		List<HashMap<String, Object>> reservationList=statisticsDao.eachReservation(); //월별 총 예약 건수 및 금액
   		
   		String month="";
   		String totalReservCount="";
   		
   		for(int i=0;i<reservationList.size();i++) {
   			
   			month+="\'"+reservationList.get(i).get("reservation_date")+"\'";
   			totalReservCount+="["+(reservationList.get(i).get("count"))+","+((Integer)(reservationList.get(i).get("price"))/10000)+"]";
   			
   			if(i!=reservationList.size()-1) {
   				
   				month+=",";
   				totalReservCount+=",";
   			}
   		}
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("memberTotal", memberTotal);
   		mav.addObject("maleTotal", maleTotal);
   		mav.addObject("femaleTotal", femaleTotal);
   		mav.addObject("ageList", agecount_s);
   		mav.addObject("reservationTotal", reservationTotal);
   		mav.addObject("reservationPriceTotal", reservationPriceTotal);
   		mav.addObject("reservationList", reservationList);
   		mav.addObject("month", month);
   		mav.addObject("totalReservCount", totalReservCount);
   		mav.setViewName("admin/admin_main");
   		
   		return mav;
	}
   
   /**
    * 공지쓰기로 진입하는 컨트롤러
    */
   @RequestMapping(value="/notice_write.do")
   public String noticeWrite() {
      return "admin/notice/notice_write";
   }
   
   /**
    * 공지쓰기를 실행하는 컨트롤러
    * @param dto공지의 정보를 담고 있는 dto
    */
   @RequestMapping(value="/notice_write_ok.do")
   public ModelAndView noticeWrite_ok(NoticeDTO dto) {
      ModelAndView mav = new ModelAndView();
      int result = NoticeDao.notice_write(dto);
      String msg=result>0?"성공":"실패";
      mav.addObject("msg",msg);
      mav.addObject("goPage","notice_list.do");
      mav.setViewName("admin/stateMsg2");
      return mav;
   }
   
   /**
    * 공지 리스트로 리동하는 컨트롤러
    */
   @RequestMapping(value="/notice_list.do")
   public ModelAndView notice_list() {
      ModelAndView mav = new ModelAndView();
      List<NoticeDTO> list = NoticeDao.notice_list();
      mav.addObject("list",list);
      mav.setViewName("admin/notice/notice_list");
      return mav;   
   }
   
   /**
    * 공지 본문으로 이동하는 컨트롤러
    * @param notice_idx 해당하는 글의 idx
    */
   @RequestMapping(value="/notice_content.do")
   public ModelAndView notice_content(int notice_idx) {
      ModelAndView mav = new ModelAndView();
      NoticeDTO dto = NoticeDao.notice_content(notice_idx);
      mav.addObject("dto", dto);
      mav.setViewName("admin/notice/notice_content");
      return mav;
   }
   
   /**
    * 공지 수정으로 이동하는 컨트롤러
    * @param notice_idx 해당하는 글의 idx
    */
   @RequestMapping(value="/notice_update.do")
   public ModelAndView notice_update(int notice_idx) {
      ModelAndView mav = new ModelAndView();
      NoticeDTO dto = NoticeDao.notice_content(notice_idx);
      mav.addObject("dto", dto);
      mav.setViewName("admin/notice/notice_update");
      return mav;
   }
   
   /**
    * 공지업데이트를 수정하는 컨트롤러
    * @param dto공지의 정보를 담고 있는 dto
    */
   @RequestMapping(value="/notice_update_ok.do")
   public ModelAndView notice_update_ok(NoticeDTO dto) {
      ModelAndView mav = new ModelAndView();
      int result = NoticeDao.notice_update(dto);
      String msg=result>0?"성공":"실패";
      mav.addObject("msg",msg);
      mav.addObject("goPage","notice_list.do");
      mav.setViewName("admin/stateMsg2");
      return mav;
   }
   
   
   /**
    * QnA글쓰기 폼으로 이동하는 컨트롤러
    */
   @RequestMapping(value="/qna_write.do")
   public String qna_write() {
      return "admin/qna/qna_write";
   }

   /**
    * QnA글쓰기 완료 메서드를 호출하는 컨트롤러
    * @param dto 글의 모든 정보를 담고있는 dto
    */
   @RequestMapping(value="/qna_write_ok.do")
   public ModelAndView qna_write_ok(QnaDTO dto) {
      ModelAndView mav = new ModelAndView();
      int result = QnaDao.qna_write(dto);
      String msg=result>0?"성공":"실패";
      mav.addObject("msg",msg);
      mav.addObject("goPage","qna_list.do");
      mav.setViewName("admin/qna/qna_msg");
      return mav;
   }
   
   /**
    * QnA업데이트 메서드를 호출하는 컨트롤러
    * @param dto 글의 모든 정보를 담고있는 dto
    */
   @RequestMapping(value="/qna_update_ok.do")
   public ModelAndView qna_update_ok(QnaDTO dto) {
      ModelAndView mav = new ModelAndView();
      int result = QnaDao.qna_update(dto);
      String msg=result>0?"성공":"실패";
      mav.addObject("msg",msg);
      mav.addObject("goPage","qna_list.do");
      mav.setViewName("admin/qna/qna_msg");
      return mav;
   }


   /**
    * QnA삭제
    * @param qna_idx 글의 idx
    */
   @RequestMapping(value="/qna_del.do")
   public ModelAndView qna_del(int qna_idx) {
      ModelAndView mav = new ModelAndView();
      int result = QnaDao.qna_del(qna_idx);
      String msg=result>0?"성공":"실패";
      mav.addObject("msg",msg);
      mav.addObject("goPage","qna_list.do");
      mav.setViewName("admin/qna/qna_msg");
      return mav;
   }
   
   /**
    * notice 삭제
    * @param notice_idx 글의 idx
    */
   @RequestMapping(value="/notice_del.do")
   public ModelAndView notice_del(int notice_idx) {
      ModelAndView mav = new ModelAndView();
      int result = NoticeDao.notice_del(notice_idx);
      String msg=result>0?"성공":"실패";
      mav.addObject("msg",msg);
      mav.addObject("goPage","qna_list.do");
      mav.setViewName("admin/stateMsg2");
      return mav;
   }
   
   /**
    * QnA 리스트로 이동하는 컨트롤러
    */
   @RequestMapping(value="/qna_list.do")
   public ModelAndView qna_list() {
      ModelAndView mav = new ModelAndView();
      List<QnaDTO> list = QnaDao.qna_list();
      mav.addObject("list",list);
      mav.setViewName("admin/qna/qna_list");
      return mav;   
   }
   
   /**
    * QnA 본문으로 이동하는 컨트롤러
    * @param qna_idx 이동할 글의 idx
    */
   @RequestMapping(value="/qna_content.do")
   public ModelAndView qna_content(int qna_idx) {
      ModelAndView mav = new ModelAndView();
      QnaDTO dto = QnaDao.qna_content(qna_idx);
      mav.addObject("dto", dto);
      mav.setViewName("admin/qna/qna_content");
      return mav;
   }
   
   /**
    * QnA 수정으로 이동하는 컨트롤러
    * @param qna_idx 이동할 글의 idx
    */
   @RequestMapping(value="/qna_update.do")
   public ModelAndView qna_update(int qna_idx) {
      ModelAndView mav = new ModelAndView();
      QnaDTO dto = QnaDao.qna_content(qna_idx);
      mav.addObject("dto", dto);
      mav.setViewName("admin/qna/qna_update");
      return mav;
   }
   
   

   public void hairshop_spon(int hairshop_idx, int updown) {
      ModelAndView mav = new ModelAndView();
      int result = SponDao.hairshop_spon(hairshop_idx, updown);
   }
   
   

   public void hairshop_bbs_spon(int hairshop_bbs_idx, int updown) {
      ModelAndView mav = new ModelAndView();
      int result = SponDao.hairshop_bbs_spon(hairshop_bbs_idx, updown);
   
   }
   
   
   
   
   
///////////////////////////////////////////////////////////////////////////////////////
   	
   	//전체 메세지 보내기 팝업창 띄우기
   	@RequestMapping("/admin_msgSendAllForm.do")
   	public ModelAndView admin_msgForm() {
   		
   		ModelAndView mav=new ModelAndView();
   		mav.setViewName("admin/msg/admin_msgSendAllForm");
   		
   		return mav;
   	}
   	
   	//전체 메세지 보내기
   	/*admin_msgForm.jsp에서 message_content와 select box의 value를 파라미터로 받아옴*/
   	@RequestMapping("/admin_msgSendAll.do")
   	public ModelAndView admin_msgSendAll(@RequestParam("message_content")String message_content,
   									  @RequestParam("select")String select) {
   	
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		if(select.equals("개인전체")) {
   			result=msgDao.admin_msgSendMember(message_content, select);
   		}else {
   			result=msgDao.admin_msgSendShop(message_content, select);
   		}
   		
   		String msg=result>0?"메세지 보내기 성공!":"메세지 보내기 실패!";
   		
   		mav.addObject("msg", msg);
   		mav.setViewName("admin/Msg");
   		
   		return mav;
   	}
   	
   	/*----------------------------------------------------------------------------------------------------------------------------------------------*/
   	
   	/*(개인)*/
   	//회원관리 - 개인회원목록 보기 페이지 이동
   	@RequestMapping("/admin_memberList.do")
   	public ModelAndView admin_memberList() {
   		
   		ModelAndView mav=new ModelAndView();		
   		mav.setViewName("admin/member/admin_memberList");
   		
   		return mav;
   	}
   	
   	//회원관리 - 개인회원목록 보기
   	@RequestMapping("/admin_memberState.do")
   	public ModelAndView admin_memberState(@RequestParam(value="cp",defaultValue="1")int cp,
   										  @RequestParam("member_state")int state) {
   		
   		ModelAndView mav=new ModelAndView();
   		
   		//페이징
   		int totalCnt=0;
   		int listSize=5;
   		int pageSize=5;
   		
   		String pageStr=null;
   		
   		//목록
   		List<MemberDTO> list = null;
   		
   		if(state==1) {
   			
   			totalCnt=memberDao.normalTotalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=memberDao.memberList(cp,listSize); //정상회원목록
   			mav.addObject("paging", pageStr);
   			mav.addObject("list", list);
   			mav.setViewName("admin/member/admin_memberState1");
   			 
   		}else if(state==2) {
   			
   			totalCnt=memberDao.blackTotalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=memberDao.blackMemberList(cp,listSize); //블랙회원목록
   			mav.addObject("paging", pageStr);
   			mav.addObject("list", list);
   			mav.setViewName("admin/member/admin_memberState2");
   			
   		}else if(state==3) {
   			
   			totalCnt=memberDao.outTotalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=memberDao.outMemberList(cp,listSize); //탈퇴회원목록
   			mav.addObject("paging", pageStr);
   			mav.addObject("list", list);
   			mav.setViewName("admin/member/admin_memberState3");
   		}
   				
   		return mav;
   	}
   	
   	//회원관리 - 개인회원상태 바꾸기(탈퇴) 팝업창 띄우기
   	@RequestMapping("/admin_outMemberListForm.do")
   	public ModelAndView admin_outMemberListForm(String members_id) {
   		
   		String id[]=members_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("members_id", members_id);
   		mav.setViewName("admin/member/admin_outMemberListForm");
   		
   		return mav;
   	}
   	
   	//회원관리 - 개인회원상태 바꾸기(탈퇴)
   	@RequestMapping("/admin_makeMemberOut.do")
   	public ModelAndView admin_makeMemberOut(@RequestParam("members_id")String members_id) {
   		
   		String id[]=members_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<id.length;i++) {
   			
   			result=memberDao.makeMemberOut(id[i]);
   		}
   		String msg=result>0?"탈퇴처리 되었습니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.setViewName("admin/stateMsg");
   		
   		return mav;	
   	}
   	
   	//회원관리 - 개인회원상태 바꾸기(블랙) 팝업창 띄우기
   	@RequestMapping("/admin_blackMemberListForm.do")
   	public ModelAndView admin_blackMemberListForm(String members_id) {
   		
   		String id[]=members_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("members_id", members_id);
   		mav.setViewName("admin/member/admin_blackMemberListForm");
   		
   		return mav;
   	}
   	
   	//회원관리 - 개인회원상태 바꾸기(블랙)
   	@RequestMapping("/admin_makeMemberBlack.do")
   	public ModelAndView admin_makeMemberBlack(@RequestParam("members_id")String members_id) {
   		
   		String id[]=members_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<id.length;i++) {
   			
   			result=memberDao.makeMemberBlack(id[i]);
   		}
   		String msg=result>0?"블랙처리 되었습니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.setViewName("admin/stateMsg");
   		
   		return mav;
   	}
   	
   	//회원관리 - 메세지 팝업창 띄우기
   	@RequestMapping("/admin_eachMemberMsgForm.do")
   	public ModelAndView admin_eachMemberMsgForm(String members_id) {
   		
   		String id[]=members_id.split(","); //,를 기준으로 문자열 자르기
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("members_id", members_id);
   		mav.setViewName("admin/msg/admin_eachMemberMsgForm");
   		
   		return mav;
   	}
   	
   	//회원관리 - 선택한 개인회원에게 메세지 보내기
   	@RequestMapping("/admin_eachMemberMsgSend.do")
   	public ModelAndView admin_eachMemberMsgSend(@RequestParam("message_content")String message_content,
   												@RequestParam("members_id")String members_id) {
   	
   		String id[]=members_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		System.out.println(id.length);
   		for(int i=0;i<id.length;i++)
   		{	
   			System.out.println(id[i]);
   			result=msgDao.admin_eachMemberMsgSend(message_content, id[i]);
   		}
   		String msg=result>0?"메세지 보내기 성공!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.setViewName("admin/Msg");
   		
   		return mav;
   	}
   		
   	//회원관리 - 레벨 팝업창 띄우기
   	@RequestMapping("/admin_memberLevelForm.do")
   	public ModelAndView admin_memberLevelForm(String members_id) {
   		
   		String id[]=members_id.split(","); //,를 기준으로 문자열 자르기
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("members_id", members_id);
   		mav.setViewName("admin/member/admin_memberLevelForm");
   		
   		return mav;
   	}
   	
   	//회원관리 - 레벨 바꾸기
   	@RequestMapping("/admin_setMemberLevel.do")
   	public ModelAndView admin_setMemberLevel(@RequestParam("member_level")String member_level,
   											 @RequestParam("members_id")String members_id) {
   		
   		String id[]=members_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<id.length;i++) {
   			result=memberDao.setMemberLevel(member_level, id[i]);
   		}		
   		String msg=result>0?"레벨 바꾸기에 성공하였습니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.setViewName("admin/stateMsg");
   		
   		return mav;
   	}
   	
   	//회원관리 - 탈퇴,블랙 취소 팝업창 띄우기
   	@RequestMapping("/admin_normalMemberListForm.do")
   	public ModelAndView admin_normalMemberListForm(String members_id) {
   		
   		String id[]=members_id.split(","); //,를 기준으로 문자열 자르기
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("members_id", members_id);
   		mav.setViewName("admin/member/admin_normalMemberListForm");
   		
   		return mav;
   	}
   	
   	//회원관리 - 탈퇴,블랙 취소하기
   	@RequestMapping("/admin_makeMemberNormal.do")
   	public ModelAndView admin_makeMemberNormal(@RequestParam("members_id")String members_id) {
   		
   		String id[]=members_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<id.length;i++) {
   			
   			result=memberDao.makeMemberNormal(id[i]);
   		}
   		String msg=result>0?"정상처리 되었습니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.setViewName("admin/stateMsg");
   		
   		return mav;
   	}
   	
  //회원관리 - 검색하기
    @RequestMapping("/admin_memberSearchAjax.do")
    public ModelAndView admin_memberSearchList(@RequestParam("member_id")String member_id) {
       
       List<MemberDTO> searchList=memberDao.memberSearch(member_id);
       
       ModelAndView mav=new ModelAndView();
       mav.addObject("searchList", searchList);
       mav.addObject("member_state", searchList.get(0).getMember_state());
       mav.setViewName("admin/member/admin_memberSearchList");
       
       return mav;
    }
    
   	
   	/*----------------------------------------------------------------------------------------------------------------------------------------------*/
   	
   	/*(기업)*/
   	
   	//회원관리 - 기업회원목록 보기 페이지 이동
   	@RequestMapping("/admin_hairshopList.do")
   	public ModelAndView admin_hairshopList() {
   		
   		int total=hairshopDao.joinHairshopTotalCnt(); //가입 승인 기업 전체 수
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("total", total);
   		mav.setViewName("admin/hairshop/admin_hairshopList");
   		
   		return mav;
   	}
   	
   	//회원관리 - 기업회원목록 보기
   	@RequestMapping("/admin_hairshopState.do")
   	public ModelAndView admin_hairshopState(@RequestParam(value="cp",defaultValue="1")int cp,
   			 								@RequestParam("hairshop_state")int state) {
   		
   		ModelAndView mav=new ModelAndView();
   		
   		//페이징
   		int totalCnt=0;
   		int listSize=5;
   		int pageSize=5;
   				
   		String pageStr=null;
   		
   		//목록
   		List<HairShopDTO> list=null;
   		
   		if(state==0) {
   			
   			totalCnt=hairshopDao.beforeHairshopTotalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=hairshopDao.beforeHairshopList(cp,listSize); //가입 승인 전 기업목록
   			mav.addObject("paging", pageStr);
   			mav.addObject("list", list);
   			mav.setViewName("admin/hairshop/admin_hairshopState0");
   			
   		}else if(state==1) {
   			
   			totalCnt=hairshopDao.joinHairshopTotalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=hairshopDao.joinHairshopList(cp,listSize); //가입 승인 기업목록
   			mav.addObject("paging", pageStr);
   			mav.addObject("list", list);
   			mav.setViewName("admin/hairshop/admin_hairshopState1");
   			
   		}else if(state==-1) {
   			
   			totalCnt=hairshopDao.rejectHairshopTotalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=hairshopDao.rejectHairshopList(cp,listSize); //가입 미 승인 기업목록
   			mav.addObject("paging", pageStr);
   			mav.addObject("list", list);
   			mav.setViewName("admin/hairshop/admin_hairshopState-1");
   			
   		}else if(state==2) {
   			
   			totalCnt=hairshopDao.blackHairshopTotalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=hairshopDao.blackHairshopList(cp,listSize); //블랙기업목록
   			mav.addObject("paging", pageStr);
   			mav.addObject("list", list);
   			mav.setViewName("admin/hairshop/admin_hairshopState2");
   			
   		}else if(state==3) {
   			
   			totalCnt=hairshopDao.outHairshopTotalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=hairshopDao.outHairshopList(cp,listSize); //탈퇴기업목록
   			mav.addObject("paging", pageStr);
   			mav.addObject("list", list);
   			mav.setViewName("admin/hairshop/admin_hairshopState3");			
   		}
   		
   		return mav;
   	}
   	
   	//회원관리 - 가입 승인 전 헤어샵 상세 정보 확인 팝업창 띄우기
   	@RequestMapping("/admin_checkHairshopInfoForm.do")
   	public ModelAndView admin_checkHairshopInfoForm(@RequestParam("hairshop_idx")int hairshop_idx) {
   		
   		HairShopDTO dto=hairshopDao.hairshopInfo(hairshop_idx);
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("hairshop_idx", hairshop_idx);
   		mav.addObject("dto", dto);
   		mav.setViewName("admin/hairshop/admin_checkHairshopInfoForm");
   		
   		return mav;
   	}
   	
   	//회원관리 - 가입 승인하기 팝업창 띄우기
   	@RequestMapping("/admin_beforeHairshopListForm.do")
   	public ModelAndView admin_beforeHairshopListForm(@RequestParam("hairshops_id")String hairshops_id) {
   		
   		String id[]=hairshops_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("hairshops_id", hairshops_id);
   		mav.setViewName("admin/hairshop/admin_beforeHairshopListForm");
   		
   		return mav;
   	}
   	
   	//회원관리 - 가입 승인하기
   	@RequestMapping("/admin_makeHairshopJoin.do")
   	public ModelAndView admin_makeHairshopJoin(@RequestParam(value="hairshops_id",defaultValue="")String hairshops_id,
   											   @RequestParam(value="hairshop_idx",defaultValue="0")int hairshop_idx) {
   		
   		String id[]=hairshops_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<id.length;i++) {
   			
   			result=hairshopDao.makeHairshopJoin(id[i],hairshop_idx);
   		}
   		String msg=result>0?"가입이 승인되었습니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.setViewName("admin/stateMsg");
   		
   		return mav;	
   	}
   	
   	//회원관리 - 가입 미 승인하기 팝업창 띄우기
   	@RequestMapping("/admin_rejectHairshopListForm.do")
   	public ModelAndView admin_rejectHairshopListForm(@RequestParam("hairshops_id")String hairshops_id) {
   		
   		String id[]=hairshops_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("hairshops_id", hairshops_id);
   		mav.setViewName("admin/hairshop/admin_rejectHairshopListForm");
   		
   		return mav;
   	}
   	
   	//회원관리 - 가입 미 승인하기
   	@RequestMapping("/admin_rejectHairshopJoin.do")
   	public ModelAndView admin_rejectHairshopJoin(@RequestParam(value="hairshops_id",defaultValue="")String hairshops_id,
   												 @RequestParam(value="hairshop_idx",defaultValue="0")int hairshop_idx) {
   		
   		String id[]=hairshops_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<id.length;i++) {
   			
   			result=hairshopDao.rejectHairshopJoin(id[i],hairshop_idx);
   		}
   		String msg=result>0?"가입이 미 승인되었습니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.setViewName("admin/stateMsg");
   		
   		return mav;	
   	}
   	
   	//회원관리 - 기업회원상태 바꾸기(블랙) 팝업창 띄우기
   	@RequestMapping("/admin_blackHairshopListForm.do")
   	public ModelAndView admin_blackHairshopListForm(@RequestParam("hairshops_id")String hairshops_id) {
   		
   		String id[]=hairshops_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("hairshops_id", hairshops_id);
   		mav.setViewName("admin/hairshop/admin_blackHairshopListForm");
   		
   		return mav;
   	}
   	
   	//회원관리 - 기업회원상태 바꾸기(블랙)
   	@RequestMapping("/admin_makeHairshopBlack.do")
   	public ModelAndView admin_makeHairshopBlack(@RequestParam("hairshops_id")String hairshops_id) {
   		
   		String id[]=hairshops_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<id.length;i++) {
   			
   			result=hairshopDao.makeHairshopBlack(id[i]);
   		}
   		String msg=result>0?"블랙처리 되었습니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.setViewName("admin/stateMsg");
   		
   		return mav;
   	}
   	
   	//회원관리 - 기업회원상태 바꾸기(탈퇴) 팝업창 띄우기
   	@RequestMapping("/admin_outHairshopListForm.do")
   	public ModelAndView admin_outHairshopListForm(@RequestParam("hairshops_id")String hairshops_id) {
   		
   		String id[]=hairshops_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("hairshops_id", hairshops_id);
   		mav.setViewName("admin/hairshop/admin_outHairshopListForm");
   		
   		return mav;
   	}
   	
   	//회원관리 - 기업회원상태 바꾸기(탈퇴)
   	@RequestMapping("/admin_makeHairshopOut.do")
   	public ModelAndView admin_makeHairshopOut(@RequestParam("hairshops_id")String hairshops_id) {
   		
   		String id[]=hairshops_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<id.length;i++) {
   			
   			result=hairshopDao.makeHairshopOut(id[i]);
   		}
   		String msg=result>0?"탈퇴처리 되었습니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.setViewName("admin/stateMsg");
   		
   		return mav;
   	}
   	
   	//회원관리 - 메세지 팝업창 띄우기
   	@RequestMapping("/admin_eachHairshopMsgForm.do")
   	public ModelAndView admin_eachHairshopMsgForm(@RequestParam("hairshops_id")String hairshops_id) {
   		
   		String id[]=hairshops_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("hairshops_id", hairshops_id);
   		mav.setViewName("admin/msg/admin_eachHairshopMsgForm");
   		
   		return mav;
   	}
   	
   	//회원관리 - 선택한 기업회원에게 메세지 보내기
   	@RequestMapping("/admin_eachHairshopMsgSend.do")
   	public ModelAndView admin_eachHairshopMsgSend(@RequestParam("message_content")String message_content,
   												  @RequestParam("hairshops_id")String hairshops_id) {
   		
   		String id[]=hairshops_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<id.length;i++) {
   			
   			result=msgDao.admin_eachHairshopMsgSend(message_content, id[i]);
   		}
   		String msg=result>0?"메세지 보내기 성공!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.setViewName("admin/Msg");
   		
   		return mav;
   	}
   	
   	//회원관리 - 레벨 팝업창 띄우기
   	@RequestMapping("/admin_hairshopLevelForm.do")
   	public ModelAndView admin_hairshopLevelForm(@RequestParam("hairshops_id")String hairshops_id) {
   		
   		String id[]=hairshops_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("hairshops_id", hairshops_id);
   		mav.setViewName("admin/hairshop/admin_hairshopLevelForm");
   		
   		return mav;
   	}
   	
   	//회원관리 - 레벨 바꾸기
   	@RequestMapping("/admin_setHairshopLevel.do")
   	public ModelAndView admin_setHairshopLevel(@RequestParam("hairshop_level")String hairshop_level,
   											   @RequestParam("hairshops_id")String hairshops_id) {
   		
   		String id[]=hairshops_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<id.length;i++) {
   			result=hairshopDao.setHairshopLevel(hairshop_level, id[i]);
   		}
   		String msg=result>0?"레벨 바꾸기에 성공하였습니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.setViewName("admin/stateMsg");
   		
   		return mav;
   	}
   	
   	//회원관리 - 기업 정보 수정 팝업창 띄우기
   	@RequestMapping("/admin_updateHairshopInfoForm.do")
   	public ModelAndView admin_updateHairshopInfoForm(@RequestParam("hairshop_idx")int hairshop_idx) {
   		
   		HairShopDTO dto=hairshopDao.hairshopInfo(hairshop_idx);
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("hairshop_idx", hairshop_idx);
   		mav.addObject("dto", dto);
   		mav.setViewName("admin/hairshop/admin_updateHairshopInfoForm");
   		
   		return mav;
   	}
   	
   	//회원관리 - 기업 정보 수정하기
   	@RequestMapping("/admin_updateHairshopInfo.do")
   	public ModelAndView admin_updateHairshopInfo(HairShopDTO dto) {
   		
   		int result=hairshopDao.updateHairshopInfo(dto);
   		
   		String msg=result>0?"정보를 수정했습니다!":"다시 시도해주세요!";
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("msg", msg);
   		mav.setViewName("admin/Msg");
   		
   		return mav;
   	}
   	
   	//회원관리 - 탈퇴,블랙 취소 팝업창 띄우기
   	@RequestMapping("/admin_normalHairshopListForm.do")
   	public ModelAndView admin_normalHairshopListForm(@RequestParam("hairshops_id")String hairshops_id) {
   		
   		String id[]=hairshops_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("hairshops_id", hairshops_id);
   		mav.setViewName("admin/hairshop/admin_normalHairshopListForm");
   		
   		return mav;
   	}
   	
   	//회원관리 - 탈퇴,블랙 취소하기
   	@RequestMapping("/admin_makeHairshopNormal.do")
   	public ModelAndView admin_makeHairshopNormal(@RequestParam("hairshops_id")String hairshops_id) {
   		
   		String id[]=hairshops_id.split(",");
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<id.length;i++) {
   			
   			result=hairshopDao.makeHairshopNormal(id[i]);
   		}
   		String msg=result>0?"정상처리 되었습니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.setViewName("admin/stateMsg");
   		
   		return mav;
   	}
   	
  //회원관리 - 검색하기
    @RequestMapping("/admin_hairshopSearchAjax.do")
    public ModelAndView admin_hairshopSearchAjax(@RequestParam("hairshop_id")String hairshop_id) {
       
       List<HairShopDTO> searchList=hairshopDao.hairshopSearch(hairshop_id);
       
       ModelAndView mav=new ModelAndView();
       mav.addObject("searchList", searchList);
       mav.addObject("hairshop_state", searchList.get(0).getHairshop_state());
       mav.setViewName("admin/hairshop/admin_hairshopSearchList");
       
       return mav;
    }
   	/*----------------------------------------------------------------------------------------------------------------------------------------------*/
   	
   	//게시글 관리 - 게시글 목록으로 페이지 이동하기
   	@RequestMapping("/admin_hairshop_bbsList.do")
   	public ModelAndView admin_hairshop_bbsList() {
   		
   		ModelAndView mav=new ModelAndView();		
   		mav.setViewName("admin/bbs/admin_hairshop_bbsList");
   		
   		return mav;
   	}
   	
   	//게시글 관리 - 게시글 목록보기
   	@RequestMapping("/admin_hairshop_bbsState.do")
   	public ModelAndView admin_hairshop_bbsState(@RequestParam(value="cp",defaultValue="1")int cp,
   			 								    @RequestParam("hairshop_bbs_state")int state) {
   		
   		ModelAndView mav=new ModelAndView();
   		
   		//페이징
   		int totalCnt=0;
   		int listSize=5;
   		int pageSize=5;
   				
   		String pageStr=null;
   		
   		//목록
   		List<HairShop_BbsDTO> list=null;
   		
   		if(state==1) {
   			
   			totalCnt=hairshopDao.normalHairshop_bbsTotalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=hairshopDao.hairshop_bbsList(cp,listSize); //게시글 목록
   			mav.setViewName("admin/bbs/admin_hairshop_bbsState1");
   			
   		}else if(state==0) {
   			
   			totalCnt=hairshopDao.notOpenHairshop_bbsTotalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=hairshopDao.notOpenHairshop_bbsList(cp,listSize);//비공개 게시글 목록
   			mav.setViewName("admin/bbs/admin_hairshop_bbsState0");
   			
   		}else if(state==2) {
   			
   			totalCnt=hairshopDao.deleteHairshop_bbsTotalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=hairshopDao.deleteHairshop_bbsList(cp,listSize);//삭제 게시글 목록
   			mav.setViewName("admin/bbs/admin_hairshop_bbsState2");			
   		}
   		
   		mav.addObject("paging", pageStr);
   		mav.addObject("list", list);
   		
   		return mav;
   	}
   	
   	//게시글 관리 - 게시글 내용 팝업창 띄우기
   	@RequestMapping("/admin_checkBbsContentForm.do")
   	public ModelAndView admin_checkBbsContentForm(@RequestParam("hairshop_bbs_idx")int hairshop_bbs_idx) {
   		
   		HairShop_BbsDTO dto=hairshopDao.hairshop_bbsContent(hairshop_bbs_idx);
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("hairshop_bbs_idx", hairshop_bbs_idx);
   		mav.addObject("dto", dto);
   		mav.setViewName("admin/bbs/admin_checkBbsContentForm");
   		
   		return mav;
   	}
   	
   	//게시글 관리 - 게시글 상태 바꾸기(비공개)
   	@RequestMapping("/admin_makeBbsNotOpen.do")
   	public ModelAndView admin_makeBbsNotOpen(@RequestParam("hairshop_bbs_idx")String hairshop_bbs_idx) {
   		
   		String idx[]=hairshop_bbs_idx.split(",");
   		
   		//String[] -> int[] 변환
   		int bbs_idx[]=new int[idx.length];
   		
   		for(int i=0;i<idx.length;i++) {
   			bbs_idx[i]=Integer.parseInt(idx[i]);
   		}
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<idx.length;i++) {
   			
   			result=hairshopDao.makeBbsNotOpen(bbs_idx[i]);
   		}
   		String msg=result>0?"비공개 처리되었습니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.addObject("goPage", "admin_hairshop_bbsList.do");
   		mav.setViewName("admin/stateMsg2");
   		
   		return mav;	
   	}
   	
   	//게시글 관리 - 게시글 상태 바꾸기(삭제)
   	@RequestMapping("/admin_makeBbsDelete.do")
   	public ModelAndView admin_makeBbsDelete(@RequestParam("hairshop_bbs_idx")String hairshop_bbs_idx) {
   		
   		String idx[]=hairshop_bbs_idx.split(",");
   		
   		//String[] -> int[] 변환
   		int bbs_idx[]=new int[idx.length];
   		
   		for(int i=0;i<idx.length;i++) {
   			bbs_idx[i]=Integer.parseInt(idx[i]);
   		}
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<idx.length;i++) {
   			
   			result=hairshopDao.makeBbsDelete(bbs_idx[i]);
   		}
   		String msg=result>0?"삭제 처리되었습니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.addObject("goPage", "admin_hairshop_bbsList.do");
   		mav.setViewName("admin/stateMsg2");
   		
   		return mav;	
   	}
   	
   	//게시글 관리 - 게시글 비공개,삭제 취소하기
   	@RequestMapping("/admin_makeBbsNormal.do")
   	public ModelAndView admin_makeBbsNormal(@RequestParam("hairshop_bbs_idx")String hairshop_bbs_idx) {
   		
   		String idx[]=hairshop_bbs_idx.split(",");
   		
   		//String[] -> int[] 변환
   		int bbs_idx[]=new int[idx.length];
   		
   		for(int i=0;i<idx.length;i++) {
   			bbs_idx[i]=Integer.parseInt(idx[i]);
   		}
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<idx.length;i++) {
   			
   			result=hairshopDao.makeBbsNormal(bbs_idx[i]);
   		}
   		String msg=result>0?"정상 처리되었습니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.addObject("goPage", "admin_hairshop_bbsList.do");
   		mav.setViewName("admin/stateMsg2");
   		
   		return mav;	
   	}
   	
   	//게시글 관리 - 검색하기
   	@RequestMapping("/admin_bbsSearchAjax.do")
   	public ModelAndView admin_bbsSearchAjax(@RequestParam("select")String select,
   											@RequestParam("bbsSearch")String bbsSearch) {
   		
   		List<HairShop_BbsDTO> searchList=hairshopDao.bbsSearch(select, bbsSearch);
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("searchList", searchList);
   		mav.setViewName("admin/bbs/admin_hairshop_bbsSearchList");
   		
   		return mav;
   	}
   	
   	/*----------------------------------------------------------------------------------------------------------------------------------------------*/
   	
   	//스폰 관리 - 페이지 이동하기
   	@RequestMapping("/admin_sponList.do")
   	public ModelAndView admin_sponList() {
   		
   		int startSponTotalPrice=sponDao.startSponTotalPrice(); //진행 스폰 총 금액
   		int finishSponTotalPrice=sponDao.finishSponTotalPrice(); //종료 스폰 총 금액
   				
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("startSponTotalPrice", startSponTotalPrice);
   		mav.addObject("finishSponTotalPrice", finishSponTotalPrice);
   		mav.setViewName("admin/spon/admin_sponList");
   		
   		return mav;
   	}
   	
   	//스폰 관리 - 스폰 목록보기
   	@RequestMapping("/admin_sponState.do")
   	public ModelAndView admin_sponState(@RequestParam(value="cp",defaultValue="1")int cp,
   			 							@RequestParam("spon_state")int state) {
   		
   		ModelAndView mav=new ModelAndView();
   		
   		//페이징
   		int totalCnt=0;
   		int listSize=5;
   		int pageSize=5;
   		
   		String pageStr=null;
   		
   		//목록
   		List<SponDTO> list=null;
   		
   		if(state==0) {
   			
   			totalCnt=sponDao.readySpon_totalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=sponDao.readySponList(cp,listSize); //대기 스폰 목록
   			mav.addObject("paging", pageStr);
   			mav.addObject("list", list);
   			mav.setViewName("admin/spon/admin_sponState0");
   			
   		}else if(state==4) {
   			
   			totalCnt=sponDao.joinSpon_totalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=sponDao.joinSponList(cp,listSize); //승인 스폰 목록
   			mav.addObject("paging", pageStr);
   			mav.addObject("list", list);
   			mav.setViewName("admin/spon/admin_sponState4");
   			
   		}else if(state==1) {
   			
   			totalCnt=sponDao.startSpon_totalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=sponDao.startSponList(cp,listSize); //진행 스폰 목록
   			mav.addObject("paging", pageStr);
   			mav.addObject("list", list);
   			mav.setViewName("admin/spon/admin_sponState1");
   			
   		}else if(state==2) {
   			
   			totalCnt=sponDao.finishSpon_totalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=sponDao.finishSponList(cp,listSize); //종료 스폰 목록
   			mav.addObject("paging", pageStr);
   			mav.addObject("list", list);
   			mav.setViewName("admin/spon/admin_sponState2");
   			
   		}else if(state==3) {
   			
   			totalCnt=sponDao.cancelSpon_totalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=sponDao.cancelSponList(cp,listSize); //취소 스폰 목록
   			mav.addObject("paging", pageStr);
   			mav.addObject("list", list);
   			mav.setViewName("admin/spon/admin_sponState3");
   			
   		}else if(state==5) {
   			
   			totalCnt=sponDao.rejectSpon_totalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=sponDao.rejectSponList(cp,listSize); //미 승인 스폰 목록
   			mav.addObject("paging", pageStr);
   			mav.addObject("list", list);
   			mav.setViewName("admin/spon/admin_sponState5");			
   		}
   		return mav;
   	}
   		
   	//스폰 관리 - 스폰 내용 확인하기
   	@RequestMapping("/admin_checkSponInfoForm.do")
   	public ModelAndView admin_checkSponInfoForm(@RequestParam("spon_idx")int spon_idx,
   												@RequestParam("spon_state")int spon_state,
   												@RequestParam("hairshop_idx")int hairshop_idx) {
   			
   		String sponInfo=sponDao.sponInfo(spon_idx);
   		sponInfo.replaceAll("\n", "<br>");
   			
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("spon_idx", spon_idx);
   		mav.addObject("spon_state", spon_state);
   		mav.addObject("hairshop_idx", hairshop_idx);
   		mav.addObject("sponInfo", sponInfo);
   		mav.setViewName("admin/spon/admin_checkSponInfoForm");
   			
   		return mav;
   	}
   	
   	//스폰 관리 - 스폰 승인하기 + 스폰 승인하면 게시글level도 바꾸기
   	@RequestMapping("/admin_makeSponJoin.do")
   	public ModelAndView admin_makeSponJoin(@RequestParam("spon_idx")int spon_idx,
   										   @RequestParam("hairshop_idx")int hairshop_idx) {
   		
   		int result=sponDao.makeSponJoin(spon_idx);
   		int result2=sponDao.makeBbsJoin(hairshop_idx);
   		String msg=result>0?"스폰 등록이 승인되었습니다!":"다시 시도해주세요!";
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("msg", msg);
   		mav.setViewName("admin/stateMsg");
   		
   		return mav;
   	}
   	
   	//스폰 관리 - 스폰 미 승인하기
   	@RequestMapping("/admin_rejectSponJoin.do")
   	public ModelAndView admin_rejectSponJoin(@RequestParam("spon_idx")int spon_idx) {
   		
   		int result=sponDao.rejectSponJoin(spon_idx);
   		String msg=result>0?"스폰 등록이 미 승인되었습니다!":"다시 시도해주세요!";
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("msg", msg);
   		mav.setViewName("admin/stateMsg");
   		
   		return mav;
   	}
   	
   	//스폰 관리 - 스폰 진행시키기
   	@RequestMapping("/admin_makeSponStart.do")
   	public ModelAndView admin_makeSponStart(@RequestParam("spon_idx")String spon_idx) {
   		
   		String idx[]=spon_idx.split(",");
   		int s_idx[]=new int[idx.length];
   		String[] kinds = new String[idx.length];
   		int[] hairshop_idx_s = new int[idx.length];
   		
   		for(int i=0;i<idx.length;i++) {
   			String[] info_temp = idx[i].split("_");
   			s_idx[i]=Integer.parseInt(info_temp[0]);//스폰 idx
   			String[] hairshop_info = info_temp[1].split("-");
   			kinds[i]=hairshop_info[0];
   			hairshop_idx_s[i] = Integer.parseInt(hairshop_info[1]);
   		}
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<idx.length;i++) {
   			if(kinds[i].equals("파워게시글"))
   			{
   				System.out.println(s_idx[i]);
   				System.out.println(hairshop_idx_s[i]);
   			
   			result=sponDao.makeSponStart(s_idx[i]);
   			hairshop_bbs_spon(hairshop_idx_s[i], 1);
   			}
   			else if(kinds[i].equals("파워헤어샵"))
   			{
   			result=sponDao.makeSponStart(s_idx[i]);
   			hairshop_spon(hairshop_idx_s[i], 1);
   			}
   		}
   		String msg=result>0?"스폰을 진행합니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.addObject("goPage", "admin_sponList.do");
   		mav.setViewName("admin/stateMsg2");
   		
   		return mav;
   	}
   	
   	//스폰 관리 - 스폰 취소시키기
   	@RequestMapping("admin_makeSponCancel.do")
   	public ModelAndView admin_makeSponCancel(@RequestParam("spon_idx")String spon_idx) {
   		
   		String idx[]=spon_idx.split(",");
   		int s_idx[]=new int[idx.length];
   		String[] kinds = new String[idx.length];
   		int[] hairshop_idx_s = new int[idx.length];
   		
   		for(int i=0;i<idx.length;i++) {
   			String[] info_temp = idx[i].split("_");
   			s_idx[i]=Integer.parseInt(info_temp[0]);//스폰 idx
   			String[] hairshop_info = info_temp[1].split("-");
   			kinds[i]=hairshop_info[0];
   			hairshop_idx_s[i] = Integer.parseInt(hairshop_info[1]);
   		}
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
 		for(int i=0;i<idx.length;i++) {
   			if(kinds[i].equals("파워게시글"))
   			{
   			result=sponDao.makeSponCancel(s_idx[i]);
   			hairshop_bbs_spon(hairshop_idx_s[i], 0);
   			}
   			else if(kinds[i].equals("파워헤어샵"))
   			{
   			result=sponDao.makeSponCancel(s_idx[i]);
   			hairshop_spon(hairshop_idx_s[i], 0);
   			}
   		}
   		String msg=result>0?"스폰을 취소합니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.addObject("goPage", "admin_sponList.do");
   		mav.setViewName("admin/stateMsg2");
   		
   		return mav;
   	}
   	
   	//스폰 관리 - 스폰 종료시키기
   	@RequestMapping("admin_makeSponFinish.do")
   	public ModelAndView admin_makeSponFinish(@RequestParam("spon_idx")String spon_idx) {
   		
   		String idx[]=spon_idx.split(",");
   		int s_idx[]=new int[idx.length];
   		String[] kinds = new String[idx.length];
   		int[] hairshop_idx_s = new int[idx.length];
   		
   		for(int i=0;i<idx.length;i++) {
   			String[] info_temp = idx[i].split("_");
   			s_idx[i]=Integer.parseInt(info_temp[0]);//스폰 idx
   			String[] hairshop_info = info_temp[1].split("-");
   			kinds[i]=hairshop_info[0];
   			hairshop_idx_s[i] = Integer.parseInt(hairshop_info[1]);
   		}
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<idx.length;i++) {
   			if(kinds[i].equals("파워게시글"))
   			{
   			result=sponDao.makeSponFinish(s_idx[i]);
   			hairshop_bbs_spon(hairshop_idx_s[i], 0);
   			}
   			else if(kinds[i].equals("파워헤어샵"))
   			{
   			result=sponDao.makeSponFinish(s_idx[i]);
   			hairshop_spon(hairshop_idx_s[i], 0);
   			}
   		}
   		String msg=result>0?"스폰을 종료합니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.addObject("goPage", "admin_sponList.do");
   		mav.setViewName("admin/stateMsg2");
   		
   		return mav;
   	}
   	
   	/*----------------------------------------------------------------------------------------------------------------------------------------------*/
   	
   	//메세지 관리 - 페이지 이동
   	@RequestMapping("/admin_msgList.do")
   	public ModelAndView admin_msgList() {
   		
   		ModelAndView mav=new ModelAndView();
   		mav.setViewName("admin/msg/admin_msgList");
   		
   		return mav;
   	}
   	
   	//메세지 관리 - 받은 메세지 + 보낸 메세지 목록보기
   	@RequestMapping("/admin_messageState.do")
   	public ModelAndView admin_messageState(@RequestParam(value="cp",defaultValue="1")int cp,
   										   @RequestParam("message_state")int state) {
   		
   		ModelAndView mav=new ModelAndView();
   		
   		//페이징
   		int totalCnt=0;
   		int listSize=5;
   		int pageSize=5;
   				
   		String pageStr=null;
   				
   		//목록
   		List<MessageDTO> list = null;
   		
   		if(state==1) {
   			
   			totalCnt=msgDao.receiveMsgFromShop_totalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=msgDao.receiveMsgListFromShop(cp,listSize); //기업에게 받은 메세지 목록
   			mav.addObject("paging", pageStr);
   			mav.addObject("list", list);
   			mav.setViewName("admin/msg/admin_messageState1");
   			
   		}else if(state==2) {
   			
   			totalCnt=msgDao.sendMsgToMember_totalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=msgDao.sendMsgListToMember(cp,listSize); //회원에게 보낸 메세지 목록
   			mav.addObject("paging", pageStr);
   			mav.addObject("list", list);
   			mav.setViewName("admin/msg/admin_messageState2");
   			
   		}else if(state==3) {
   			
   			totalCnt=msgDao.sendMsgToShop_totalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=msgDao.sendMsgListToShop(cp,listSize); //기업에게 보낸 메세지 목록
   			mav.addObject("paging", pageStr);
   			mav.addObject("list", list);
   			mav.setViewName("admin/msg/admin_messageState3");
   			
   		}else if(state==4) {
   			
   			totalCnt=msgDao.deleteMsg_totalCnt();
   			if(totalCnt==0)
			{
				totalCnt = 1;
			}
   			pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
   			list=msgDao.deleteMsgList(cp,listSize); //삭제한 메세지 목록
   			mav.addObject("paging", pageStr);
   			mav.addObject("list", list);
   			mav.setViewName("admin/msg/admin_messageState4");			
   		}
   		
   		return mav;
   	}
   	
   	//메세지 관리 - 기업에게 받은 메세지 내용보기 팝업창 띄우기
   	@RequestMapping("/admin_checkMsgContentForm_fromShop.do")
   	public ModelAndView admin_checkMsgContentForm_fromShop(@RequestParam("message_idx")int message_idx) {
   		
   		List<MessageDTO> checkMsg=msgDao.checkMsgContentFromShop(message_idx);
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("checkMsg", checkMsg);
   		mav.setViewName("admin/msg/admin_checkMsgContentForm_fromShop");
   		
   		return mav;	
   	}
   	
   	//메세지 관리 - 기업에게 답장하기 팝업창 띄우기
   	@RequestMapping("/admin_sendReplyForm_ToShop.do")
   	public ModelAndView admin_sendReplyForm_ToShop(@RequestParam("message_idx")int message_idx,
   												   @RequestParam("hairshop_id")String hairshop_id) {
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("message_idx", message_idx);
   		mav.addObject("hairshop_id", hairshop_id);
   		mav.setViewName("admin/msg/admin_sendReplyForm_ToShop");
   		
   		return mav;
   	}
   	
   	//메세지 관리 - 답장하기
   	@RequestMapping("/admin_sendReply.do")
   	public ModelAndView admin_sendReply(@RequestParam("message_idx")int message_idx,
   										@RequestParam("message_content")String message_content) {
   			
   		int result=msgDao.sendReply(message_idx, message_content);
   		String msg="";
   		
   		if(result>0) {
   			
   			int makeread=msgDao.makeMsgRead(message_idx);
   			
   			if(makeread>0) {
   				msg="성공적으로 답장을 보냈습니다!";
   			}
   			
   		}else {
   			msg="다시 시도해주세요!";
   		}
   			
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("msg", msg);
   		mav.setViewName("admin/stateMsg");
   			
   		return mav;
   	}
   	
  //메세지 관리 - 내용 확인 후 읽음 처리하기
    @RequestMapping(value="/admin_makeMsgRead.do",method=RequestMethod.POST)
    public ModelAndView admin_makeMsgRead(@RequestParam("message_idx")int message_idx) {
          
       int result=msgDao.makeMsgRead(message_idx);
       String msg=result>0?"확인했습니다!":"다시 시도해주세요!";
       
       ModelAndView mav=new ModelAndView();
       mav.addObject("msg", msg);
       mav.setViewName("admin/stateMsg");
          
       return mav;
    }
   	
   	//메세지 관리 - 회원에게 보낸 메세지 내용보기 팝업창 띄우기
   	@RequestMapping("/admin_checkMsgContentForm_ToMember.do")
   	public ModelAndView admin_checkMsgContentForm_ToMember(@RequestParam("message_idx")int message_idx) {
   		
   		List<MessageDTO> checkMsg=msgDao.checkMsgContentToMember(message_idx);
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("checkMsg", checkMsg);
   		mav.setViewName("admin/msg/admin_checkMsgContentForm_ToMember");
   		
   		return mav;	
   	}
   	
   	//메세지 관리 - 기업에게 보낸 메세지 내용보기 팝업창 띄우기
   	@RequestMapping("/admin_checkMsgContentForm_ToShop.do")
   	public ModelAndView admin_checkMsgContentForm_ToShop(@RequestParam("message_idx")int message_idx) {
   		
   		List<MessageDTO> checkMsg=msgDao.checkMsgContentToShop(message_idx);
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("checkMsg", checkMsg);
   		mav.setViewName("admin/msg/admin_checkMsgContentForm_ToShop");
   		
   		return mav;	
   	}
   	
   	//메세지 관리 - 휴지통에 있는 메세지 내용보기 팝업창 띄우기
   	@RequestMapping("/admin_checkMsgContentForm_FromDelete.do")
   	public ModelAndView admin_checkMsgContentForm_FromDelete(@RequestParam("message_idx")int message_idx) {
   		
   		List<MessageDTO> checkMsg=msgDao.checkMsgContentFromDelete(message_idx);
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("checkMsg", checkMsg);
   		mav.setViewName("admin/msg/admin_checkMsgContentForm_fromDelete");
   		
   		return mav;	
   	}
   	
   	//메세지 관리 - 팝업창에서 메세지 복구시키기
   	@RequestMapping(value="/admin_makeMsgNormal.do",method=RequestMethod.POST)
   	public ModelAndView admin_makeMsgNormal(@RequestParam("message_idx")int message_idx) {
   		
   		int result=msgDao.makeMsgNormal(message_idx);
   		String msg=result>0?"복구되었습니다!":"다시 시도해주세요!";
   		
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("msg", msg);
   		mav.setViewName("admin/stateMsg");
   			
   		return mav;
   	}
   	
   	//메세지 관리 - 메세지 상태 바꾸기(읽음)
   	@RequestMapping(value="/admin_makeMsgRead.do",method=RequestMethod.GET)
   	public ModelAndView admin_makeMsgRead(@RequestParam("message_idx")String msg_idx){
   		
   		String idx[]=msg_idx.split(",");
   		
   		int message_idx[]=new int[idx.length];
   		
   		for(int i=0;i<idx.length;i++) {
   			message_idx[i]=Integer.parseInt(idx[i]);
   		}
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<idx.length;i++) {
   			
   			result=msgDao.makeMsgRead(message_idx[i]);
   		}
   		String msg=result>0?"읽음 처리되었습니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.addObject("goPage", "admin_msgList.do");
   		mav.setViewName("admin/stateMsg2");
   		
   		return mav;
   	}
   	
   	//메세지 관리 - 메세지 상태 바꾸기(삭제)
   	@RequestMapping("/admin_makeMsgDelete.do")
   	public ModelAndView admin_makeMsgDelete(@RequestParam("message_idx")String msg_idx) {
   		
   		String idx[]=msg_idx.split(",");
   		
   		int message_idx[]=new int[idx.length];
   		
   		for(int i=0;i<idx.length;i++) {
   			message_idx[i]=Integer.parseInt(idx[i]);
   		}
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<idx.length;i++) {
   			
   			result=msgDao.makeMsgDelete(message_idx[i]);
   		}
   		String msg=result>0?"삭제 처리되었습니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.addObject("goPage", "admin_msgList.do");
   		mav.setViewName("admin/stateMsg2");
   		
   		return mav;
   	}
   	
   	//메세지 관리 - 메세지 복구하기
   	@RequestMapping(value="/admin_makeMsgNormal.do",method=RequestMethod.GET)
   	public ModelAndView admin_makeMsgNormal(@RequestParam("message_idx")String msg_idx) {
   		
   		String idx[]=msg_idx.split(",");
   		
   		int message_idx[]=new int[idx.length];
   		
   		for(int i=0;i<idx.length;i++) {
   			message_idx[i]=Integer.parseInt(idx[i]);
   		}
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<idx.length;i++) {
   			
   			result=msgDao.makeMsgNormal(message_idx[i]);
   		}
   		String msg=result>0?"복구되었습니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.addObject("goPage", "admin_msgList.do");
   		mav.setViewName("admin/stateMsg2");
   		
   		return mav;
   	}
   	
   	//메세지 관리 - 메세지 영구 삭제 확인 팝업창 띄우기
   	@RequestMapping("/admin_permanentlyDeleteMsgForm.do")
   	public ModelAndView admin_permanentlyDeleteMsgForm(@RequestParam("message_idx")String msg_idx) {
   		
   		String idx[]=msg_idx.split(",");
   				
   		ModelAndView mav=new ModelAndView();
   		mav.addObject("msg_idx", msg_idx);
   		mav.setViewName("admin/msg/admin_permanentlyDeleteMsgForm");
   		
   		return mav;
   	}
   	
   	//메세지 관리 - 메세지 영구 삭제하기
   	@RequestMapping("/admin_makeMsgPermanentlyDelete.do")
   	public ModelAndView admin_makeMsgPermanentlyDelete(@RequestParam("message_idx")String msg_idx) {
   		
   		String idx[]=msg_idx.split(",");
   		
   		int message_idx[]=new int[idx.length];
   		
   		for(int i=0;i<idx.length;i++) {
   			message_idx[i]=Integer.parseInt(idx[i]);
   		}
   		
   		ModelAndView mav=new ModelAndView();
   		
   		int result=0;
   		
   		for(int i=0;i<idx.length;i++) {
   			
   			result=msgDao.makeMsgPermanentlyDelete(message_idx[i]);
   		}
   		String msg=result>0?"영구적으로 삭제되었습니다!":"다시 시도해주세요!";
   		
   		mav.addObject("msg", msg);
   		mav.addObject("goPage", "admin_msgList.do");
   		mav.setViewName("admin/stateMsg");
   		
   		return mav;
   	}
   	
   	/*----------------------------------------------------------------------------------------------------------------------------------------------*/
}
