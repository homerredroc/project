package hair.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.ModelAndViewDefiningException;

import hair.hair.model.HairDAO;
import hair.hair.model.HairDTO;
import hair.hair.model.HairListDAO;
import hair.hair.model.HairOptionDTO;
import hair.hairshop.designer.model.DesignerDAO;
import hair.hairshop.designer.model.DesignerDTO;
import hair.hairshop.model.Favorite_HairShopDAO;
import hair.hairshop.model.HairShopDAO;
import hair.hairshop.model.HairShopDTO;
import hair.hairshop.model.HairShop_BbsDAO;
import hair.hairshop.model.HairShop_BbsDTO;
import hair.hairshop.model.HairShop_Bbs_GoodDAO;
import hair.hairshop.model.HairShop_Bbs_GoodDTO;
import hair.hairshop.model.HairShop_CouponDTO;
import hair.hairshop.model.HairShop_PhotoDTO;
import hair.hairshop.model.HairShop_Related_BbsDAO;
import hair.hairshop.model.Hairshop_PhotoDAO;
import hair.member.model.MemberDTO;
import hair.member.model.Member_ReviewDAO;
import hair.member.model.Member_ReviewDTO;
import hair.message.model.MessageDAO;
import hair.message.model.MessageDTO;
import hair.reservation.model.ReservationDTO;
import hair.spon.model.SponDTO;

@Controller
public class HairshopController {
	
	@Autowired
	private HairShop_BbsDAO Hairshop_BbsDao;
	@Autowired
	private HairShopDAO Hairshop_Dao;
	@Autowired
	private HairListDAO HairListDao;
	@Autowired
	private DesignerDAO DesignerDao;
	@Autowired
	private HairDAO HairDao;
	@Autowired
	private HairShop_Related_BbsDAO HairShop_Related_BbsDao;
	@Autowired
	private HairShop_Bbs_GoodDAO HairShop_Bbs_GoodDao;
	@Autowired
	private Hairshop_PhotoDAO Hairshop_PhotoDao;
	@Autowired
	private Favorite_HairShopDAO Favorite_HairShopDao;
	@Autowired
	private Member_ReviewDAO Member_ReviewDao;
	@Autowired
	private MessageDAO msgDao;



	
	
//  **********************************************************************

  /**
   * 사용자 입장의 헤어샵으로 이동하는 컨트롤러
   * @param hairshop_idx 헤어샵의 idx
   */   
  @RequestMapping("/member_hairshop_main.do")
  public ModelAndView member_hairshop_main(HttpSession session, int hairshop_idx) {
     ModelAndView mav = new ModelAndView();
     mav.setViewName("member/hairshop/member_hairshop_main");
     List<HairShop_PhotoDTO> list = Hairshop_PhotoDao.hairshop_photo(hairshop_idx);
     HairShopDTO hdto = Hairshop_Dao.hairhsopInfo(hairshop_idx);
     int member_idx;
     if(session.getAttribute("member_idx")==null) {
        member_idx=0;
     }else {
        member_idx=(Integer) session.getAttribute("member_idx");
     }
     int followcheck=Favorite_HairShopDao.hairshop_good_check(hairshop_idx, member_idx);
     mav.addObject("hdto", hdto);
     mav.addObject("followcheck", followcheck);
     mav.addObject("list", list);
     
     return mav;
  }

  /**
   * 사용자 입장의 헤어샵에서 스타일로 이동하는 컨트롤러
   * @param hairshop_idx 헤어샵의 idx
   * @param cp페이징의 위치
   */   
  @RequestMapping("/member_hairshop_style.do")
  public ModelAndView member_hairshop_style(@RequestParam(value="cp",required=false,defaultValue="1")Integer cp,int hairshop_idx) {
     ModelAndView mav = new ModelAndView();
     HairShopDTO hdto = Hairshop_Dao.hairhsopInfo(hairshop_idx);
     mav.addObject("hdto", hdto);
     mav.setViewName("member/hairshop/member_hairshop_style");
     int listSize=15;
     int pageSize=5;
     int totalCnt=Hairshop_BbsDao.member_hairshop_bbs_totalcnt(hairshop_idx);
     String param="&hairshop_idx="+hairshop_idx;
     String pageStr=hair.paging.PageModule.makePage("member_hairshop_style.do", totalCnt, listSize, pageSize, cp,param);
     mav.addObject("pageStr",pageStr);
     List<HairShop_BbsDTO> blist = Hairshop_BbsDao.member_hairshop_bbs_list(hairshop_idx,cp,listSize);
     mav.addObject("blist",blist);
     return mav;
  }
  
  /**
   * 사용자 입장의 헤어샵에서 디자이너 리스트로 이동하는 컨트롤러
   * @param hairshop_idx 헤어샵의 idx
   */   
  @RequestMapping("/member_hairshop_designer.do")
  public ModelAndView member_hairshop_designer(int hairshop_idx) {
     ModelAndView mav = new ModelAndView();
     HairShopDTO hdto = Hairshop_Dao.hairhsopInfo(hairshop_idx);
     mav.addObject("hdto", hdto);
     mav.setViewName("member/hairshop/member_hairshop_designer");
     List<DesignerDTO> dlist = DesignerDao.designerList(hairshop_idx);
     mav.addObject("dlist",dlist);
     return mav;
  }
  
  /**
   * 사용자 입장의 헤어샵에서 리뷰목록으로 이동하는 컨트롤러
   * @param hairshop_idx 헤어샵의 idx
   * @param cp페이징의 위치
   */   
  @RequestMapping("/member_hairshop_review.do")
  public ModelAndView member_hairshop_review(@RequestParam(value="cp",required=false,defaultValue="1")Integer cp,int hairshop_idx) {
     ModelAndView mav = new ModelAndView();
     HairShopDTO hdto = Hairshop_Dao.hairhsopInfo(hairshop_idx);
     mav.addObject("hdto", hdto);
     mav.setViewName("member/hairshop/member_hairshop_review");
     int listSize=15;
     int pageSize=5;
     List<Member_ReviewDTO> rlist = Member_ReviewDao.member_member_review_list(cp, listSize, hairshop_idx);
     mav.addObject("rlist",rlist);

     int totalCnt=Member_ReviewDao.member_member_review_totalcnt(hairshop_idx);
     String param="&hairshop_idx="+hairshop_idx;
     String pageStr=hair.paging.PageModule.makePage("member_hairshop_review.do", totalCnt, listSize, pageSize, cp,param);
     mav.addObject("pageStr",pageStr);
     return mav;
  }

  /**
   * 사용자 입장의 헤어샵에서 문의하기를 눌렀을때 팝업을 위해
   * @param hairshop_idx 헤어샵의 idx
   */   
     @RequestMapping("/member_hairshop_masage.do")
     public ModelAndView member_hairshop_masage(@RequestParam("hairshop_idx")int hairshop_idx) {

        HairShopDTO hdto = Hairshop_Dao.hairhsopInfo(hairshop_idx);
        ModelAndView mav=new ModelAndView();
     mav.addObject("hdto", hdto);      

        mav.addObject("hairshop_idx", hairshop_idx);
        mav.setViewName("member/hairshop/member_hairshop_masage");
        
        return mav;
     }
     
  /**
   * 헤어샵  관심을 눌렀을때 값을 ajax로 넘겨주는 컨트롤러
   * @param member_idx 추천을 누른 회원의 idx
   * @param hairshop_bbs_idx 추천을 눌리는 글의 idx
   */
  @RequestMapping("/hairshop_good_ajax.do")
  public ModelAndView hairshop_good_ajax(int member_idx, int hairshop_idx) {
     ModelAndView mav= new ModelAndView();
     int result=Favorite_HairShopDao.HairShop_Good(hairshop_idx, member_idx);
     String msg=result==1?"following":"follow";
     mav.addObject("msg",msg);
     mav.setViewName("member/hairshop/member_hairshop_good_ajax");
     return mav;
  }
  
  /**
   * 헤어샵 문의하기로 쪽지를 보내는 컨트롤러
   * @param member_idx 보내는 회원의 idx
   * @param hairshop_bbs_idx 받는 헤어샵의 idx
   * @param content 내용
   */
  @RequestMapping("/member_hairshop_masageSend.do")
  public ModelAndView member_hairshop_masageSend(int hairshop_idx, int member_idx, String content) {
     ModelAndView mav = new ModelAndView();
        int result=0;
        
        result=msgDao.member_hairshop_masage(hairshop_idx, member_idx, content);

        
        String msg=result>0?"메세지 보내기 성공!":"메세지 보내기 실패!";
        
        mav.addObject("msg", msg);
        mav.setViewName("admin/Msg");
        
        return mav;
  }
  

  
	
	
	
	
	
	/**
	 * 헤어샵 글쓰기로 진입하는 컨트롤러
	 */
	@RequestMapping("/hairshop_header.do")
	public String header()
	{
		return "hairshop/hairshop_header.jsp";
	}
	

	@RequestMapping(value="/hairshopBbsWrite.do")
	public String HairshopBbsWrite() {
		return "hairshop/bbs/hairshop_bbs_write";
	}
	
	/**
	 * 헤어샵 글쓰기시 관련게시글 팝업을 여는 컨트롤러
	 * @param hairshop_idx글을 쓰는 헤어샵의 idx
	 */
	@RequestMapping(value="/Related_BbsOpen.do")
	public ModelAndView HairshopRelatedBbs(int hairshop_idx) {
		ModelAndView mav= new ModelAndView();
		List<HairShop_BbsDTO> list = Hairshop_BbsDao.HairshopRelatedBbsForm(hairshop_idx);
		mav.addObject("list",list);
		mav.setViewName("hairshop/bbs/RelatedBbsPopup");
		return mav;
	}	
	

	
	/**
	 * 헤어샵 글쓰기시 정보를 모델에게 넘겨주는 컨트롤러
	 * @param dto 글에 정보를 담고 있는 HairShop_BbsDTO
	 * @param relatedBbs 관련게시글을 한줄로 받아오는 파라미터
	 */
	@RequestMapping(value="/hairshopBbsWrite_ok.do")
	public ModelAndView HairshopBbsWrite_ok(HairShop_BbsDTO dto,
			@RequestParam(value="relatedBbs",required=false)String relatedBbs) {
	
		int result=Hairshop_BbsDao.hairshopBbsWrite(dto);
		
		System.out.println(relatedBbs);
		if(relatedBbs!=null&&!relatedBbs.equals("")) {
			int hairshopBbsIdx=HairShop_Related_BbsDao.RelatedRowNum(dto.getHairshop_idx());
			System.out.println("실행됨"+relatedBbs);
		    String[] relatedBbsArray;
		    relatedBbsArray = relatedBbs.split(",");
		    for(int i=0; i<relatedBbsArray.length; i++) {
		    	HairShop_Related_BbsDao.hairshopRelatedBbsWrite(hairshopBbsIdx,Integer.parseInt(relatedBbsArray[i]));
		    }			
		}
	    
		String msg=result>0?"성공":"실패";
		ModelAndView mav = new ModelAndView();
		mav.addObject("msg",msg);
		mav.addObject("goPage","hairshop_portfolio.do");
		mav.setViewName("hairshop/bbs/msg");
		return mav;
	}
	
	
	/**
	 * 헤어샵 본문보기시 폼으로 정보와 함께 이동하는 컨트롤러
	 * @param hairshop_bbs_idx 글을 구분하기 위한 헤어샵 본문 idx
	 */
	@RequestMapping(value="/hairshopBbs.do")
	public ModelAndView HairshopBbs(int hairshop_bbs_idx) {

		HairShop_BbsDTO bdto = Hairshop_BbsDao.hairhsopBbs(hairshop_bbs_idx);
		HairDTO hdto = HairDao.HairInfo(bdto.getHair_idx());
		DesignerDTO ddto = DesignerDao.designerInfo(bdto.getDesigner_idx());
		HairShopDTO hsdto = Hairshop_Dao.hairhsopInfo(bdto.getHairshop_idx());
		int goodSum= HairShop_Bbs_GoodDao.HairShop_Bbs_SumGood(hairshop_bbs_idx);
		List<HairShop_BbsDTO> relatedlist = Hairshop_BbsDao.HairshopRelatedBbsList(hairshop_bbs_idx);
		HairOptionDTO odto = HairDao.hairoption_select(bdto.getHairshop_idx());
		ModelAndView mav = new ModelAndView();
		mav.addObject("option",odto);
		mav.addObject("bdto",bdto);
		mav.addObject("hdto",hdto);
		mav.addObject("ddto",ddto);
		mav.addObject("hsdto",hsdto);
		mav.addObject("goodSum",goodSum);
		mav.addObject("relatedlist",relatedlist);
		mav.setViewName("hairshop/bbs/hairshop_bbs");
		return mav;
	}
	
	
	
	/**
	 * 헤어샵 글쓰기시 이미지 정보를 모델에게 넘겨주는 컨트롤러
	 */
	@RequestMapping(value = "/fileUpload.do", method = RequestMethod.POST)
	public String fileUpload(Model model, MultipartRequest multipartRequest, HttpServletRequest request) throws IOException{
		MultipartFile imgfile = multipartRequest.getFile("Filedata");
		Calendar cal = Calendar.getInstance();
		String fileName = imgfile.getOriginalFilename();
		String fileType = fileName.substring(fileName.lastIndexOf("."), fileName.length());
		String replaceName = cal.getTimeInMillis() + fileType;  
		System.out.println("이름:"+replaceName);
		String path = request.getSession().getServletContext().getRealPath("/")+File.separator+"resources/upload";		
		System.out.println(path);
		Hairshop_BbsDao.fileUpload(imgfile, path, replaceName);
		model.addAttribute("path", path);
		model.addAttribute("filename", replaceName);
		return "hairshop/bbs/file_upload";
	}
	
	
	/**
	 * 헤어샵 글쓰기시 호출되는 헤어리스트를 ajax로 넘겨주는 컨트롤러
	 * @param designer_idx 호출할 디자이너의 idx
	 */
	@RequestMapping("/hairlist_ajax.do")
	   public ModelAndView hairlist_ajax(int designer_idx)
	   {
	      ModelAndView mav = new ModelAndView();
	      List<HairDTO> list = HairListDao.hair_list(designer_idx);
	      mav.addObject("list",list);
	      mav.setViewName("hairshop/bbs/hairlist_ajax");
	      return mav;
	   }

	
	/**
	 * 헤어샵 글쓰기시 호출되는 디자이너리스트를 ajax로 넘겨주는 컨트롤러
	 * @param hairshop_idx 호출할 헤어샵의 idx
	 */
	@RequestMapping("/desig_list_ajax.do")
	   public  ModelAndView desig_list_ajax(int hairshop_idx)
	   {
	      ModelAndView mav = new ModelAndView();
	      List<DesignerDTO> list = DesignerDao.desig_list(hairshop_idx);
	      mav.addObject("list", list);
	      mav.setViewName("hairshop/bbs/desig_list_ajax");
	      return mav;
	   }
	
	/**
	 * 헤어샵 본문보기 추천을 눌렀을때 값을 ajax로 넘겨주는 컨트롤러
	 * @param member_idx 추천을 누른 회원의 idx
	 * @param hairshop_bbs_idx 추천을 눌리는 글의 idx
	 */
	@RequestMapping("/hairshop_bbs_good_ajax.do")
	public ModelAndView hairshop_bbs_good_ajax(int member_idx, int hairshop_bbs_idx) {
		ModelAndView mav= new ModelAndView();
		int goodSum=HairShop_Bbs_GoodDao.HairShop_Bbs_Good(hairshop_bbs_idx, member_idx);
		mav.addObject("goodSum",goodSum);
		mav.setViewName("hairshop/bbs/good_ajax");
		return mav;
	}
	
	/**
	 * 헤어샵 본문 삭제를 하는 컨트롤러
	 * @param hairshop_bbs_idx 삭제를 눌리는 글의 idx
	 */
	@RequestMapping("/hairshop_bbs_del.do")
	public ModelAndView hairshop_bbs_del(int hairshop_bbs_idx) {
		ModelAndView mav= new ModelAndView();
		int result=Hairshop_BbsDao.hairshop_bbs_del(hairshop_bbs_idx);
		String msg=result>0?"성공":"실패";
		mav.addObject("msg",msg);
		mav.setViewName("hairshop/bbs/msg");
		mav.addObject("goPage","/hair");
		return mav;
	}
	
	
	   /**
	    * 헤어샵 업데이트 폼으로 넘어가는 컨트롤러
	    * @param hairshop_bbs_idx 수정을 눌리는 글의 idx
	    */   
	   @RequestMapping("/hairshop_bbs_update.do")
	   public ModelAndView hairshop_bbs_update(int hairshop_bbs_idx) {
	      HairShop_BbsDTO bdto = Hairshop_BbsDao.hairhsopBbs(hairshop_bbs_idx);
	      List<HairShop_BbsDTO> relatedlist = Hairshop_BbsDao.HairshopRelatedBbsList(hairshop_bbs_idx);
	      ModelAndView mav = new ModelAndView();
	      mav.addObject("bdto",bdto);
	      mav.addObject("relatedlist",relatedlist);
	      String relatedidx="";
	      for(int i=0; i<relatedlist.size(); i++) {
	         relatedidx+=relatedlist.get(i).getHairshop_bbs_idx()+",";
	      }
	      mav.addObject("relatedidx",relatedidx);
	      if(relatedlist.size()!=0) {
	         String relatedIdx="";
	         for(int i=0; i<relatedlist.size(); i++) {
	            relatedIdx+=relatedlist.get(i).getHairshop_bbs_idx()+",";
	         }
	         mav.addObject("relatedIdx",relatedIdx.substring(0, relatedIdx.length()-1));
	      }
	      mav.setViewName("hairshop/bbs/hairshop_bbs_update");
	      return mav;   
	   }
	
	
	/**
	 * 헤어샵 업데이트 완료를 눌렀을 때 처리하는 컨틀롤러
	 * @param dto 글의 정보를 담고있는 dto
	 * @param relatedBbs 관련 글의 idx를 갖고있는 idx
	 */		
	@RequestMapping("/hairshop_bbs_update_ok.do")
	public ModelAndView hairshop_bbs_update_ok(HairShop_BbsDTO dto,
			@RequestParam(value="relatedBbs",required=false)String relatedBbs) {
		
		int result=Hairshop_BbsDao.hairshop_bbs_update(dto);
		
		if(relatedBbs!=null&&!relatedBbs.equals("")) {
		    String[] relatedBbsArray;
		    relatedBbsArray = relatedBbs.split(",");
		    for(int i=0; i<relatedBbsArray.length; i++) {
		    	HairShop_Related_BbsDao.hairshopRelatedBbsWrite(dto.getHairshop_bbs_idx(),Integer.parseInt(relatedBbsArray[i]));
		    }			
		}
	    
		String msg=result>0?"성공":"실패";
		ModelAndView mav = new ModelAndView();
		mav.addObject("msg",msg);
		mav.addObject("goPage","/hair");
		mav.setViewName("hairshop/bbs/msg");
		return mav;
	}
	
	
	/**
	 * 헤어스타일 검색을 위한 컨트롤러
	 * @param cp 사용자의 현 위치
	 * @param hair_style 헤어스타일 선택 옵션
	 * @param search_option 어떤 검색을 했는지 알기위해
	 * @param search_value 어떤 키워드로 검색을 했는지
	 * @param hair_price 선택한 가격대
	 * @param order 어떤 정렬을 선택 했는지
	 * @param addinfo 추가정보 선택을 했는지
	 */		
	@RequestMapping("/hairshop_bbs_list.do")
	public ModelAndView hairshop_bbs_list(
			@RequestParam(value="cp",required=false,defaultValue="1")Integer cp,
			@RequestParam(value="hair_style",required=false,defaultValue="")String hair_style,
			@RequestParam(value="search_option",required=false,defaultValue="hairshop_bbs_subject")String search_option,
			@RequestParam(value="search_value",required=false,defaultValue="")String search_value,
			@RequestParam(value="hair_price",required=false,defaultValue="9999999")String hair_price,
			@RequestParam(value="order",required=false,defaultValue="writedate")String order,
			@RequestParam(value="addinfo",required=false)String[] addinfo) {
		
		
		String addinfoparam="";
		if(addinfo!=null) {
			for(int i=0; i<addinfo.length; i++) addinfoparam+="&addinfo="+addinfo[i];
		}

		ModelAndView mav = new ModelAndView();
		int totalCnt=Hairshop_BbsDao.hairshop_bbs_totalcnt(hair_style, search_option, search_value, hair_price, addinfo);
		int listSize=10;
		int pageSize=5;
		List<HairShop_BbsDTO> list=Hairshop_BbsDao.hairshop_bbs_list(cp, listSize, hair_style, search_option, search_value, hair_price, order, addinfo);
		mav.addObject("arr",list);
		String param="&hair_style="+hair_style+"&search_option="+search_option+"&search_value="+search_value+"&hair_price="+hair_price+addinfoparam+"&order="+order;
		String pageStr=hair.paging.PageModule.makePage("hairshop_bbs_list.do", totalCnt, listSize, pageSize, cp,param);
		mav.addObject("pageStr",pageStr);
		
		mav.setViewName("hairshop/bbs/hairshop_bbs_list");
		return mav;
	}
	
	
	
	/**
	 * 헤어샵 검색을 위한 컨트롤러
	 * @param cp 사용자의 현 위치
	 * @param search_option 어떤 검색을 했는지 알기위해
	 * @param search_value 어떤 키워드로 검색을 했는지
	 * @param order 어떤 정렬을 선택 했는지
	 */	
	@RequestMapping("/hairshop_search_list.do")
	public ModelAndView hairshop_search_list(
			@RequestParam(value="cp",required=false,defaultValue="1")Integer cp,
			@RequestParam(value="search_option",required=false,defaultValue="name")String search_option,
			@RequestParam(value="search_value",required=false,defaultValue="")String search_value,
			@RequestParam(value="order",required=false,defaultValue="")String order){
		ModelAndView mav = new ModelAndView();
		System.out.println("aaa");
		int totalCnt=Hairshop_Dao.hairshop_totalcnt(search_option, search_value);
		int listSize=20;
		int pageSize=5;
		List<HairShop_BbsDTO> list=Hairshop_Dao.hairshop_list(cp, listSize, search_option, search_value, order);
		mav.addObject("arr",list);
		String param="&search_option="+search_option+"&search_value="+search_value+"&order="+order;
		String pageStr=hair.paging.PageModule.makePage("hairshop_search_list.do", totalCnt, listSize, pageSize, cp,param);
		mav.addObject("pageStr",pageStr);
		mav.setViewName("hairshop/info/hairshop_list");
		return mav;
	}
	
	/**
	 * 헤어샵 지도 검색을 위한 컨트롤러
	 */	
	@RequestMapping("/hairshop_map_search_form.do")
	public String hairshop_map_search_form() {
		return "hairshop/info/hairshop_map_search";
	}
	
	/**
	 * 헤어샵 검색을 위한 컨트롤러
	 * @param cp 사용자의 현 위치
	 * @param hairshop_addr 검색하는 주소
	 */	
	@RequestMapping("/hairshop_map_search.do")
	public ModelAndView hairshop_map_search(String hairshop_addr) {
		ModelAndView mav = new ModelAndView();
		List<HairShopDTO> list=Hairshop_Dao.hairshop_map_saerch(hairshop_addr);
		mav.addObject("list",list);
		mav.setViewName("hairshop/info/hairshop_map_json");
		return mav;
	}
	
	/**
	 * 헤어샵 사진 등록 폼으로 이동하는 컨트롤러
	 */	
	@RequestMapping("/hairshop_photo_form.do")
	public String hairshop_photo_form() {
		return "hairshop/info/hairshop_photo_add";
	}
	
	/**
	 * 헤어샵 사진등록을 실행하는 컨트롤러
	 * @param hairshop_idx 헤어샵의 idx
	 * @param photo_names 저장될 사진의 이름
	 */	
	@RequestMapping("/hairshop_photo_add.do")
	public ModelAndView hairshop_photo_add(int hairshop_idx, String photo_names) {
		ModelAndView mav = new ModelAndView();
		Hairshop_PhotoDao.hairshop_photo_del(hairshop_idx);
		String photo_name[];
		photo_name = photo_names.split(",");

		int[] results = new int[photo_name.length]; 
		int result=1;
	    for(int i=0; i<photo_name.length; i++) {
	    	results[i]=Hairshop_PhotoDao.hairshop_photo_add(hairshop_idx, photo_name[i]);
	    }	
	    for(int i=0; i<results.length; i++) {
	    	if(results[i]!=1) {
	    		result=-1;
	    	}
	    }
		String msg=result==1?"성공":"실패";
		mav.addObject("msg", msg);
		mav.setViewName("hairshop/designer/designer_msg");
		
		return mav;
	}
	
	/**
	 * 헤어샵 사진 슬라이드 test
	 * @param hairshop_idx 헤어샵의 idx
	 */	
	@RequestMapping("/hairshop_photo_slide.do")
	public ModelAndView hairshop_photo_slide(int hairshop_idx) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("hairshop/info/hairshop_photo_slide");
		List<HairShop_PhotoDTO> list = Hairshop_PhotoDao.hairshop_photo(hairshop_idx);
		mav.addObject("list", list);
		return mav;
	}
	
	/**
	 * 헤어샵 좋아요 test
	 */	
	@RequestMapping("/hairshop.do")
	public String hairshop() {
		return "hairshop/info/hairshop";
	}
	
	
	
	
//	용석이형 로그인/////////////////////////////////////////////////////////////////////////
	


	/*기업 회원가입*/
	
	@RequestMapping(value="/hairshop_join_submit.do", method= {RequestMethod.POST})
	public ModelAndView hairshop_join_submit(HairShopDTO hsdto) {
		
		int result = Hairshop_Dao.hairshop_join_submit(hsdto);
		
		System.out.println(result > 0 ? "등록" : "실패");
		String msg = result>0?"모두의 헤어에 오신걸 환영합니다.":"";
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("msg", msg);
		mav.addObject("goPage", "index.do");
		mav.setViewName("hairshop/info/hairshop_join_Msg");
		return mav;
	}
	
	/*기업 로그인*/
	
	/*기업 아이디찾기*/
	@RequestMapping("/hairshop_search_id.do")
	public String hairshop_search_id() {
		return "login/hairshop_search_id";
	}
	@RequestMapping(value="/hairshop_search_id_submit.do", method=RequestMethod.POST)
	public ModelAndView hairshop_search_id_submit(
			@RequestParam(value="hairshop_ceo",required=false)String hairshop_ceo,
			@RequestParam(value="hairshop_email", required=false)String hairshop_email,
			@RequestParam(value="hairshop_name", required=false)String hairshop_name) {
		
		List<HairShopDTO> search_id_list = Hairshop_Dao.hairshop_search_id_submit(hairshop_ceo, hairshop_email, hairshop_name);
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("search_id_list", search_id_list);
		mav.setViewName("login/hairshop_search_id_submit");
		
		return mav;
	}
	/*기업 비밀번호 찾으면서 바로 update까지 수행*/
	@RequestMapping("/hairshop_search_pwd.do")
	public String hairshop_search_pwd() {
		return "login/hairshop_search_pwd";
	} 
	@RequestMapping(value="/hairshop_search_pwd_submit.do", method=RequestMethod.POST)
	public ModelAndView hairshop_search_pwd_submit(
			@RequestParam(value="hairshop_id", required=false)String hairshop_id,
			@RequestParam(value="hairshop_ceo", required=false)String hairshop_ceo,
			@RequestParam(value="hairshop_email", required=false)String hairshop_email) {
		
		List<HairShopDTO> search_pwd_list = Hairshop_Dao.hairshop_search_pwd_submit(hairshop_id, hairshop_ceo, hairshop_email);
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("search_pwd_list", search_pwd_list);
		mav.setViewName("login/hairshop_search_pwd_submit");
		
		return mav;
	}
	/*기업 비밀번호 update*/
	@RequestMapping(value="/hairshop_pwd_update.do", method=RequestMethod.POST)
	public ModelAndView hairshop_pwd_update(
			@RequestParam(value="hairshop_pwd", required=false)String hairshop_pwd,
			@RequestParam(value="hairshop_idx", required=false)String hairshop_idx) {
		
		int result = Hairshop_Dao.hairshop_pwd_update(hairshop_idx, hairshop_pwd);
		String msg = result>0?"비밀번호가 변경되었습니다":"";
		System.out.println(hairshop_idx);
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("msg", msg);
		mav.addObject("goPage", "index.do");
		mav.setViewName("hairshop/info/hairshop_pwd_update_Msg");
		
		return mav;
	}
	/*헤어샵 리스트 단순이동 */
	@RequestMapping("/hairshop_list.do")
	public String hairshop_list() {
		return "hairshop/info/hairshop_list";
	}
	
	
	
	////////////////////////////////////////////////////////////////////////////////////////////예지누나꺼////////////////////
	
	
	
	
	
	
	public void copyInto(int designerIdx, MultipartFile designer_photo,HttpServletRequest request) {

		 try {
			 byte bytes[]=designer_photo.getBytes();
			 File newFile= new File(request.getSession().getServletContext().getRealPath("/")+File.separator+"resources/upload/"+designer_photo.getOriginalFilename());
			 
			 FileOutputStream fos= new FileOutputStream(newFile);
			 fos.write(bytes);
			 fos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
			
	 
	    /**헤어샵메인페이지이동*/
	    @RequestMapping("/hairshop_main.do")
	    public ModelAndView hairshop_main(HttpSession session) {
	    	
	    	ModelAndView mav = new ModelAndView();
	        List<HairShop_PhotoDTO> list = Hairshop_PhotoDao.hairshop_photo((Integer)session.getAttribute("hairshop_idx"));
	        mav.setViewName("hairshop/hairshop_main");
	        mav.addObject("list", list);
	    	return mav;
	    }
	    
	    /**정보클릭시 비밀번호 확인페이지 이동*/
	    @RequestMapping("/hairshop_pwdCheck.do")
		public ModelAndView hairshop_pwdCheckForm(HttpSession session) {
			ModelAndView mav = new ModelAndView();
			mav.setViewName("hairshop/hairshop_pwd_check");
			return mav;
		}
	    
    
	    /**비밀번호 확인 */
	    @RequestMapping("/pwdCheck.do")
	    public ModelAndView pwdCheck(HttpSession session,
	                          @RequestParam(value="pwd",required=false)String pwd) {
	    	ModelAndView mav=new ModelAndView();
	    	
	       String hairshop_id=(String)session.getAttribute("hairshop_id");
	       String dbpwd=Hairshop_Dao.pwdCheck(hairshop_id);
	    
	       if(dbpwd.equals(pwd)) {
	          mav.addObject("msg", 1); //비밀번호 맞음
	          mav.setViewName("hairshop/msg/hairshop_hairshopMsg");
	       }else {
	          mav.addObject("msg", 2); //비밀번호 틀림
	          mav.setViewName("hairshop/msg/hairshop_hairshopMsg");
	       }
	       return mav;
	    }
	    	
	  	
	    /**헤어샵 정보불러오기*/
	    @RequestMapping(value="/hairshop_infoForm.do", method=RequestMethod.POST)
	    public ModelAndView hairshop_updateInfo(HttpSession session) {
	    	ModelAndView mav = new ModelAndView();
	    	String hairshop_id = (String)session.getAttribute("hairshop_id");
	    	System.out.println(hairshop_id);
	    	List<HairShopDTO> hairshopInfo = Hairshop_Dao.hairshop_info(hairshop_id);	
	    	mav.addObject("hairshop_id", hairshop_id);
	    	mav.addObject("hairshop_info", hairshopInfo);
	    	mav.setViewName("hairshop/info/hairshop_info");
	    	return mav;
	    }
	    
	    /**헤어샵 정보 업데이트*/
	    @RequestMapping(value="/hairshop_updateInfo.do", method=RequestMethod.POST)
	    public ModelAndView hairshop_updateInform(HttpSession session,@RequestParam("hairshop_pwd")String hairshop_pwd,
	    		@RequestParam("hairshop_info")String hairshop_info,@RequestParam("hairshop_addinfo")String hairshop_addinfo,
	    		@RequestParam("hairshop_open")String hairshop_open,@RequestParam("hairshop_off")String hairshop_off) {
	    	ModelAndView mav = new ModelAndView();
	    	String hairshop_id = (String)session.getAttribute("hairshop_id");
	    	int result = Hairshop_Dao.hairshop_updateInfo(hairshop_pwd, hairshop_info, hairshop_addinfo, hairshop_open, hairshop_off, hairshop_id);
	    	if(result>0) {
	    		mav.addObject("msg", "성공적으로 변경되었습니다.");
	    		mav.addObject("page", "hairshop_main.do");
	    	}else {
	    		mav.addObject("msg", "오류가 발생하였습니다. 관리자에게 문의하세요.");
	    		mav.addObject("page", "hairshop_infoForm.do");
	    	}
	    	mav.setViewName("hairshop/info/hairshop_info_msg");
	    	return mav;
	    }
	    
	    /**스타일 등록  관련 */
  		@RequestMapping("/updateStyle.do")
  		public String hairshop_stylePopup() {
  			return "hairshop/hair/hairshop_updateStyle";
  		}
	    

		/**
		 *  shop_hair_list 페이지 이동과 디자이너에  리스트 출력
		 * @param hairshop_idx (해어샵 idx)
		 * @return List<HairDTO> 헤어 리스트 출력
		 */
		@RequestMapping("/hairshop_style.do")
		public ModelAndView hair_style_list(HttpSession session) {
			ModelAndView mav = new ModelAndView();
			int hairshop_idx = (Integer)session.getAttribute("hairshop_idx");
			List<HairDTO> list = HairDao.shop_hair_list(hairshop_idx);
			mav.addObject("list", list);
			mav.setViewName("hairshop/hair/hairshop_style");
			return mav;
		}

	
		
		
		//디자이너 리스트 출력
		@RequestMapping("/hairshop_designerList.do")
		public ModelAndView hairshop_insert_designer_hairstyle(HttpSession session) {
			
			ModelAndView mav = new ModelAndView();
			int hairshop_idx = (Integer)session.getAttribute("hairshop_idx");
			List<DesignerDTO> designerlist = DesignerDao.desig_list(hairshop_idx);
			
			mav.addObject("designerList", designerlist);
			mav.setViewName("hairshop/designer/hairshop_designer");
			return mav;
		}
		
		
		/**디자이너 수정하기 정보 불러오기*/
		@RequestMapping(value="/updateDesigner.do",method=RequestMethod.GET)
		public ModelAndView designer_update(HttpSession session,@RequestParam("designerIdx")int designer_idx) {
			ModelAndView mav = new ModelAndView();
			

			
			int hairshop_idx = (Integer)session.getAttribute("hairshop_idx");	
			DesignerDTO designerInfo = DesignerDao.designerInfo(designer_idx);
			
			mav.addObject("designer_idx", designer_idx);
			mav.addObject("hairshop_idx", hairshop_idx);
			mav.addObject("designer_info", designerInfo);
			mav.setViewName("hairshop/designer/hairshop_update_designer");
			return mav;
		}
		
		
		/**디자이너 정보 수정하기
		 * @param dep :designer_photo
		 * hairshop_update_designer.jsp*/
		@RequestMapping(value="/upateDesigner.do", method=RequestMethod.POST)
		public ModelAndView updateDesigner_info(DesignerDTO designerDto,
				@RequestParam(value = "dep", required=false )MultipartFile designer_photo,HttpServletRequest request) {
			ModelAndView mav = new ModelAndView();
			int designer_idx = designerDto.getDesigner_idx();
			DesignerDTO designerInfo = DesignerDao.designerInfo(designer_idx);
				String designerPhoto=DesignerDao.designerInfo(designer_idx).getDesigner_photo();
			
				if(designer_photo.isEmpty()==true) {
					designerDto.setDesigner_photo(designerPhoto);
				}else {
					String fileName = designer_photo.getOriginalFilename();
					String realpath=request.getContextPath()+"/resources/upload/"+fileName;
					
					designerDto.setDesigner_photo(realpath);
					int result = DesignerDao.addDesigner(designerDto);
					copyInto(designer_idx, designer_photo,request);
				}
			int result = DesignerDao.updateDesignerInfo(designerDto);
			System.out.println(result);
			String msg = result > 0? "디자이너 정보를 수정하였습니다":"오류가 발생하였습니다. 관리자에게 문의하세요.";
			mav.addObject("msg", msg);
			mav.setViewName("hairshop/designer/designer_msg");
			return mav;
		}
		
		
		 /** 디자이너 등록 팝업창 이동 */
			@RequestMapping(value="/addDesigner.do", method=RequestMethod.GET)
			public ModelAndView hairshop_designerPopup(HttpSession session) {
				ModelAndView mav = new ModelAndView();
				
				int hairshop_idx = (Integer)session.getAttribute("hairshop_idx");			
				mav.addObject("hairshop_idx", hairshop_idx);
				mav.setViewName("hairshop/designer/hairshop_add_designer");
				return mav;
			}
		

			 /** 디자이너 등록 관련 */
			@RequestMapping(value="/addDesigner.do", method=RequestMethod.POST)
			public ModelAndView hairshop_addDesigner
			(DesignerDTO designerDto, @RequestParam("photo")MultipartFile designer_photo,HttpSession session,HttpServletRequest request) {
				
				int designerIdx = designerDto.getDesigner_idx();
				copyInto(designerIdx, designer_photo,request);		
				int hairshop_idx =(Integer)session.getAttribute("hairshop_idx");
				ModelAndView mav = new ModelAndView();
				String fileName = designer_photo.getOriginalFilename();
				String realpath=request.getContextPath()+"/resources/upload/"+fileName;
				
				designerDto.setDesigner_photo(realpath);
				int result = DesignerDao.addDesigner(designerDto);
				String msg = result>0? "등록하였습니다.":"오류가 발생하였습니다. 관리자에게 문의하세요.";			
				mav.addObject("hairshop_idx", hairshop_idx);
				mav.addObject("msg", msg);
				mav.setViewName("hairshop/designer/designer_msg");
				return mav;
			}
			
		
			/** 디자이너 삭제  폼이동*/
			@RequestMapping(value="/deleteDesigner.do", method=RequestMethod.GET)
			public ModelAndView hairshop_delDesignerForm(
				@RequestParam("designerIdx")int designer_idx,
				@RequestParam("designerName")String designer_name) {
				ModelAndView mav = new ModelAndView();
				mav.addObject("designer_idx", designer_idx);
				mav.addObject("designer_name", designer_name);
				mav.setViewName("hairshop/designer/hairshop_del_designer");
				return mav;
			}
			
			/**디자이너  삭제 관련*/
			@RequestMapping(value="/deleteDesigner.do",method=RequestMethod.POST)
			public ModelAndView hairshop_delDesigner(@RequestParam("designer_idx")int designer_idx) {
				ModelAndView mav =new ModelAndView();
				int result = DesignerDao.deleteDesigner(designer_idx);
				if(result>0) {
					mav.addObject("msg", "삭제되었습니다.");
				}else {
					mav.addObject("msg", "오류가 발생되었습니다. 관리자에게 문의하세요");
				}
				mav.setViewName("hairshop/designer/designer_msg");
				return mav;
			}		
			

			/**헤어샵 > 디자이너 관련 form 출력(디자이너 리스트  & 헤어스타일리스트 불러오기)*/
			@RequestMapping("/hairshop_designer_style.do")
			public ModelAndView hairshop_designerList(HttpSession session) {
				
				ModelAndView mav = new ModelAndView();	
				int hairshop_idx = (Integer)session.getAttribute("hairshop_idx");
				
				List<DesignerDTO> designerlist = DesignerDao.designerList(hairshop_idx);
				List<HairDTO> hairlist = Hairshop_Dao.hairshopStyleList(hairshop_idx);			
				mav.addObject("designerList", designerlist);
				mav.addObject("hairList", hairlist);
				mav.setViewName("hairshop/designer/hairshop_insert_designer_hairstyle");
				return mav;
			}
			
			
			/**받은 메세지함 관련 form 출력*/
			@RequestMapping("/hairshop_receivemessage.do")
			public ModelAndView hairshop_receivemessage(HttpSession session) {
				ModelAndView mav = new ModelAndView();
				/*String hairshop_id=(String)session.getAttribute("hairshop_id");
				int hairshop_idx = hairshopDao.hairshop_idx(hairshop_id);
				
				List<MessageDTO> receiveMessageList = hairshopDao.receiveMessage(hairshop_idx);
				
				mav.addObject("receiveMessageList", receiveMessageList);
				mav.addObject("hairshop_idx", hairshop_idx);*/
				mav.setViewName("hairshop/msg/hairshop_receive_message");
				return mav;
			}
			
	
		
			/**보낸 메세지함  관련 form 출력*/
			@RequestMapping("/hairshop_sendmessage.do")
			public ModelAndView hairshop_sendmessage(HttpSession session
					) {
				ModelAndView mav = new ModelAndView();
				/*int hairshop_idx=hairshopDao.hairshop_idx((String)session.getAttribute("hairshop_id"));
				List<MessageDTO> sendMessageList = hairshopDao.sendMessage(hairshop_idx);
				String member_id="";
				for(int i=0;i<sendMessageList.size();i++) {
				member_id = sendMessageList.get(i).getMemberDTO().getMember_id();
				}
				System.out.println(member_id);
				mav.addObject("hairshop_idx", hairshop_idx);
				mav.addObject("member_id", member_id);
				mav.addObject("sendMessageList", sendMessageList);*/
				mav.setViewName("hairshop/msg/hairshop_send_message");
				return mav;
			}
		
		
			@RequestMapping("/hairshop_hairoption.do")
			public ModelAndView hairshop_hairoption(HttpSession session)
			{
				ModelAndView mav= new ModelAndView();
				int hairshop_idx = (Integer)session.getAttribute("hairshop_idx");
				HairOptionDTO dto  = HairDao.hairoption_select(hairshop_idx);
				mav.setViewName("hairshop/hair/hairoption");
				mav.addObject("dto", dto);
				return mav;
			}
		@RequestMapping("/hairoption_reg.do")
		public ModelAndView hairshop_hairoption_reg(HttpSession session,HairOptionDTO dto)
		{
			int hairshop_idx = (Integer)session.getAttribute("hairshop_idx");
			dto.setHairshop_idx(hairshop_idx);
			int result = HairDao.hairoption_reg(dto);
			ModelAndView mav= new ModelAndView();
			
			String msg = result>0?"등록완료":"등록실패";
			mav.addObject("msg",msg);
			mav.addObject("page_state", 1);
			mav.setViewName("msg");
			return mav;
		}
		
		@RequestMapping("/hairoption_update.do")
		public ModelAndView hairshop_hairoption_update(HttpSession session,HairOptionDTO dto)
		{
			int hairshop_idx = (Integer)session.getAttribute("hairshop_idx");
			dto.setHairshop_idx(hairshop_idx);
			int result = HairDao.hairoption_update(dto);
			ModelAndView mav= new ModelAndView();
			String msg = result>0?"수정완료":"수정실패";
			mav.addObject("msg",msg);
			mav.addObject("page_state",1);
			mav.setViewName("msg");
			return mav;
		}
			
					
			
			
		/**헤어샵 > 포트폴리오  관련 form 출력*/
		@RequestMapping("/hairshop_portfolio.do")
		public ModelAndView hairshop_portfolio(@RequestParam(value="cp",required=false,defaultValue="1")Integer cp,HttpSession session) {
			ModelAndView mav = new ModelAndView();
			int hairshop_idx = (Integer)session.getAttribute("hairshop_idx");
		    int listSize=15;
		    int pageSize=5;
		    int totalCnt=Hairshop_BbsDao.member_hairshop_bbs_totalcnt(hairshop_idx);
		    String param="&hairshop_idx="+hairshop_idx;
		    String pageStr=hair.paging.PageModule.makePage("hairshop_portfolio.do", totalCnt, listSize, pageSize, cp,param);
		    mav.addObject("pageStr",pageStr);
		    List<HairShop_BbsDTO> blist = Hairshop_BbsDao.member_hairshop_bbs_list(hairshop_idx,cp,listSize);
		    mav.addObject("blist",blist);
			mav.setViewName("hairshop/hairshop_portfolio");
			return mav;
		}
		
		
		
		
		/**관리자에게 메세지 창 띄우기*/
		@RequestMapping(value="/msg_toAdmin.do", method=RequestMethod.GET)
		public ModelAndView msg_toAdminForm(HttpSession session) {
			ModelAndView mav = new ModelAndView();
			int hairshop_idx = (Integer)session.getAttribute("hairshop_idx");
			List<MemberDTO> adminIdxs = Hairshop_Dao.admin_idx();
			int admin_idx = 0;
			for(int i=0;i<adminIdxs.size();i++) {
				admin_idx = adminIdxs.get(i).getMember_idx();
			}
			mav.addObject("admin_idx", admin_idx);
			mav.addObject("hairshop_idx", hairshop_idx);
			mav.setViewName("hairshop/msg/hairshop_msg_toAdmin");
			return mav;
		}
		

		/**관리자에게 메세지 보내기*/
		@RequestMapping(value="/msg_toAdmin.do", method=RequestMethod.POST)
		public ModelAndView msg_toAdmin(@RequestParam ("sender_idx")int sender_idx, 
				@RequestParam ("receiver_idx")int receiver_idx,@RequestParam("message_content")String message_content) {
			ModelAndView mav = new ModelAndView();
			List<MemberDTO> adminIdxs = Hairshop_Dao.admin_idx();
			int result = 0;
			for(int i=0;i<adminIdxs.size();i++) {
				result = Hairshop_Dao.msgToMember(sender_idx, receiver_idx, message_content);
			}
			mav.addObject("result", result);
			mav.setViewName("hairshop/msg/hairshop_message_ok");
			return mav;
		}
		
		

		/**메세지 본문보기(보낸메세지함에서 본문보기)*/
		@RequestMapping("/openmsg_content.do")
		public ModelAndView openmsg_content(@RequestParam("messageIdx")int message_idx) {
			ModelAndView mav = new ModelAndView();
			List<MessageDTO> sendMessage_content=Hairshop_Dao.message_content(message_idx);
			String member_id="";
			for(int i=0;i<sendMessage_content.size();i++) {
				member_id = sendMessage_content.get(i).getMemberDto().getMember_id();
			}
			System.out.println(sendMessage_content.size());
			mav.addObject("member_id", member_id);
			mav.addObject("open_content", sendMessage_content);
			mav.setViewName("hairshop/msg/hairshop_message_content");
			return mav;
		}
		
		/**답장할 수 있는 메세지 본문보기(받은메세지함에서 본문보기)*/
		@RequestMapping("/openmsg_content_re.do")
		public ModelAndView openmsg_content_re(HttpSession session,@RequestParam("messageIdx")int message_idx,
				@RequestParam("senderId")String sender_id) {
			ModelAndView mav = new ModelAndView();
			int hairshop_idx = (Integer)session.getAttribute("hairshop_idx");
			
			List<MessageDTO> receiveMessage_content = Hairshop_Dao.message_allContent(message_idx);
			//List<MessageDTO> receiveMessageList = Hairshop_Dao.receiveMessage(hairshop_idx);
			
			int result = Hairshop_Dao.msgchangeState(message_idx);
			if(result>0) {
				System.out.println("읽기성공");
			}else {
				System.out.println("읽기실패");
			}		
			mav.addObject("sender_id", sender_id);
		//mav.addObject("receiveMessageList", receiveMessageList);
			mav.addObject("open_content_re", receiveMessage_content);
			mav.setViewName("hairshop/msg/hairshop_message_content_re");
			return mav;
		}
		
		
		/**답장하기 폼 열기*/
		@RequestMapping(value="/reMessage.do", method=RequestMethod.GET)
		public ModelAndView remsgForm(@RequestParam("receiver_idx")int receiver_idx,
				@RequestParam("senderId")String sender_id) {
			ModelAndView mav = new ModelAndView();
			
			mav.addObject("sender_id", sender_id);
			mav.addObject("receiver_idx", receiver_idx);
			mav.setViewName("hairshop/msg/hairshop_remessage");
			return mav;
		}
		
		
		/**답장보내기!*/
		@RequestMapping(value="/reMessage.do", method=RequestMethod.POST)
		public ModelAndView reMessage(HttpSession session,@RequestParam("receiver_idx")int receiver_idx,
				@RequestParam("message_content")String message_content) {
			ModelAndView mav = new ModelAndView();
			
			int hairshop_idx = (Integer)session.getAttribute("hairshop_idx");
			int result = Hairshop_Dao.msgToMember(hairshop_idx, receiver_idx, message_content);

			mav.addObject("result", result);
			mav.setViewName("hairshop/msg/hairshop_message_ok");
			return mav;
		}
		
		
		/**보낸메세지 삭제처리상태로 바꾸기*/
		@RequestMapping("/sendmsgTrash.do")
		public ModelAndView trash_semsg(@RequestParam("msgChecked")int[] message_idx) {
			ModelAndView mav = new ModelAndView();
			int result= 0;
			for(int i = 0;i<message_idx.length;i++)
			{
			result+= Hairshop_Dao.deleterMessage(message_idx[i]);
			} 
			if(result > 0) {
				mav.addObject("msg", "메세지를 삭제하였습니다.");
				mav.addObject("page", "hairshop_sendmessage.do");
			}else {
				mav.addObject("msg", "오류가 발생하였습니다. 관리자에게 문의하세요.");
				mav.addObject("page", "hairshop_sendmessage.do");
			}
		
			mav.setViewName("hairshop/msg/hairshop_msg_trash_ok");
			return mav;
		}
		
		
		/**받은메세지 삭제처리상태로 바꾸기*/
		@RequestMapping("/receivemsgTrash.do")
		public ModelAndView trash_remsg(@RequestParam("msgChecked")int[] message_idx) {
			ModelAndView mav = new ModelAndView();
			int result  = 0;
			for(int i = 0;i<message_idx.length;i++)
			{
			result+= Hairshop_Dao.deleterMessage(message_idx[i]);
			}		
			if(result > 0) {
				mav.addObject("msg", "메세지를 삭제하였습니다.");
				mav.addObject("page", "hairshop_receivemessage.do");
			}else {
				mav.addObject("msg", "오류가 발생하였습니다. 관리자에게 문의하세요.");
				mav.addObject("page", "hairshop_receivemessage.do");
			}
		
			mav.setViewName("hairshop/msg/hairshop_msg_trash_ok");
			return mav;
		}
	

		/**헤어샵 > 회원관리 관련 form 출력*/
		@RequestMapping("/hairshop_member.do")
		public ModelAndView hairshop_member
		(HttpSession session) {
			ModelAndView mav = new ModelAndView();
		
			mav.setViewName("hairshop/member/hairshop_member");
			return mav;
		}
		
		/**회원 각 개인에게 메세지 보내기 */
		@RequestMapping("/sendMemberMsg.do")
		public ModelAndView sendMemberMsg(@RequestParam ("sender_idx")int sender_idx, 
				@RequestParam ("receiver_idx")int receiver_idx,@RequestParam("message_content")String message_content) {
			ModelAndView mav = new ModelAndView();
		
			int result = Hairshop_Dao.msgToMember(sender_idx, receiver_idx, message_content);
			
			mav.addObject("result", result);
			mav.setViewName("hairshop/msg/hairshop_message_ok");
			return mav;
		}
		

		/**개인 메세지 팝업창 띄우기*/
		@RequestMapping("/sendMsg.do")
		public ModelAndView sendMsg
			(@RequestParam ("memberIdx") int member_idx, @RequestParam ("hairshopIdx")int hairshop_idx,
			 @RequestParam ("memberName")String member_name) {
			ModelAndView mav = new ModelAndView();
			
			mav.addObject("member_name", member_name);
			mav.addObject("member_idx", member_idx);
			mav.addObject("hairshop_idx", hairshop_idx);
			mav.setViewName("hairshop/msg/hairshop_memberMsg");
			return mav;
		}
		

		/**전체회원에게 메세지보내기 창 띄우기(popup page이동)*/
		@RequestMapping("/sendAllMsgForm.do")
		public ModelAndView sendmessage(@RequestParam ("hairshopIdx")int hairshop_idx) {
			ModelAndView mav = new ModelAndView();
			List<ReservationDTO> memberList = Hairshop_Dao.reservationAllMember(hairshop_idx);
			int member_idx = 0;
			for(int i=0;i<memberList.size();i++) {
				member_idx = memberList.get(i).getMember_idx();
			}
			mav.addObject("member_idx", member_idx);
			mav.addObject("hairshop_idx", hairshop_idx);
			mav.setViewName("hairshop/msg/hairshop_sendAllMemberMsg");
			return mav;
		}
		
	
		/**회원 전체에게 메세지 보내기*/
		@RequestMapping("/sendAllMemberMsg.do")
		public ModelAndView sendAllMemberMsg
		(@RequestParam ("sender_idx")int hairshop_idx,
		@RequestParam("message_content")String message_content) {
			ModelAndView mav = new ModelAndView();
			List<ReservationDTO> memberList = Hairshop_Dao.reservationAllMember(hairshop_idx);
			int result = 0;
			for(int i=0;i<memberList.size();i++) {
				
				result = Hairshop_Dao.msgToMember(hairshop_idx,memberList.get(i).getMember_idx(), message_content);
			}
			mav.addObject("result", result);
			mav.setViewName("hairshop/msg/hairshop_message_ok");
			return mav;
		}
		
		
		/**회원에게 쿠폰 보내기*/
		@RequestMapping("/sendMemberCoupon.do")
		public ModelAndView sendMemberCoupon(@RequestParam("member_coupon_deadline")String member_coupon_deadline,
			@RequestParam("member_idx")int member_idx, @RequestParam("hairshop_coupon_idx")int hairshop_coupon_idx){
			ModelAndView mav = new ModelAndView();
			String YY=member_coupon_deadline.substring(2, 4);
			String MM=member_coupon_deadline.substring(5, 7);
			String DD=member_coupon_deadline.substring(8);	
			String YYMMDD = YY+"."+MM+"."+DD;
			System.out.println(YYMMDD);
			int result = Hairshop_Dao.sendCouponToMember(YYMMDD, member_idx, hairshop_coupon_idx);
			if(result>0) {
				mav.addObject("msg","쿠폰 보내기 완료");
			}
			else {
				mav.addObject("msg", "오류가 발생하였습니다. 관리자에게 문의하세요.");
			}
			mav.setViewName("hairshop/coupon/hairshop_coupon_ok");
			return mav;
		}
		
		/**모든회원에게 쿠폰보내기 창 띄우기*/
		@RequestMapping("/sendAllCouponForm.do")
		public ModelAndView sendAllCouponForm(@RequestParam("hairshopIdx")int hairshop_idx) {
			ModelAndView mav = new ModelAndView();
			List<HairShop_CouponDTO> hairshopCouponList = Hairshop_Dao.hairshop_couponList(hairshop_idx);
			mav.addObject("hairshop_coupon_list", hairshopCouponList);
			mav.addObject("hairshop_idx", hairshop_idx);
			mav.setViewName("hairshop/coupon/hairshop_Send_AllMember_Coupon");
			return mav;
		}
		/**쿠폰선택하기popup 열기*/
		@RequestMapping("/selectCoupon.do")
		public ModelAndView selectCoupon(HttpSession session,@RequestParam ("memberIdx")int hairhsop_member_idx,
			@RequestParam("memberName")String member_name) {
			ModelAndView mav = new ModelAndView();		
			int hairshop_idx = (Integer)session.getAttribute("hairshop_idx");
			List<HairShop_CouponDTO> hairshopCouponList = Hairshop_Dao.hairshop_couponList(hairshop_idx);
			
			mav.addObject("member_name", member_name);
			mav.addObject("hairshop_coupon_list", hairshopCouponList);
			mav.addObject("hairhsop_member_idx", hairhsop_member_idx);
			mav.setViewName("hairshop/coupon/hairshop_selectCoupon");
			return mav;
		}
		
		
		/**모든 회원에서 쿠폰 보내기*/
		@RequestMapping("/sendAllMemberCoupon.do")
		public ModelAndView sendAllMemberCoupon(HttpSession session,@RequestParam("member_coupon_deadline")String member_coupon_deadline,
			 @RequestParam("hairshop_coupon_idx")int hairshop_coupon_idx) {
			ModelAndView mav = new ModelAndView();
			
			int hairshop_idx =  (Integer)session.getAttribute("hairshop_idx");
			List<ReservationDTO> member_idxs = Hairshop_Dao.reservationAllMember(hairshop_idx);
			
			String YY=member_coupon_deadline.substring(2, 4);
			String MM=member_coupon_deadline.substring(5, 7);
			String DD=member_coupon_deadline.substring(8);	
			String YYMMDD = YY+"."+MM+"."+DD;
			int result = 0;
			for(int i=0;i<member_idxs.size();i++) {
				result = Hairshop_Dao.sendCouponToMember(YYMMDD, member_idxs.get(i).getMember_idx(), hairshop_coupon_idx);
			}
			
			if(result > 0) {
				mav.addObject("msg", "모든 회원에게 쿠폰을 보냈습니다.");
			}else {
				mav.addObject("msg", "오류가 발생하였습니다. 관리자에게 문의하세요.");
			}
			mav.setViewName("hairshop/coupon/hairshop_coupon_ok");
			return mav;
		}
		/**쿠폰관리 팝업창 띄우기*/
		@RequestMapping("/hairshop_coupon.do")
		public ModelAndView couponForm(@RequestParam("hairshopIdx")int hairshop_idx) {
			ModelAndView mav = new ModelAndView();
			
			List<HairShop_CouponDTO> hairshop_couponList = Hairshop_Dao.hairshop_couponList(hairshop_idx);
			mav.addObject("hairshop_couponList", hairshop_couponList);
			mav.addObject("hairshop_idx", hairshop_idx);
			mav.setViewName("hairshop/coupon/hairshop_coupon");
			return mav;
		}
		
		/**쿠폰 만들기 팝업창 띄우기*/
		@RequestMapping(value="/addcoupon.do", method=RequestMethod.GET)
		public ModelAndView addCouponForm(@RequestParam("hairshopIdx")int hairshop_idx) {
			ModelAndView mav = new ModelAndView();
			mav.addObject("hairshop_idx", hairshop_idx);
			mav.setViewName("hairshop/coupon/hairshop_addCoupon");
			
			return mav;
		}
		
		/**쿠폰만들기!!!*/
		@RequestMapping(value="/addcoupon.do", method=RequestMethod.POST)
		public ModelAndView addCouponSubmit(@RequestParam("hairshop_coupon_discount")int hairshop_coupon_discount,
			@RequestParam("hairshop_idx")int hairshop_idx) {
			ModelAndView mav = new ModelAndView();
			
			int result = Hairshop_Dao.addCoupon(hairshop_coupon_discount, hairshop_idx);
			if(result>0) {
				mav.addObject("msg", "쿠폰이 만들어졌습니다.");
			}else {
				mav.addObject("msg", "오류가 발생하였습니다. 관리자에게 문의하세요.");
			}
			mav.setViewName("hairshop/coupon/hairshop_coupon_ok");
			return mav;
		}
		
		/** 체크박스로 체크된 쿠폰 목록 쪼개기*/
		@RequestMapping("/hairshop_couponIdx.do")
		public ModelAndView hairshopCouponIdx(@RequestParam ("coupon_idx")String hairshopCoupon_idx) {
			ModelAndView mav = new ModelAndView();
			
			mav.addObject("hairshopCoupon_idx", hairshopCoupon_idx);
			mav.setViewName("hairshop/coupon/hairshop_coupon_delete");
			return mav;
		}
		
		/**쿠폰 삭제하기*/
		@RequestMapping("/delete_hairshop_coupon.do")
		public ModelAndView delete_hairshop_coupon(@RequestParam ("hairshopCouponIdx")String hairshop_coupon_idx) {
			ModelAndView mav = new ModelAndView();
			String idx[] = hairshop_coupon_idx.split(",");
			int hairshop_couponIdx[] = new int[idx.length];
			for(int i=0;i<idx.length;i++) {
				hairshop_couponIdx[i] = Integer.parseInt(idx[i]);
				System.out.println(hairshop_couponIdx[i]);
			}
			int result = 0;
			for(int i = 0;i<hairshop_couponIdx.length;i++)
			{
			  result = Hairshop_Dao.del_hairshop_coupon(hairshop_couponIdx[i]);
			}
			if(result>0) {
				mav.addObject("msg","삭제되었습니다.");
			}
			else {
				mav.addObject("msg", "오류가 발생하였습니다. 관리자에게 문의하세요.");
			}
			mav.setViewName("hairshop/coupon/hairshop_coupon_ok");
			return mav;
		}
		

		
		/**헤어샵 > 리뷰  관련 form 출력*/
		@RequestMapping("/hairshop_review.do")
		public ModelAndView hairshop_review(HttpSession session) {
			int hairshop_idx = (Integer)session.getAttribute("hairshop_idx");
			ModelAndView mav = new ModelAndView();
			List<Member_ReviewDTO> hairshop_reviewList = Hairshop_Dao.hairshop_reviewList(hairshop_idx); 
			for(int i=0;i<hairshop_reviewList.size();i++) {
				System.out.println(hairshop_reviewList.get(i).getMember_review_subject());
				System.out.println(hairshop_reviewList.get(i).getMember_review_thumb());
			}
			
			mav.addObject("hairshopReviewList", hairshop_reviewList);
			mav.setViewName("hairshop/hairshop_review");
			return mav;
		}
		
		
	
		
		
		/**헤어샵 > 통계  관련 form 출력*/
		@RequestMapping(value="/hairshop_stats.do", method=RequestMethod.GET)
		public ModelAndView hairshop_stats(HttpSession session) {
			ModelAndView mav = new ModelAndView();	 
			int hairshop_idx = (Integer)session.getAttribute("hairshop_idx");		
			String hairshop_id = (String)session.getAttribute("hairshop_id");
			List<ReservationDTO> daysales = Hairshop_Dao.dayTotalSales(hairshop_idx);
			
			String date="";
			String total="";
			for(int i=0;i<daysales.size();i++) {
				date += "\'"+daysales.get(i).getReservation_date().substring(0, 10)+"\'";
				total += "["+(daysales.get(i).getReservation_price()/1000)+"]";
				
				if(i!=daysales.size()-1)
				{
					date+=",";
					total+=",";
				}
			}
			System.out.println(date);
			System.out.println(total);
			mav.addObject("date",date);
			mav.addObject("total", total);
			mav.addObject("day_total", daysales);
			mav.addObject("hairshop_id",hairshop_id);
			mav.addObject("hairshop_idx", hairshop_idx);
			mav.setViewName("hairshop/stats/hairshop_stats");
			return mav;
		}
		
		
		
		
		
		//통계 - 날짜 검색 결과 보기 폼!
		@RequestMapping(value="hairshop_stats.do", method=RequestMethod.POST)
		public ModelAndView hairshop_staticsList(@RequestParam("startDate")String start,@RequestParam("finishDate")String finish,
				HttpSession session) {
			ModelAndView mav = new ModelAndView();
			int hairshop_idx = (Integer)session.getAttribute("hairshop_idx");
			List<ReservationDTO> daysales = Hairshop_Dao.dayTotalSales(hairshop_idx);
			
			String date="";
			String total="";
			for(int i=0;i<daysales.size();i++) {
				date += "\'"+daysales.get(i).getReservation_date().substring(0, 10)+"\'";
				total += "["+(daysales.get(i).getReservation_price()/1000)+"]";
				
				if(i!=daysales.size()-1){
					date+=",";
					total+=",";
				}
			}
			
			
			//매출통계
			String searchDate="";
			String searchTotal="";
			List<ReservationDTO> searchsales = Hairshop_Dao.searchsales(start, finish, hairshop_idx);
			for(int k=0;k<searchsales.size();k++) {
				searchDate += "\'"+searchsales.get(k).getReservation_date()+"\'";
				searchTotal += "["+(searchsales.get(k).getReservation_price()/1000)+"]";
				
				if(k!=searchsales.size()-1){
					searchDate+=",";
					searchTotal+=",";
				}
			}
			System.out.println("매출통계");
			System.out.println(searchDate);System.out.println(searchTotal);
			//성별통계
			List<HashMap> searchGender = Hairshop_Dao.searchsex(start, finish, hairshop_idx);
				int[] gendercount = new int[2];
			 
					for(int i=0;i<searchGender.size();i++) {
						if((Integer)searchGender.get(i).get("member_sex")==1) {
							gendercount[0] = (Integer)searchGender.get(i).get("count");
							System.out.println((Integer)searchGender.get(i).get("count"));
						}else if((Integer)searchGender.get(i).get("member_sex")==2) {
							gendercount[1] = (Integer)searchGender.get(i).get("count");
						}
					
				}
				String gendercount_s = gendercount[0]+","+gendercount[1];
				System.out.println("----------------");
				System.out.println("성별통계");
				System.out.println(gendercount_s);
				System.out.println("----------------");
			//나이별통계	
			List<HashMap> searchAge = Hairshop_Dao.searchage(start, finish, hairshop_idx);
			int[] agecount = new int[4]; 
		
				for(int a=0;a<searchAge.size();a++) {
					if((Integer)searchAge.get(a).get("age")==10){
						agecount[0] = (Integer)searchAge.get(a).get("count");
					}else if((Integer)searchAge.get(a).get("age")==20){
						agecount[1] = (Integer)searchAge.get(a).get("count");
					}else if((Integer)searchAge.get(a).get("age")==30){
						agecount[2] = (Integer)searchAge.get(a).get("count");
					}else if((Integer)searchAge.get(a).get("age")==40) {
						agecount[3] = (Integer)searchAge.get(a).get("count");
					}
				
			}
			String agecount_s = agecount[0]+","+agecount[1]+","+agecount[2]+","+agecount[3];
			
			System.out.println(agecount_s);
				
			//스타일통계	
			String styleType="";
			List<HashMap> searchStyle = Hairshop_Dao.searchstyle(start, finish, hairshop_idx);
			int[] stylecount = new int[4];
			if(searchStyle.size()<4) {
				for(int s=0;s<searchStyle.size();s++) {
					if(searchStyle.get(s).get("hair_style").equals("파마")){
						stylecount[0] = (Integer) searchStyle.get(s).get("count");
					}else if(searchStyle.get(s).get("hair_style").equals("염색")) {
						stylecount[1] = (Integer)searchStyle.get(s).get("count");
					}else if(searchStyle.get(s).get("hair_style").equals("커트")) {
						stylecount[2] = (Integer)searchStyle.get(s).get("count");
					}else if(searchStyle.get(s).get("hair_style").equals("매직")) {
						stylecount[3] = (Integer)searchStyle.get(s).get("count");
					}
				}
			}
				String stylecount_s = stylecount[0]+","+stylecount[1]+","+stylecount[2]+","+stylecount[3];
				System.out.println(stylecount_s);
			System.out.println(styleType);
			//스타일별통계
			mav.addObject("styleType", stylecount_s);
			//나이별 통계
			mav.addObject("searchList", agecount_s);
			//매출통계
			mav.addObject("searchDate", searchDate);
			mav.addObject("searchTotal", searchTotal);
			//성별통계
			mav.addObject("gendercount_s", gendercount_s);
			//7일통계
			mav.addObject("date",date);
			mav.addObject("total", total);
			mav.setViewName("hairshop/stats/hairshop_stats");
			mav.addObject("reservationList", searchsales);
			return mav;
		}
		

		
		
		/**스폰신청하기 폼띄우기*/
		@RequestMapping(value="/hairshop_sponApplication.do",method=RequestMethod.GET)
		public ModelAndView sponApplicationForm(HttpSession session) {
			ModelAndView mav = new ModelAndView();
			int hairshop_idx = (Integer)session.getAttribute("hairshop_idx");
			String hairshop_id = (String)session.getAttribute("hairshop_id");
			List<HairShopDTO> hairshopDto = Hairshop_Dao.hairshop_info(hairshop_id);
		
			mav.addObject("hairshopDto", hairshopDto);
			mav.addObject("hairshop_idx", hairshop_idx);
			mav.setViewName("hairshop/spon/hairshop_spon_application");
			return mav;
		}

		
		
		/**스폰 신청하기*/
		@RequestMapping(value="/hairshop_sponApplication.do", method=RequestMethod.POST)
		public ModelAndView sponApplication(SponDTO sponDto) {
			ModelAndView mav = new ModelAndView();
			String start_date = sponDto.getSpon_start();
			String finish_date = sponDto.getSpon_finish();
			
			String start = start_date.substring(2, 4)+"."+start_date.substring(5, 7)+"."+start_date.substring(8);
			String finish = finish_date.substring(2, 4)+"."+finish_date.substring(5, 7)+"."+finish_date.substring(8);
			sponDto.setSpon_start(start);
			sponDto.setSpon_finish(finish);
			int result = Hairshop_Dao.sponApplication(sponDto);
			if(result>0) {
				mav.addObject("msg", "신청서를 제출하였습니다.");
				
			}else {
				mav.addObject("msg", "오류가 발생하였습니다. 관리자에게 문의하세요.");
			}
			mav.addObject("page", "hairshop_main.do");
			mav.setViewName("hairshop/msg/hairshop_msg_trash_ok");
			return mav;
		}

		
		/**보낸메세지함 리스트 및 페이징*/
		@RequestMapping("/hairshop_sendMessage_State.do")
		public ModelAndView hairshop_sendMessage_State(HttpSession session,
													   @RequestParam(value="cp",defaultValue="1")int cp,
													   @RequestParam("message_state")int state) {
			
			ModelAndView mav=new ModelAndView();
			
			//페이징
			int totalCnt=0;
			int listSize=5;
			int pageSize=5;
					
			String pageStr=null;
				
			//목록
			int hairshop_idx=(Integer)session.getAttribute("hairshop_idx");
			List<MessageDTO> sendMessageList = null;
			
			if(state==1) {
				
				totalCnt= Hairshop_Dao.hairshop_sendMessageTotalCnt(hairshop_idx);
				if(totalCnt==0)
				{
					totalCnt = 1;
				}
				pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
				sendMessageList=Hairshop_Dao.sendMessage(hairshop_idx,cp,listSize);
				String member_id="";
				for(int i=0;i<sendMessageList.size();i++) {
				member_id = sendMessageList.get(i).getMemberDto().getMember_id();
				}
				mav.addObject("paging", pageStr);
				mav.addObject("member_id", member_id);
				mav.addObject("sendMessageList", sendMessageList);
				mav.setViewName("hairshop/msg/hairshop_sendMessage_State1");
			}
			return mav;
		}
		/**받은 메세지함 리스트 및 페이징*/
		@RequestMapping("/hairshop_receiveMessage_State.do")
		public ModelAndView hairshop_receiveMessage_State(HttpSession session,
														  @RequestParam(value="cp",defaultValue="1")int cp,
														  @RequestParam("message_state")int state) {
			
			ModelAndView mav=new ModelAndView();
			int hairshop_idx =(Integer)session.getAttribute("hairshop_idx");
			//페이징
			int totalCnt=0;
			int listSize=5;
			int pageSize=5;
			
			String pageStr=null;
			
			//목록
		
			
			List<MessageDTO> receiveMessageList = null;
			
			if(state==1) {
				
				totalCnt=Hairshop_Dao.hairshop_receiveMessageTotalCnt(hairshop_idx);
				if(totalCnt==0)
				{
					totalCnt = 1;
				}
				pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
				receiveMessageList=Hairshop_Dao.receiveMessage(hairshop_idx,cp,listSize);
				mav.addObject("paging", pageStr);
				mav.addObject("receiveMessageList", receiveMessageList);
				mav.setViewName("hairshop/msg/hairshop_receiveMessage_State1");
			}
			return mav;
			
		}
		
		@RequestMapping("/hairshop_member_State.do")
		public ModelAndView hairshop_member_State(HttpSession session,
											  	  @RequestParam(value="cp",defaultValue="1")int cp,
									              @RequestParam("member_state")int state) {
			
			ModelAndView mav=new ModelAndView();
			
			//페이징
	        int totalCnt=0;
	        int listSize=5;
	        int pageSize=5;
	              
	        String pageStr=null;
	              
	        //목록
	        
			int hairshop_idx = (Integer)session.getAttribute("hairshop_idx");
			
			List<MemberDTO> hairshop_member = null;
			
	        if(state==1) {
	            
	            totalCnt=Hairshop_Dao.hairshopMember_TotalCnt(hairshop_idx);
	            if(totalCnt==0)
				{
					totalCnt = 1;
				}
	            pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
	            hairshop_member=Hairshop_Dao.hairshop_Member(hairshop_idx,cp,listSize);
	            mav.addObject("paging", pageStr);
	            mav.addObject("hairshop_member", hairshop_member);
	            mav.setViewName("hairshop/member/hairshop_member_State1");
	        }
	        return mav;
		}
		
		
}

