package hair.controller;


import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import hair.hairshop.model.HairShopDAO;
import hair.hairshop.model.HairShopDTO;
import hair.hairshop.model.HairShop_BbsDAO;
import hair.hairshop.model.HairShop_BbsDTO;
import hair.member.model.MemberDAO;
import hair.member.model.MemberDTO;


@Controller
public class IndexController {

	@Autowired
	private HairShopDAO Hairshop_Dao;
	
	@Autowired
	private MemberDAO Member_dao;
	
	   @Autowired
	   private HairShop_BbsDAO Hairshop_BbsDao;
	   
	   //인덱스 이동
	   @RequestMapping("/index.do")
	   public ModelAndView index()
	   {
	      ModelAndView mav = new ModelAndView();
	      mav.setViewName("index");
	      List<HairShop_BbsDTO> list = Hairshop_BbsDao.indextop5();
	      mav.addObject("top5",list);
	      System.out.println(list.size());
	      return mav;
	   }
	/*기업 및 사용자 판단 페이지*/
	@RequestMapping("/allJoin.do")
	public String allJoin() {
		return "login/allJoin";
	}	
	/*회원가입 전 정보동의*/
	@RequestMapping("/join_info_agree.do")
	public String join_info_agree() {
		return "login/join_info_agree";
	}
	
	/*정보동의 자세히보기 창열기*/
	@RequestMapping("/join_info_look.do")
	public String join_info_look() {
		return "login/join_info_look";
	}
	
	// 로그인 실행
	@RequestMapping(value = "/login_submit.do", method = RequestMethod.POST)
	public ModelAndView login(HttpSession session, HttpServletResponse resp,
			@RequestParam(value = "id", required = false) String id,
			@RequestParam(value = "pwd", required = false) String pwd,
			@RequestParam(value = "save_id", required = false) String save_id) {

		ModelAndView mav = new ModelAndView();
		MemberDTO mdto = Member_dao.member_login(id, pwd); // meber_state를 가져와서
		HairShopDTO hdto = Hairshop_Dao.hairshop_login_submit(id, pwd);
		
		
		if (mdto == null && hdto == null)
		{
			mav.addObject("msg", "아이디 또는 비밀번호가 틀립니다.");
			mav.addObject("page_state", "loginForm.do");
			mav.setViewName("msg");
		} 
		else if (mdto != null)
		{
			if (mdto.getMember_state() == 3)
			{ // meber_state =3(탈퇴) ->탈퇴 된 회원 알림
				mav.addObject("msg", "탈퇴 된 정보입니다.");
				mav.addObject("page_state", "loginForm.do");
				mav.setViewName("msg");
			}
			else
			{
				System.out.println(mdto.getMember_idx());
				session.setAttribute("member_id", id);
				session.setAttribute("member_idx", mdto.getMember_idx());
				session.setAttribute("member_name", mdto.getMember_name());
				session.setAttribute("member_level", mdto.getMember_level());
				session.setAttribute("member_state", mdto.getMember_state());

				mav.addObject("msg", "로그인 성공");
				mav.addObject("page_state", "index.do");
				mav.setViewName("msg");

				// 아이디 기억하기 수행
				if (save_id == null || save_id.equals("")) {
					Cookie ck = new Cookie("save_id", id);
					ck.setMaxAge(0);
					resp.addCookie(ck);
				} 
				else
				{
					Cookie ck = new Cookie("save_id", id);
					ck.setMaxAge(60 * 60);
					resp.addCookie(ck);
				}
			}
		}
		else if(hdto != null)
		{
			
			if(hdto.getHairshop_state()==3)
			{
				mav.addObject("msg", "탈퇴 된 정보입니다.");
				mav.addObject("page_state", "loginForm.do");
				mav.setViewName("msg");
			}else if(hdto.getHairshop_state()==0) {
				mav.addObject("msg", "승인 전입니다.");
				mav.addObject("page_state", "loginForm.do");
				mav.setViewName("msg");		
			}
			else
			{
				mav.addObject("msg", "로그인 성공");
				mav.addObject("page_state", "index.do");
				mav.setViewName("msg");
				session.setAttribute("hairshop_idx", hdto.getHairshop_idx());
				session.setAttribute("hairshop_id", hdto.getHairshop_id());
				session.setAttribute("hairshop_name",  hdto.getHairshop_name());
				session.setAttribute("hairshop_level", hdto.getHairshop_level());
			}
			
		if (save_id == null || save_id.equals("")) {
			Cookie ck = new Cookie("save_id", id);
			ck.setMaxAge(0);
			resp.addCookie(ck);
		} 
		else
		{
			Cookie ck = new Cookie("save_id", id);
			ck.setMaxAge(60 * 60);
			resp.addCookie(ck);
		}
		}
		
			return mav;
		}

	// 전체 로그아웃 실행
	@RequestMapping("/logOut.do")
	public ModelAndView logout(HttpServletRequest req) {
			
			HttpSession session = req.getSession();
			session.invalidate(); //세션을 지움!!!!
			
			ModelAndView mav = new ModelAndView();
			mav.setViewName("redirect:/index.do"); 
			return mav;	
		}
	
	// 로그인 페이지 이동
		@RequestMapping("/loginForm.do")
		public String loginForm() {
			return "login/loginForm";
		}

		/* 회원가입 아이디 중복검사*/
		@RequestMapping(value="idCheck.do",method={RequestMethod.POST})
		public ModelAndView join_idCheck(@RequestParam(value="id", required=false)String id) {
			
			boolean h_result = Hairshop_Dao.hairshop_join_idCheck(id);
			boolean m_result = Member_dao.member_idcheck(id);
			
			int idck;
			if(m_result && h_result)
			{
				idck = 0;
			}
			else
			{
				idck = 1;
			}
				
			ModelAndView mav = new ModelAndView();
			mav.addObject("idck", idck);
			mav.setViewName("login/join_ajax");		
			
			return mav;
		}
		
		
		//기업 회원가입 페이지 이동
		@RequestMapping("/hairshop_join.do")
		 public String hairshop_join() {
			return "login/hairshop_join";
		}
		
		// 회원가입 페이지 이동
		@RequestMapping("/member_joinForm.do")
		public String joinForm() {
			return "login/member_joinForm";
		}

		//주소창 열기
		@RequestMapping("/goJusoApiPopup.do")
		public String goJusoApiPopup() {
			return "login/goJusoApiPopup";
		}
		
		/*기업 / 개인 아이디 찾기 체크 폼*/
		@RequestMapping("/all_search_id.do")
		public String all_search_id() {
			return "login/all_search_id";
		}
		/*기업 / 개인 비밀번호 찾기 체크 폼*/
		@RequestMapping("/all_search_pwd.do")
		public String all_search_pwd() {
			return "login/all_search_pwd";
		}
		
		@RequestMapping("/about.do")
		public String info() {
			return "hairshopinfo";
		}	
		
	
}
