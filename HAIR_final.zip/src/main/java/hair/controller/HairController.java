package hair.controller;


import java.util.List;

import javax.mail.Session;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


import hair.hair.model.HairDAO;
import hair.hair.model.HairDTO;
import hair.hair.model.HairListDTO;
import hair.hair.model.HairOptionDTO;

@Controller
public class HairController {

	@Autowired
	private HairDAO hairdao;
	
	

	/**
	 * shop_hair_reg에서 해어 등록
	 * @param dto (헤어 dto)
	 * @return 메세지 전달
	 */
	@RequestMapping("/shop_hair_reg_ok.do")
	public ModelAndView hair_reg_ok(HairDTO dto) {
		System.out.println(dto.getHair_idx());
		int result = hairdao.hair_reg(dto);
		String msg = result > 0 ? "성공" : "실패";
		ModelAndView mav = new ModelAndView();
		mav.addObject("msg", msg);
		mav.addObject("page_state",1);
		mav.setViewName("msg");
		return mav;
	}

	@RequestMapping("select_hair_reg_list_ajax.do")
	public ModelAndView select_hair_reg_list_ajax(int designer_idx)
	{
		
		ModelAndView mav = new ModelAndView();
		List<HairDTO> list = hairdao.hair_reg_list(designer_idx);
		mav.addObject("list",list);
		mav.setViewName("hairshop/hair/select_hair_reg_list_ajax");
		
		return mav;
		
	}
	
	
	
	/**
	 *  select태그의 디자이너가 등록하지 않은 헤어 리스트 ajax 
	 * @param hairshop_idx  헤어샵 idx
	 * @param designer_idx  디자이너 idx
	 * @return
	 */
	@RequestMapping("/select_hair_list_ajax.do")
	public ModelAndView hairlist_ajax(int hairshop_idx, int designer_idx) {
		ModelAndView mav = new ModelAndView();
		List<HairDTO> list = hairdao.hair_list(hairshop_idx, designer_idx);
		mav.addObject("list", list);
		mav.setViewName("hairshop/hair/select_hair_list_ajax");
		return mav;
	}

	/**
	 * desig_hair_reg 에서 등록
	 * @param dto
	 * @return
	 */	
	@RequestMapping("/desig_hair_reg_ok.do")
	public ModelAndView desig_hair_list_reg_ok(HairListDTO dto) {
		int result = hairdao.desig_hair_reg(dto);
		String msg = result>0?"등록성공":"등록실패";
		ModelAndView mav  = new ModelAndView();
		mav.setViewName("msg");
		mav.addObject("page_state","hairshop_designer_style.do");
		mav.addObject("msg", msg);
		return mav;
	}

	
}
