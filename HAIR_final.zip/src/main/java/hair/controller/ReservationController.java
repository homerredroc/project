package hair.controller;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import hair.hair.model.HairDAO;
import hair.hair.model.HairOptionDTO;
import hair.hairshop.designer.model.DesignerDTO;
import hair.hairshop.model.HairShopDAO;
import hair.hairshop.model.HairShopDTO;
import hair.hairshop.model.HairShop_CouponDTO;
import hair.member.model.MemberDAO;
import hair.member.model.MemberDTO;
import hair.module.Timelist;
import hair.reservation.model.ReservationDAO;
import hair.reservation.model.ReservationDTO;
import payment_module.IamportClient;
import payment_module.request.CancelData;
import payment_module.response.IamportResponse;
import payment_module.response.Payment;
@Controller

public class ReservationController {
	@Autowired
	private ReservationDAO reservationdao;
	
	@Autowired
	private HairShopDAO Hairshop_Dao;
	
	@Autowired
	private HairDAO hair_dao;
	
	@Autowired
	private MemberDAO memberDao;
	
	   @RequestMapping("/styling_ok.do")
	   public ModelAndView styling_ok(@RequestParam("reservation_idx")int reservation_idx)
	   {
	      ModelAndView mav = new ModelAndView();
	      int result = reservationdao.reser_state_update(reservation_idx,3);
	      String msg = result>0?"성공":"실패";
	      mav.addObject("msg", msg);
	      mav.addObject("page_state", 1);
	      mav.setViewName("msg");
	      return mav;
	   }
	   
	/**
	 * reservation 페이지 이동과 보여줄 리스트
	 * @return
	 */
	@RequestMapping("/reservation.do")
	public ModelAndView reservation(ReservationDTO dto) {
		ModelAndView mav = new ModelAndView();
		Calendar cal = Calendar.getInstance();
		ArrayList<Object> list = new ArrayList<Object>();
		String days[] = { "일", "월", "화", "수", "목", "금", "토", };

		for (int i = 0; i < 14; i++) {
			String[] datas = new String[3];
			String day = days[cal.get(Calendar.DAY_OF_WEEK) - 1];
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH) + 1;
			int date = cal.get(Calendar.DATE);
			String date_s;
			String month_s;
			if (month / 10 == 0) 
			{
				month_s = "0" +month;
			} else
			{
				month_s = ""+ month;
			}
			
			
			if (date / 10 == 0) 
			{
				date_s = "0" + date;
			} else
			{
				date_s = ""+ date;
			}
			String Fulldate = year+"-"+month_s+"-"+date_s;
			cal.set(Calendar.DATE, date + 1);
			datas[0] = day;
			datas[1] = date_s;
			datas[2] = Fulldate;
			list.add(datas);
		}
		HairOptionDTO option = hair_dao.hairoption_select(dto.getHairshop_idx());
		mav.addObject("daylist", list);
		mav.addObject("dto", dto);
		mav.addObject("option", option);
		mav.setViewName("hairshop/reservation/hairshop_reservation");

		return mav;
	}

	/**
	 * reservation페이지에서  디자이너 스케줄 ajax출력
	 * @param designer_idx
	 * @param nowdate
	 * @param hair_idx
	 * @return
	 */
	@RequestMapping("/reser_desig_sche_ajax.do")
	public ModelAndView reser_desig_list(@RequestParam(value = "designer_idx",defaultValue = "0")int designer_idx,
		@RequestParam("nowdate")String nowdate, @RequestParam(value = "hair_idx",defaultValue = "0")int hair_idx,
		@RequestParam("hairshop_idx")int hairshop_idx)
	{
		String time_pattern = "T00:00:00";
		LocalDateTime now = LocalDateTime.parse(nowdate + time_pattern);
		
		List<DesignerDTO> list = null;
		if (hair_idx == 0)
		{
			list = reservationdao.reser_desig_sch_list(designer_idx, nowdate);
		}
		else
		{
			list  = reservationdao.reser_desig_list(hair_idx, nowdate ,designer_idx);
		}
		
		HairShopDTO dto =Hairshop_Dao.hairhsopInfo(hairshop_idx);
		List<String> timelist= Timelist.timelist(dto);
		Map<Integer, Object> desig_list = Timelist.schedule_list(list, now,timelist,dto);	
		ModelAndView mav = new ModelAndView();
		mav.addObject("desig_list", desig_list);
		mav.addObject("timelist", timelist);
		mav.setViewName("hairshop/reservation/reser_desig_sche_ajax");	
		return mav;
	}



	/**
	 * 예약 취소 하기
	 * @param reservation_idx
	 * @return
	 */
	@RequestMapping("/cancel.do")
	public ModelAndView reser_calcel(@RequestParam("reservation_idx")int reservation_idx ,int state)
	{	
		System.out.println("예약 취소 시작");
		IamportClient iamport = new IamportClient("0771652226910399", "Zr3aV56XST4vtlJI1HO21NX4w1AkXJ2Xb676cd3578BBtlju28x4Wv8txJOutQrEXzKaMOfTWRvqcOVe");
		ReservationDTO dto = reservationdao.reser_info(reservation_idx);	
		reservationdao.reser_state_update(reservation_idx,2);
		ModelAndView mav = new ModelAndView();
		System.out.println(dto.getReservation_number());
		CancelData can1 = new CancelData("merchant_"+dto.getReservation_number(), false);	
		IamportResponse<Payment>  payment_response =  iamport.cancelPaymentByImpUid(can1);
		String msg;
		if(payment_response.getResponse()==null)
		{
			msg= "이미 취소된 예약 입니다.";
		}
		else
		{
			msg = "예약이 취소 되었습니다.";
			
		}
		if(dto.getMember_coupon_idx()!=0)
		{
			memberDao.member_coupon_state(dto.getMember_coupon_idx(),0);
		}
		if(state == 0)//맴버에서 취소
		{
			mav.addObject("msg",msg);
			mav.addObject("page_state", "member_reservation_List.do");//페이지 상태
			mav.setViewName("msg");
		}
		else if(state ==1)//기업에서 취소
		{
			mav.addObject("msg",msg);
			mav.addObject("page_state", 1);//페이지 상태
			mav.setViewName("msg");
			
		}
		return mav;
	}

	/**
	 * 예약 페이지에서 결제 페이지로 이동
	 * @param dto
	 * @return
	 */
	@RequestMapping(value = "/payment.do",method = RequestMethod.POST)
	public ModelAndView payment(ReservationDTO dto)
	{		

		ModelAndView mav = new ModelAndView();
		MemberDTO d_dto = reservationdao.reser_member_info(dto.getMember_idx());
		HairOptionDTO option = hair_dao.hairoption_select(dto.getHairshop_idx());
		dto.setMember(d_dto);
		
		mav.addObject("reservationDTO", dto);
		mav.addObject("option", option);
		mav.setViewName("hairshop/reservation/payment");		
		return mav;
	}
	
	
	@RequestMapping(value = "/payment_ok.do",method = RequestMethod.POST)
	public ModelAndView payment_ok(ReservationDTO dto)
	{
		ModelAndView mav = new ModelAndView();
		int result = reservationdao.reser_ok(dto);	
		String msg = result>0?"예약완료":"예약 실패";
		if(dto.getMember_coupon_idx()!=0)
		{
			memberDao.member_coupon_state(dto.getMember_coupon_idx(),1);
		}
		mav.addObject("msg", msg);
		mav.addObject("page_state","index.do");
		mav.setViewName("msg");		
		return mav;
	}
	
	/**
	 *  쿠폰 리스트
	 * @param member_idx
	 * @return
	 */
	@RequestMapping("/payment_member_coupon_list.do")
	public ModelAndView payment_member_coupon_list(int hairshop_idx, HttpSession session)
	{
		ModelAndView mav = new ModelAndView();
		int member_idx = (Integer)session.getAttribute("member_idx");
		List<HairShop_CouponDTO> list  = reservationdao.reser_member_coupon_list(hairshop_idx, member_idx);
		mav.addObject("list", list);
		mav.setViewName("hairshop/reservation/pay_member_coupon_list");
		return mav;
		
	}
	
	

}
