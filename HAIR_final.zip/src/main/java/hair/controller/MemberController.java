package hair.controller;


import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import hair.hairshop.model.HairShopDAO;
import hair.hairshop.model.HairShopDTO;
import hair.hairshop.model.HairShop_CouponDTO;
import hair.member.model.MemberDAO;
import hair.member.model.MemberDTO;
import hair.member.model.Member_ReviewDAO;
import hair.member.model.Member_ReviewDTO;
import hair.member.model.Review_ReplyDAO;
import hair.member.model.Review_ReplyDTO;
import hair.message.model.MessageDTO;
import hair.reservation.model.ReservationDTO;

@Controller
public class MemberController {

	@Autowired
	private Member_ReviewDAO Member_ReviewDao;
	@Autowired
	private HairShopDAO Hairshop_Dao;
	@Autowired
	private Review_ReplyDAO Review_ReplyDao;
	@Autowired
	private MemberDAO Member_dao;
//회원가입  부분
	//아이디찾기 이동
	@RequestMapping("/member_search_id.do")
	public String member_search_id() {
		return "login/member_search_id";
	}

	
	
	//개인회원 아이디찾기 실행
	@RequestMapping(value="/member_search_id_submit.do", method=RequestMethod.POST)
	public ModelAndView member_search_id_submit(
			@RequestParam(value="member_name",required=false)String member_name,
			@RequestParam(value="member_tel", required=false)String member_tel,
			@RequestParam(value="member_email", required=false)String member_email) {
		
		List<MemberDTO> member_search_id = Member_dao.member_search_id(member_name, member_tel, member_email);
				
		ModelAndView mav = new ModelAndView();
		mav.addObject("member_search_id", member_search_id);
		mav.setViewName("login/member_search_id_submit");
		
		return mav;
	}
	/*개인회원 비밀번호 찾기 이동 */
	@RequestMapping("/member_search_pwd.do")
	public String member_search_pwd() {
		return "login/member_search_pwd";
	} 
	
	
	/*개인회원  비밀번호 찾기 실행*/
	@RequestMapping(value="/member_search_pwd_submit.do", method=RequestMethod.POST)
	public ModelAndView hairshop_search_pwd_submit(
			@RequestParam(value="member_id", required=false)String member_id,
			@RequestParam(value="member_name", required=false)String member_name,
			@RequestParam(value="member_email", required=false)String member_email) {
		
		List<MemberDTO> member_search_pwd = Member_dao.member_search_pwd(member_id, member_name, member_email);
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("member_search_pwd", member_search_pwd);
		mav.setViewName("login/member_search_pwd_submit");
		
		return mav;
	}
	
	
	/*개인회원 비밀번호 수정*/
	@RequestMapping(value="/member_pwd_update.do", method=RequestMethod.POST)
	public ModelAndView hairshop_pwd_update(
			@RequestParam(value="member_idx", required=false)String member_idx,
			@RequestParam(value="member_pwd", required=false)String member_pwd) {
		
		int result = Member_dao.member_pwd_update(member_idx, member_pwd);
		String msg = result>0?"비밀번호가 변경되었습니다":"";
		System.out.println(member_idx);
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("msg", msg);
		mav.setViewName("login/msg");
		
		return mav;
	}
	
	
	
	
	// 개인회원 회원가입 실행
		@RequestMapping("/member_join.do")
		public ModelAndView join(MemberDTO member_dto) {

			int result = Member_dao.member_join(member_dto);
			String msg = result > 0 ? "회원가입 완료" : "회원가입 실패";

			ModelAndView mav = new ModelAndView();
			mav.addObject("msg", msg);
			mav.addObject("page_state", "index.do");
			mav.setViewName("msg");

			return mav;
		}
	
//마이 페이지 이동
		@RequestMapping("/myPageForm.do")
		public ModelAndView myPageForm(HttpSession session){
						
			ModelAndView mav = mypage_info(session);
			mav.setViewName("member/mypage/member_mypage_main");				
			return mav;
		}
		
		
		public ModelAndView mypage_info(HttpSession session)
		{
			String member_name = (String)session.getAttribute("member_name");
			int member_level = (Integer)session.getAttribute("member_level");
			int member_idx = (Integer)session.getAttribute("member_idx");
			int remainingPrice = 0;
			String nextLevel = "";
			
			//결제금액 확인해서 남은금액 확인하기
			
			try{
				int resPrice = Member_dao.member_total_reservation_Price(member_idx);
			
				if(resPrice<=100000) {
					nextLevel = "브론즈";
					remainingPrice = 100000 - resPrice;
				}else if(resPrice>100000&&resPrice<=200000) {
					nextLevel = "실버";
					remainingPrice = 200000 - resPrice;
				}else 
				{
					nextLevel = "골드";
					remainingPrice = 0;
				}

			}catch(NullPointerException e) {
				nextLevel = "브론즈";
				remainingPrice = 100000;
			}
			  
			  DecimalFormat df = new DecimalFormat("#,##0");
			  String remainingPr = df.format(remainingPrice);
			 		  
			//쿠폰 개수 확인하기
			int couponCount = Member_dao.member_coupon_count(member_idx);
			
			//메세지 개수 확인하기
			int messageCount = Member_dao.member_message_Count(member_idx);
			
			
			ModelAndView mav = new ModelAndView();
			
			mav.addObject("nextLevel", nextLevel);
			mav.addObject("messageCount", messageCount);
			mav.addObject("couponCount", couponCount);
			mav.addObject("remainingPrice", remainingPr);
			mav.addObject("member_name", member_name);
			mav.addObject("member_level", member_level);		
			return mav;
		}
		
		
		
		// 마이페이지_회원탈퇴 페이지 이동
		@RequestMapping("/member_Leave_Form.do")
			public ModelAndView memberLeaveForm(HttpSession session){
			ModelAndView mav = mypage_info(session);
			mav.setViewName("member/mypage/member_myPage_memberLeaveForm");
			return mav;
			}			
		
		
		
	
		
		
		// 마이페이지_회원탈퇴 시 비밀번호 확인
		@RequestMapping("/member_pwd_Check.do")
		public ModelAndView pwd_Check(HttpSession session,
				@RequestParam(value = "member_pwd", required = false) String member_pwd) {

			ModelAndView mav = new ModelAndView();
			int member_idx = (Integer) session.getAttribute("member_idx");
			String result = Member_dao.member_pwd_Check(member_idx);
			if (result.equals(member_pwd)) {
				mav.setViewName("redirect:/member_Leave.do");
			} else {
				mav.addObject("msg", "비밀번호가 일치하지 않습니다.");
				mav.addObject("goPage", "myPageForm.do");
				mav.setViewName("member/memberMsg");
			}
			return mav;
		}
			
		// 마이페이지_회원탈퇴 실행
		@RequestMapping("/member_Leave.do")
		public ModelAndView memberLeave(HttpSession session) {

			int member_idx = (Integer) session.getAttribute("member_idx");
			int member_state = 3;
			int result = Member_dao.member_Leave(member_idx, member_state);
			String msg = result > 0 ? "회원탈퇴가 완료되었습니다." : "회원탈퇴 실패 (관리자에게 문의하세요.)";

			if (result > 0) {
				session.invalidate();
			}

			ModelAndView mav = new ModelAndView();
			mav.addObject("msg", msg);
			mav.addObject("goPage", "index.do");
			mav.setViewName("member/memberMsg");
			return mav;

		}
		
		// 마이페이지_정보변경_비밀번호 확인 페이지 이동
		@RequestMapping("/member_pwd_Check2.do")
		public ModelAndView pwdCheck(HttpSession session) {
			ModelAndView mav  =  mypage_info(session);
			mav.setViewName("member/mypage/member_myPage_memberUpdate_pwdCheck");
			return mav;
		}
	
		
		  // 마이페이지_정보변경_비밀번호 확인 실행
	      @RequestMapping("/member_pwdCk.do")
	      public ModelAndView pwdCk(HttpSession session,
	            @RequestParam(value = "member_pwd", required = false) String member_pwd) {

	         ModelAndView mav  =  mypage_info(session);
	         
	         int member_idx = (Integer) session.getAttribute("member_idx");
	         System.out.println(member_idx);
	         String result = Member_dao.member_pwd_Check(member_idx);
	         
	         if (result.equals(member_pwd)) {
	            mav.addObject("msg", "비밀번호 확인 완료");
	            mav.addObject("goPage", "member_update_Form.do");
	            mav.setViewName("member/memberMsg");
	         } else {
	            mav.addObject("msg", "2");
	            mav.setViewName("member/mypage/member_myPage_memberUpdate_pwdCheck");
	         }
	         return mav;
	      }
		
		
		
		// 마이페이지_정보변경_회원정보 수정 페이지 이동
		@RequestMapping("/member_update_Form.do")
		public ModelAndView memebrInfo(HttpSession session) {

			ModelAndView mav  =  mypage_info(session);

			String member_id = (String) session.getAttribute("member_id");
			MemberDTO mInfo = Member_dao.member_Info(member_id);
			

			String addr = mInfo.getMember_addr();
		

			String[] addrAll = addr.split(",");
			String addr1 = addrAll[0];
			String addr2 = addrAll[1];
			String addr3 = addrAll[2];

			mav.addObject("addr1", addr1);
			mav.addObject("addr2", addr2);
			mav.addObject("addr3", addr3);

			mav.addObject("mInfo", mInfo);
			mav.setViewName("member/mypage/member_myPage_memberUpdateForm");
			return mav;
		}
		
		
		// 마이페이지_정보변경_회원정보수정 실행
		@RequestMapping("/member_upadate.do")
		public ModelAndView memberUpdate(HttpSession session,
				@RequestParam(value = "member_pwd", required = false) String member_pwd,
				@RequestParam(value = "member_email", required = false) String member_email,
				@RequestParam(value = "member_addr", required = false) String member_addr,
				@RequestParam(value = "member_tel", required = false) String member_tel) {

			String member_id = (String) session.getAttribute("member_id");

			int result = Member_dao.member_Update(member_id, member_pwd, member_email, member_addr, member_tel);
			// System.out.println(result>0?"성공":"실패");

			ModelAndView mav = new ModelAndView();

			mav.addObject("msg", "정보수정완료");
			mav.addObject("goPage", "index.do");
			mav.setViewName("member/memberMsg");
			return mav;
		}
		
		
		// 마이페이지_예약리스트
		@RequestMapping("member_reservation_List.do")
		public ModelAndView reservationList(HttpSession session) {

			int member_idx = (Integer) session.getAttribute("member_idx");

			List<ReservationDTO> resList = Member_dao.member_reservation_List(member_idx);
			ModelAndView mav = mypage_info(session);

			mav.addObject("resList", resList);
			mav.setViewName("member/mypage/member_mypage_reservationList");
			return mav;
		}


		// 마이페이지_예약리스트_예약취소
		@RequestMapping("member_reservation_Cancle.do")
		public ModelAndView resCancle(@RequestParam(value = "reservation_idx", required = false) int reservation_idx) {

			ModelAndView mav = new ModelAndView();
			int resCancle = Member_dao.member_reservation_Cancle(reservation_idx);
			
			if (resCancle == 1) {
				mav.addObject("msg", "예약취소 완료");
				mav.addObject("page_state", "member_reservation_List.do");
				mav.setViewName("msg");
			} else {
				mav.addObject("msg", "예약취소 실패");
				mav.addObject("page_state", "member_reservation_List,do");
				mav.setViewName("msg");
			}

			return mav;
		}
	

		// 마이페이지_내가작성한 리뷰 리스트
		@RequestMapping("member_review_List.do")
		public ModelAndView member_review_List(HttpSession session) {

			int member_idx = (Integer) session.getAttribute("member_idx");

			List<Member_ReviewDTO> reviewList = Member_dao.member_review_List(member_idx);
			ModelAndView mav = mypage_info(session);
		
			mav.addObject("reviewList", reviewList);
			mav.setViewName("member/mypage/member_mypage_reviewList");
			return mav;
		}
	
	
		// 마이페이지_관심리스트_헤어샵
		@RequestMapping("/member_good_List.do")
		public ModelAndView goodList(HttpSession session) {

			ModelAndView mav = mypage_info(session);
			List<Object> list = new ArrayList<Object>();
			int goodShop_countReservation = 0;
			int goodShop_countFavorite = 0;

			int member_idx = (Integer) session.getAttribute("member_idx");
			List<HairShopDTO> goodShop_hairshopInfo = Member_dao.member_goodShop_hairshop_Info(member_idx);

			if (goodShop_hairshopInfo.size() != 0) {
				for (int i = 0; i < goodShop_hairshopInfo.size(); i++) {
					int hairshop_idx = goodShop_hairshopInfo.get(i).getHairshop_idx();
					HashMap<String, Object> goodShop_avg_countReview = Member_dao.member_goodShop_avg_count_Review(hairshop_idx);
					goodShop_countReservation = Member_dao.member_goodShop_count_Reservation(hairshop_idx);
					// System.out.println(goodShop_avg_countReview);
					list.add(goodShop_avg_countReview);
					goodShop_countFavorite = Member_dao.member_goodShop_count_Favorite(hairshop_idx);
				}
			}
			List<HashMap<String, Object>> goodStyle = Member_dao.member_good_Style(member_idx);

			mav.addObject("goodStyle", goodStyle);
			mav.addObject("countFavr", goodShop_countFavorite);
			mav.addObject("countRes", goodShop_countReservation);
			mav.addObject("list", list);
			mav.addObject("hInfo", goodShop_hairshopInfo);
			mav.setViewName("member/mypage/member_mypage_goodList");
			return mav;
		}
	
	
		// 마이페이지_관심리스트_스타일
		@RequestMapping("/member_good_Style.do")
		public ModelAndView goodStyle(HttpSession session) {

			ModelAndView mav = new ModelAndView();

			int member_idx = (Integer) session.getAttribute("member_idx");
			// System.out.println(member_idx);
			List<HashMap<String, Object>> goodStyle = Member_dao.member_good_Style(member_idx);

			mav.addObject("goodStyle", goodStyle);
			mav.setViewName("member/mypage/member_myPgae_goodList");
			return mav;
		}
		
		
		// 마이페이지_관심 헤어샵_취소
		@RequestMapping("/member_goodshop_Cancle.do")
		public ModelAndView goodHairshop(HttpSession session,
				@RequestParam(value = "hairshop_idx", required = false) int[] hairshop_idx) {

			ModelAndView mav = new ModelAndView();
			int goodshopCancle = 0;
			int member_idx = (Integer) session.getAttribute("member_idx");

			for (int i = 0; i < hairshop_idx.length; i++) {
				goodshopCancle = Member_dao.member_goodshop_Cancle(member_idx, hairshop_idx[i]);
			}

			if (goodshopCancle == 1) {
				mav.addObject("msg", "관심취소 완료");
				mav.addObject("goPage", "member_good_List.do");
				mav.setViewName("member/member_memberMsg");
			} else {
				mav.addObject("msg", "관심취소 실패");
				mav.addObject("goPage", "member_good_List.do");
				mav.setViewName("member/member_memberMsg");
			}

			return mav;
		}
	

		// 마이페이지_관심 스타일_취소
		@RequestMapping("/member_good_style_Cancle.do")
		public ModelAndView goodStyle(HttpSession session,
				@RequestParam(value = "hairshop_bbs_idx", required = false) int[] hairshop_bbs_idx) {

			ModelAndView mav = new ModelAndView();
			int goodstyleCancle = 0;
			int member_idx = (Integer) session.getAttribute("member_idx");

			for (int i = 0; i < hairshop_bbs_idx.length; i++) {
				goodstyleCancle = Member_dao.member_good_style_Cancle(member_idx, hairshop_bbs_idx[i]);
			}

			if (goodstyleCancle == 1) {
				mav.addObject("msg", "관심취소 완료");
				mav.addObject("goPage", "member_good_List.do");
				mav.setViewName("member/member_memberMsg");
			} else {
				mav.addObject("msg", "관심취소 실패");
				mav.addObject("goPage", "member_good_List.do");
				mav.setViewName("member/member_memberMsg");
			}

			return mav;
		}
		
		//////////////////////////////////msg///////////////////////////////////////

		/**나의 메세지함으로 이동*/
		@RequestMapping("/member_myMessage.do")
		public ModelAndView member_message(HttpSession session) {
			ModelAndView mav = mypage_info(session);
			mav.setViewName("member/msg/member_myMessage");
			return mav;
		}

		
		@RequestMapping("/member_myMessageState.do")
		public ModelAndView member_myMessageState(@RequestParam(value="cp",defaultValue="1")int cp,
	            								  @RequestParam("message_state")int state ,HttpSession session) {
			
			ModelAndView mav=new ModelAndView();
			
			//페이징
	        int totalCnt=0;
	        int listSize=5;
	        int pageSize=5;
	              
	        String pageStr=null;
	              
	        //목록
	        int member_idx = (Integer)session.getAttribute("member_idx");
	        List<MessageDTO> member_sendMsg = null;
	        List<MessageDTO> member_receiveMsg = null;
	        
	        if(state==1) {
	           
	           totalCnt=Member_dao.member_receiveMessage_TotalCnt(member_idx);
	           pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
	           member_receiveMsg=Member_dao.receivelist(member_idx,cp,listSize);
	           mav.addObject("paging", pageStr);
	           mav.addObject("member_receiveMsg", member_receiveMsg);
	           mav.setViewName("member/msg/member_myMessageState1");
	           
	        }else if(state==2) {
	        	
	        	totalCnt=Member_dao.member_sendMessage_TotalCnt(member_idx);
	            pageStr=hair.page.PageModule.makePage("javascript:doStateResult", totalCnt, listSize, pageSize, cp, state);
	            member_sendMsg=Member_dao.sendlist(member_idx,cp,listSize);
	            mav.addObject("paging", pageStr);
	            mav.addObject("member_sendMsg", member_sendMsg);
	            mav.setViewName("member/msg/member_myMessageState2");
	        }
	        return mav;
		}
		
		/**메세지 내용 불러오기
		 * member_receiveMsg_content.jsp 받은메세지 내용보기*/
		@RequestMapping("/member_open_re_message.do")
		public ModelAndView open_msg(@RequestParam(value="memberName",required=false, defaultValue="")String member_name,
				@RequestParam(value="hairshopName",required=false, defaultValue="")String hairshop_name,
				@RequestParam("messageIdx")int message_idx) {
			ModelAndView mav = new ModelAndView();
			MessageDTO messageInfo = Member_dao.member_message_Info(message_idx);
			
			mav.addObject("hairshop_name", hairshop_name);
			System.out.println(hairshop_name);
			mav.addObject("member_name", member_name);
			System.out.println(member_name);
			mav.addObject("message_idx", message_idx);
			mav.addObject("message_info", messageInfo);
			mav.setViewName("member/msg/member_receiveMsg_content");
			return mav;
		}
			
		/**답장하기 폼으로 이동*/
		@RequestMapping("/member_re_messageForm.do")
		public ModelAndView remessageForm(@RequestParam("senderIdx")int sender_idx,
				@RequestParam(value="memberName",required=false, defaultValue="")String member_name,
				@RequestParam(value="hairshopName",required=false, defaultValue="")String hairshop_name,
				@RequestParam("messageIdx")int message_idx) {
			ModelAndView mav = new ModelAndView();
			int result = Member_dao.member_msg_Check(message_idx);
				if(result>0) {
					System.out.println("성공");
				}else {
					System.out.println("실패");
				}
			mav.addObject("sender_idx", sender_idx);
			mav.addObject("hairshop_name", hairshop_name);
			mav.addObject("member_name", member_name);
			mav.setViewName("member/msg/member_remessage");
			return mav;
		}
		
		/**답장 보내기*/
		@RequestMapping(value="/member_re_message.do", method=RequestMethod.POST)
		public ModelAndView member_remessage(HttpSession session,@RequestParam("receiver_idx")int receiver_idx,
				@RequestParam("message_content")String message_content) {
			ModelAndView mav = new ModelAndView();
			int sender_idx=17;
			int result = Member_dao.member_remessage(sender_idx, receiver_idx, message_content);
			if(result>0) {
				mav.addObject("msg", "메세지를 전송하였습니다.");
			}else {
				mav.addObject("msg", "오류가 발생하였습니다. 관리자에게 문의 하세요.");
			}
			mav.setViewName("member/msg/member_message_ok");
			return mav;
		}
		
		/**보낸메세지 내용 불러오기*/
		@RequestMapping("/member_open_se_message.do")
		public ModelAndView semessageForm(@RequestParam("messageIdx")int message_idx,
				@RequestParam(value="memberName",required=false, defaultValue="")String member_name,
				@RequestParam(value="hairshopName",required=false, defaultValue="")String hairshop_name) {
			ModelAndView mav = new ModelAndView();
			MessageDTO messageInfo = Member_dao.member_message_Info(message_idx);
			
			mav.addObject("message_info", messageInfo);
			mav.addObject("member_name", member_name);
			mav.addObject("hairshop_name", hairshop_name);
			mav.setViewName("member/msg/member_sendMsg_content");
			return mav;
		}
		
		@RequestMapping("/member_checkMsg.do")
		public ModelAndView checkMsg(@RequestParam("message_idx")int message_idx) {
			ModelAndView mav = new ModelAndView();
			
			int result = Member_dao.member_msg_Check(message_idx);
			if(result>0) {
				System.out.println("성공");
				mav.setViewName("member/msg/member_checkMsg");
			}else {
				System.out.println("실패");
			}
			return mav;
		}
				
		@RequestMapping("/msgTrash.do")
		public ModelAndView deleteMsg(@RequestParam("msgChecked")int message_idx[]) {
			ModelAndView mav = new ModelAndView();
			int result  = 0;
			for(int i = 0;i<message_idx.length;i++)
			{
				result = Member_dao.member_del_Msg(message_idx[i]);
			}		
			
			if(result > 0) {
				mav.addObject("msg", "메세지를 삭제하였습니다.");
				mav.addObject("page", "myPageForm.do");
			}else {
				mav.addObject("msg", "오류가 발생하였습니다. 관리자에게 문의하세요.");
				mav.addObject("page", "myPageForm.do");
			}
		
			mav.setViewName("member/msg/member_delMsg_ok");
			return mav;
		}
		
		//마이페이지 쿠폰 리스트
		@RequestMapping("/member_coupon_list.do")
		public ModelAndView member_coupon_list(HttpSession session)
		{
			ModelAndView mav =  mypage_info(session);
			int member_idx = (Integer)session.getAttribute("member_idx");
			List<HairShop_CouponDTO> list = Member_dao.member_coupon_list(member_idx);
			
			mav.addObject("list",list);
			mav.setViewName("/member/mypage/member_mypage_coupon_list");			
			return mav;
					
		}
		
		
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	
		
	/**
	 * 리뷰쓰기로 진입하는 컨트롤러
	 * 
	 * @param hairshop_idx
	 *            쓸 리뷰의 헤어샵 idx
	 * @param reservation_idx
	 *            리뷰에 대한 예약번호
	 */
	@RequestMapping(value = "/MemberReviewWrite.do")
	public ModelAndView memberRivewBbsWrite(int hairshop_idx, int reservation_idx, HttpServletRequest req,
			HttpServletResponse res) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("hairshop_idx", hairshop_idx);
		mav.addObject("reservation_idx", reservation_idx);
		mav.setViewName("member/review/member_review_write");
		return mav;
	}

	/**
	 * 리뷰 업데이트트를 완료하는 컨트롤러
	 * 
	 * @param hairshop_idx
	 *            쓸 리뷰의 헤어샵 idx
	 * @param reservation_idx
	 *            리뷰에 대한 예약번호
	 */
	@RequestMapping(value = "/MemberReviewUpdate_ok.do")
	public ModelAndView memberRivewBbsUpdate_ok(Member_ReviewDTO dto) {
		ModelAndView mav = new ModelAndView();
		int result = Member_ReviewDao.memberReviewUpdate(dto);

		String msg = result > 0 ? "성공" : "실패";
		mav.addObject("msg", msg);
		mav.addObject("page_state", "memberReviewContent.do?member_review_idx="+dto.getMember_review_idx());
		mav.setViewName("msg");
		return mav;
	}

	/**
	 * 리뷰쓰기 완료시 폼 정보를 전송하는 컨트롤러
	 * 
	 * @param dto
	 *            모든 정보를 담고 있는 dto
	 */
	@RequestMapping(value = "/MemberReviewWrite_ok.do")
	public ModelAndView memberRivewBbsWrite_ok(Member_ReviewDTO dto) {
		ModelAndView mav = new ModelAndView();
		int result = Member_ReviewDao.memberReviewWrite(dto);
		String msg = result > 0 ? "성공" : "실패";
		mav.addObject("msg", msg);
		mav.addObject("page_state", "myPageForm.do");
		mav.setViewName("msg");
		return mav;
	}

	/**
	 * 리뷰 삭제하는 컨트롤러
	 * 
	 * @param meber_review_idx
	 *            삭제를 눌리는 글의 idx
	 */
	@RequestMapping("/member_review_del.do")
	public ModelAndView hairshop_bbs_del(int member_review_idx) {
		ModelAndView mav = new ModelAndView();
		int result = Member_ReviewDao.memberReviewDel(member_review_idx);
		String msg = result > 0 ? "성공" : "실패";
		mav.addObject("msg", msg);
		mav.setViewName("msg");
		mav.addObject("page_state", "myPageForm.do");
		return mav;
	}

	/**
	 * 회원 리뷰 리스트로 이동하는 컨트롤러
	 * 
	 * @param cp
	 *            사용자의 현재 위치
	 * @param search_option
	 *            어떤 검색을 했는 지 알기 위해
	 * @param search_value
	 *            어떤 키워드로 검색을 했는지
	 * @param order
	 *            어떤 정렬을 했는지
	 */
	@RequestMapping(value = "/MemberReviewList.do")
	public ModelAndView member_review_list(@RequestParam(value = "cp", required = false, defaultValue = "1") Integer cp,
			@RequestParam(value = "search_option", required = false, defaultValue = "subject") String search_option,
			@RequestParam(value = "search_value", required = false, defaultValue = "") String search_value,
			@RequestParam(value = "order", required = false, defaultValue = "MEMBER_REVIEW_WRITEDATE") String order) {

		ModelAndView mav = new ModelAndView();
		int totalCnt = Member_ReviewDao.memberReviewTotalCnt(search_option, search_value);
		int listSize = 20;
		int pageSize = 5;
		List<Member_ReviewDTO> list = Member_ReviewDao.memberReviewList(cp, listSize, search_option, search_value,
				order);
		mav.addObject("arr", list);
		String param = "&search_option=" + search_option + "&search_value=" + search_value + "&order=" + order;
		String pageStr = hair.paging.PageModule.makePage("MemberReviewList.do", totalCnt, listSize, pageSize, cp,
				param);
		mav.addObject("pageStr", pageStr);

		mav.setViewName("member/review/member_review_list");
		return mav;
	}

	/**
	 * 회원 리뷰의 본문으로 이동하는 컨트롤러
	 * 
	 * @param idx
	 *            해당하는 글의 idx
	 */
	@RequestMapping(value = "/memberReviewContent.do")
	public ModelAndView memberReviewContent(
			@RequestParam(value = "member_review_idx", required = false, defaultValue = "-1") Integer idx) {
		ModelAndView mav = new ModelAndView();
		Member_ReviewDTO dto = Member_ReviewDao.memberReviewContent(idx);
		HairShopDTO hsdto = Hairshop_Dao.hairhsopInfo(dto.getHairshop_idx());
		List<Review_ReplyDTO> reply = Review_ReplyDao.review_reply(idx);
		mav.addObject("dto", dto);
		mav.addObject("hsdto", hsdto);
		mav.addObject("reply", reply);
		mav.setViewName("member/review/member_review_content");
		return mav;
	}

	/**
	 * 회원 리뷰를 수정하는 컨트롤러
	 * 
	 * @param idx
	 *            해당하는 글의 idx
	 */
	@RequestMapping(value = "/memberReviewUpdate.do")
	public ModelAndView memberReviewUpdate(
			@RequestParam(value = "member_review_idx", required = false, defaultValue = "-1") Integer idx) {
		ModelAndView mav = new ModelAndView();
		Member_ReviewDTO dto = Member_ReviewDao.memberReviewContent(idx);
		mav.addObject("dto", dto);
		mav.setViewName("member/review/member_review_update");
		return mav;
	}

	/**
	 * 회원리뷰 의 댓글을 작성하는 컨트롤러
	 * 
	 * @param dto
	 *            댓글의 모든 정보를 가진 dto
	 */
	@RequestMapping(value = "/review_reply_write.do")
	public ModelAndView review_reply_write(Review_ReplyDTO dto) {
		ModelAndView mav = new ModelAndView();
		Review_ReplyDTO dto_s = Review_ReplyDao.review_reply_write(dto);
		mav.addObject("dto", dto_s);

		mav.setViewName("member/review/review_ajax");
		return mav;
	}

	/**
	 * 회원 리뷰의 댓글을 삭제하는 컨트롤러
	 * 
	 * @param review_reply_idx
	 *            해당하는 글의 idx
	 */
	@RequestMapping(value = "review_reply_delete.do")
	public void review_reply_delete(int review_reply_idx) {
		Review_ReplyDao.review_reply_delete(review_reply_idx);
	}

	/**
	 * 회원 리뷰의 댓글을 수정하는 컨트롤러
	 * 
	 * @param review_reply_idx
	 *            수정할 갯글의 idx
	 * @param review_reply_content
	 *            수정할 댓글의 내용
	 */
	@RequestMapping(value = "review_reply_rewrite.do")
	public ModelAndView review_reply_rewrite(int review_reply_idx, String review_reply_content) {
		ModelAndView mav = new ModelAndView();
		Review_ReplyDTO dto = Review_ReplyDao.review_reply_rewrite(review_reply_idx, review_reply_content);
		mav.addObject("dto", dto);
		System.out.println("헤오샵이름=" + dto.getHairshop_name());
		mav.setViewName("member/review/review_ajax");
		return mav;
	}


	
	

}
