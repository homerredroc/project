package hair.controller;

import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MailController {

	@Autowired
	private JavaMailSender mailSender;

	
	// mailSending 
	@RequestMapping("/mailSending.do")
	public void mailSending(HttpServletRequest request) {
				   
	
		
		    String tomail  = request.getParameter("tomail");     // 수신 이메일주소
		    String content = request.getParameter("content");    // 인증번호
		    System.out.println(tomail);
		    String announcement = "안녕하세요. 모두의헤어입니다."
					    		+ "\n\n이메일 주소 확인을 위한 이메일 인증 절차입니다."
					    		+ "\n아래 인증번호를 인증번호 입력란에 입력하시기 바랍니다."
					    		+ "\n\n이메일이 정상적으로 인증되지 않을 경우, 고객센터로 문의바랍니다.";
		    
		    try {
			      MimeMessage message = mailSender.createMimeMessage();
			      MimeMessageHelper messageHelper = new MimeMessageHelper(message, true, "UTF-8");
			 	     
			      messageHelper.setTo(tomail); // 수신 이메일주소
			      messageHelper.setSubject("[모두의 헤어]이메일 인증 인증번호"); // 메일제목
			      messageHelper.setText(announcement+"\n\n[ 인증번호: "+content+" ]");  // 메일 내용
			     
			      mailSender.send(message);
			
		    } catch(Exception e){
		    	System.out.println(e);	    
	    
		    }		   
		    	
	}
}
