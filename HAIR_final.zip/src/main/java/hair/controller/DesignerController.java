package hair.controller;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import hair.hairshop.designer.model.DesignerDAO;
import hair.hairshop.designer.model.DesignerDTO;
import hair.hairshop.designer.model.Designer_ScheduleDTO;
import hair.hairshop.model.HairShopDAO;
import hair.hairshop.model.HairShopDTO;
import hair.module.Timelist;
import hair.reservation.model.ReservationDAO;
import hair.reservation.model.ReservationDTO;

@Controller
public class DesignerController {
	
	@Autowired
	private DesignerDAO designerDAO;
	@Autowired
	private HairShopDAO Hairshop_Dao;
	
	@Autowired
	private ReservationDAO reservationdao;
	
	/**
	 * desig_on_off_등록 페이지 이동 	 
	 * @return
	 */
	@RequestMapping("/desig_schedule_onoff_reg.do")
	public ModelAndView desig_schedule_onoff(int designer_idx,String designer_name)
	{
		ModelAndView mav = new ModelAndView();
		  mav.addObject("designer_idx", designer_idx);
		  mav.addObject("designer_name", designer_name);
		  mav.setViewName("hairshop/designer/desig_on_off_reg");
		return mav;
	}
	
	/**
	 * desig_on_off_list로 페이지 이동
	 * @return
	 */
	@RequestMapping("/desig_schedule_onoff_list.do")
	public String desig_schedule_onoff_list()
	{	
		return "hairshop/designer/desig_on_off_list";
	}
	
	/**
	 * desig_on_off_list 에서 등록된 스케줄 삭제
	 * @param schedule_idx 스케줄 idx
	 * @return
	 */
	@RequestMapping("/schedule_delete.do")
	public ModelAndView schedule_delete(int schedule_idx)
	{
		ModelAndView mav = new ModelAndView();
		int count = designerDAO.desig_schedule_delete(schedule_idx);
		String msg = count>0?"삭제 성공":"삭제 실패";
		mav.addObject("msg", msg);
		mav.addObject("page_state", 1);
		mav.setViewName("msg");
		return mav;
	}
	
	/**
	 *  desig_schedule_list에서 예약 정보 불러오기
	 * @param 예약 idx
	 * @return map
	 */
	@RequestMapping("/reservation_info.do")
	public ModelAndView reser_info(@RequestParam("reservation_idx")int idx)
	{
		ModelAndView mav = new ModelAndView();
		ReservationDTO dto = reservationdao.reser_info(idx);
	
		mav.addObject("dto", dto);
		mav.setViewName("hairshop/designer/desig_schedule_reser_info");
		return mav;
	}
	/**
	 * desig_schedule_list 페이지 이동
	 * @return
	 */
	@RequestMapping("/desig_schedule.do")
	public String desig_schedule() {
		return "hairshop/designer/desig_schedule_list";
	}
	
	/**
	 * desig_schedule_list페이지에 디자이너의 스케줄을 보여줄 ajax
	 * @param hairshop_idx  헤어샵 _idx
	 * @param date  지정된 날짜
	 * @return 지정된 날짜의 다자이너들의 스케줄데이터	
	 * @throws ParseException
	 */
	@RequestMapping("/desig_schedule_list_ajax.do")
	public ModelAndView desig_schedule_list_ajax(int hairshop_idx, @RequestParam("nowdate") String date) 
			throws ParseException {
		
		String time_pattern = "T00:00:00";
		LocalDateTime now = LocalDateTime.parse(date + time_pattern);

		HairShopDTO dto = Hairshop_Dao.hairhsopInfo(hairshop_idx);
		List<DesignerDTO> list = designerDAO.desig_schedule_list_ajax(hairshop_idx, date);
		List<String> timelist= Timelist.timelist(dto);
		Map<Integer, Object> desig_list = Timelist.schedule_list(list, now,timelist,dto);
  

		ModelAndView mav = new ModelAndView();
		mav.addObject("desig_list", desig_list);
		mav.addObject("timelist", timelist);
		mav.setViewName("hairshop/designer/desig_schedule_list_ajax");
		return mav;
	}
	
	/**
	 * select 태그에서 출력할 desig_list ajax
	 * @param 헤어샵 idx           
	 */
	@RequestMapping("select_desig_list_ajax.do")
	public ModelAndView desig_list_ajax(int hairshop_idx) {
		ModelAndView mav = new ModelAndView();
		List<DesignerDTO> list = designerDAO.desig_list(hairshop_idx);
		mav.addObject("list", list);
		mav.setViewName("hairshop/hair/select_desig_list_ajax");
		return mav;
	}
	
	/**
	 * desig_onoff_reg 페이지 에서 onoff 스케줄 등록 하기
	 * @param dto 디자이너 스케줄 dto
	 * @return
	 */
	@RequestMapping("/desig_onoff_reg_ok.do")
	public ModelAndView desig_onoff_reg_ok(Designer_ScheduleDTO dto)
	{
		ModelAndView mav = new ModelAndView();
		int result = designerDAO.desig_schedule_reg(dto);
		String msg  = result>0?"등록 성공":"등록실패";
		mav.setViewName("msg");
		mav.addObject("msg",msg);
		mav.addObject("page_state", 1);
		return mav;
	}
	
	/**
	 * desig_onoff_list_ajax 출력
	 * @param hairshop_idx
	 * @param nowdate
	 * @return
	 */
	@RequestMapping("/desig_onoff_list_ajax.do")
	public ModelAndView desig_onoff_list_ajax(int hairshop_idx, String nowdate)
	{
		ModelAndView mav = new ModelAndView();
		List<Designer_ScheduleDTO> list = designerDAO.desig_onoff_list(hairshop_idx,nowdate);
		mav.addObject("desig_list", list);
		mav.setViewName("hairshop/designer/desig_on_off_list_ajax");
		return mav;
	}
}
