package hair.spon.model;

import java.util.List;

public interface SponDAO {
	public int hairshop_spon(int hairshop_idx, int updown);
	public int hairshop_bbs_spon(int hairshop_idx, int updown);
	//관리자 페이지 - 대기 스폰 totalCnt
		public int readySpon_totalCnt();
		
		//관리자 페이지 - 승인 스폰 totalCnt
		public int joinSpon_totalCnt();
		
		//관리자 페이지 - 진행 스폰 totalCnt
		public int startSpon_totalCnt();
		
		//관리자 페이지 - 종료 스폰 totalCnt
		public int finishSpon_totalCnt();
		
		//관리자 페이지 - 취소 스폰 totalCnt
		public int cancelSpon_totalCnt();
		
		//관리자 페이지 - 미 승인 스폰 totalCnt
		public int rejectSpon_totalCnt();

		//관리자 페이지 - 대기 스폰 목록보기
		public List<SponDTO> readySponList(int cp,int ls);
		
		//관리자 페이지 - 승인 스폰 목록보기
		public List<SponDTO> joinSponList(int cp,int ls);
		
		//관리자 페이지 - 진행 스폰 목록보기
		public List<SponDTO> startSponList(int cp,int ls);
		
		//관리자 페이지 - 종료 스폰 목록보기
		public List<SponDTO> finishSponList(int cp,int ls);
		
		//관리자 페이지 - 취소 스폰 목록보기
		public List<SponDTO> cancelSponList(int cp,int ls);
		
		//관리자 페이지 - 미 승인 스폰 목록보기
		public List<SponDTO> rejectSponList(int cp,int ls);
		
		//관리자 페이지 - 진행 스폰 총 금액 확인하기
		public int startSponTotalPrice();
		
		//관리자 페이지 - 종료 스폰 총 금액 확인하기
		public int finishSponTotalPrice();
		
		//관리자 페이지 - 스폰 내용보기
		public String sponInfo(int spon_idx);
		
		//관리자 페이지 - 스폰 승인하기
		public int makeSponJoin(int spon_idx);
		
		//관리자 페이지 - 스폰 승인하면 게시글 스폰level도 바꾸기
		public int makeBbsJoin(int hairshop_idx);
		
		//관리자 페이지 - 스폰 미 승인하기
		public int rejectSponJoin(int spon_idx);
		
		//관리자 페이지 - 스폰 진행시키기
		public int makeSponStart(int spon_idx);
		
		//관리자 페이지 - 스폰 취소시키기
		public int makeSponCancel(int spon_idx);
		
		//관리자 페이지 - 스폰 종료시키기
		public int makeSponFinish(int spon_idx);
	
}
