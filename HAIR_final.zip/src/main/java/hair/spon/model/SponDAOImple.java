package hair.spon.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;

public class SponDAOImple implements SponDAO {
	
	private SqlSessionTemplate sqlMap;
	
	public SponDAOImple(SqlSessionTemplate sqlMap) {
		super();
		this.sqlMap = sqlMap;
	}
	
	public int hairshop_spon(int hairshop_idx, int updown) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("hairshop_idx", hairshop_idx);
		map.put("hairshop_level",updown);
		return sqlMap.update("hairshop_spon",map);
	}
	public int hairshop_bbs_spon(int hairshop_idx, int updown) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("hairshop_idx", hairshop_idx);
		map.put("hairshop_bbs_level",updown);
		return sqlMap.update("hairshop_bbs_spon",map);
	}
	//관리자 페이지 - 대기 스폰 totalCnt
		public int readySpon_totalCnt() {
			
			int count=sqlMap.selectOne("readySpon_totalCnt");
			
			return count;
		}
		
		//관리자 페이지 - 승인 스폰 totalCnt
		public int joinSpon_totalCnt() {
			
			int count=sqlMap.selectOne("joinSpon_totalCnt");
			
			return count;
		}
		
		//관리자 페이지 - 진행 스폰 totalCnt
		public int startSpon_totalCnt() {
			
			int count=sqlMap.selectOne("startSpon_totalCnt");
			
			return count;
		}
		
		//관리자 페이지 - 종료 스폰 totalCnt
		public int finishSpon_totalCnt() {
			
			int count=sqlMap.selectOne("finishSpon_totalCnt");
			
			return count;
		}
		
		//관리자 페이지 - 취소 스폰 totalCnt
		public int cancelSpon_totalCnt() {
			
			int count=sqlMap.selectOne("cancelSpon_totalCnt");
			
			return count;
		}
		
		//관리자 페이지 - 미 승인 스폰 totalCnt
		public int rejectSpon_totalCnt() {
			
			int count=sqlMap.selectOne("rejectSpon_totalCnt");
			
			return count;
		}

		//관리자 페이지 - 대기 스폰 목록보기
		public List<SponDTO> readySponList(int cp,int ls) {
			
			int startnum=(cp-1)*ls+1;
			int endnum=cp*ls;
			
			Map<String, Integer> map=new HashMap<String, Integer>();
			map.put("startnum", startnum);
			map.put("endnum", endnum);
			
			List<SponDTO> list=sqlMap.selectList("readySponList", map);
			
			return list;
		}
		
		//관리자 페이지 - 승인 스폰 목록보기
		public List<SponDTO> joinSponList(int cp,int ls) {
			
			int startnum=(cp-1)*ls+1;
			int endnum=cp*ls;
			
			Map<String, Integer> map=new HashMap<String, Integer>();
			map.put("startnum", startnum);
			map.put("endnum", endnum);
			
			List<SponDTO> list=sqlMap.selectList("joinSponList", map);
			
			return list;
		}
		
		//관리자 페이지 - 진행 스폰 목록보기
		public List<SponDTO> startSponList(int cp,int ls) {
			
			int startnum=(cp-1)*ls+1;
			int endnum=cp*ls;
			
			Map<String, Integer> map=new HashMap<String, Integer>();
			map.put("startnum", startnum);
			map.put("endnum", endnum);
			
			List<SponDTO> list=sqlMap.selectList("startSponList", map);
			
			return list;
		}
		
		//관리자 페이지 - 종료 스폰 목록보기
		public List<SponDTO> finishSponList(int cp,int ls) {
			
			int startnum=(cp-1)*ls+1;
			int endnum=cp*ls;
			
			Map<String, Integer> map=new HashMap<String, Integer>();
			map.put("startnum", startnum);
			map.put("endnum", endnum);
			
			List<SponDTO> list=sqlMap.selectList("finishSponList", map);
			
			return list;
		}
		
		//관리자 페이지 - 취소 스폰 목록보기
		public List<SponDTO> cancelSponList(int cp,int ls) {
			
			int startnum=(cp-1)*ls+1;
			int endnum=cp*ls;
			
			Map<String, Integer> map=new HashMap<String, Integer>();
			map.put("startnum", startnum);
			map.put("endnum", endnum);
			
			List<SponDTO> list=sqlMap.selectList("cancelSponList", map);
			
			return list;
		}
		
		//관리자 페이지 - 미 승인 스폰 목록보기
		public List<SponDTO> rejectSponList(int cp,int ls) {
			
			int startnum=(cp-1)*ls+1;
			int endnum=cp*ls;
			
			Map<String, Integer> map=new HashMap<String, Integer>();
			map.put("startnum", startnum);
			map.put("endnum", endnum);
			
			List<SponDTO> list=sqlMap.selectList("rejectSponList", map);
			
			return list;
		}
		
		//관리자 페이지 - 진행 스폰 총 금액 확인하기
		public int startSponTotalPrice() {
			
			int startSponTotalPrice=sqlMap.selectOne("startSponTotalPrice");
			
			return startSponTotalPrice;
		}
		
		//관리자 페이지 - 종료 스폰 총 금액 확인하기
		public int finishSponTotalPrice() {
			
			int finishSponTotalPrice=sqlMap.selectOne("finishSponTotalPrice");
			
			return finishSponTotalPrice;
		}
		
		
		//관리자 페이지 - 스폰 내용보기
		public String sponInfo(int spon_idx) {
			
			String sponInfo=sqlMap.selectOne("sponInfo", spon_idx);
			
			return sponInfo;
		}
		
		//관리자 페이지 - 스폰 승인하기
		public int makeSponJoin(int spon_idx) {
			
			int count=sqlMap.update("makeSponJoin", spon_idx);
			
			return count;
		}
		
		//관리자 페이지 - 스폰 승인하면 게시글 스폰level도 바꾸기
		public int makeBbsJoin(int hairshop_idx) {
			
			int count=sqlMap.update("makeBbsJoin", hairshop_idx);
			
			return count;
		}
		
		//관리자 페이지 - 스폰 미 승인하기
		public int rejectSponJoin(int spon_idx) {
			
			int count=sqlMap.update("rejectSponJoin", spon_idx);
			
			return count;
		}
		
		//관리자 페이지 - 스폰 진행시키기
		public int makeSponStart(int spon_idx) {
			
			int count=sqlMap.update("makeSponStart", spon_idx);
			
			return count;
		}
		
		//관리자 페이지 - 스폰 취소시키기
		public int makeSponCancel(int spon_idx) {
			
			int count=sqlMap.update("makeSponCancel", spon_idx);
			
			return count;
		}
		
		//관리자 페이지 - 스폰 종료시키기
		public int makeSponFinish(int spon_idx) {
			
			int count=sqlMap.update("makeSponFinish", spon_idx);
			
			return count;
		}
	
	
	
	
	
	
	
	
}
