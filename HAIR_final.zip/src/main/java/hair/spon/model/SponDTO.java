package hair.spon.model;

import hair.hairshop.model.HairShopDTO;

public class SponDTO {

	private int spon_idx;
	private String spon_kind;
	private String spon_content;
	private int spon_price;
	private String spon_start;
	private String spon_finish;
	private int spon_state;
	private int hairshop_idx;
	
	private HairShopDTO hairshopDto; //조인
	
	public SponDTO() {
		super();
	}

	public SponDTO(int spon_idx, String spon_kind, String spon_content, int spon_price, String spon_start,
			String spon_finish, int spon_state, int hairshop_idx) {
		super();
		this.spon_idx = spon_idx;
		this.spon_kind = spon_kind;
		this.spon_content = spon_content;
		this.spon_price = spon_price;
		this.spon_start = spon_start;
		this.spon_finish = spon_finish;
		this.spon_state = spon_state;
		this.hairshop_idx = hairshop_idx;
	}

	public int getSpon_idx() {
		return spon_idx;
	}

	public void setSpon_idx(int spon_idx) {
		this.spon_idx = spon_idx;
	}

	public String getSpon_kind() {
		return spon_kind;
	}

	public void setSpon_kind(String spon_kind) {
		this.spon_kind = spon_kind;
	}

	public String getSpon_content() {
		return spon_content;
	}

	public void setSpon_content(String spon_content) {
		this.spon_content = spon_content;
	}

	public int getSpon_price() {
		return spon_price;
	}

	public void setSpon_price(int spon_price) {
		this.spon_price = spon_price;
	}

	public String getSpon_start() {
		return spon_start;
	}

	public void setSpon_start(String spon_start) {
		this.spon_start = spon_start;
	}

	public String getSpon_finish() {
		return spon_finish;
	}

	public void setSpon_finish(String spon_finish) {
		this.spon_finish = spon_finish;
	}

	public int getSpon_state() {
		return spon_state;
	}

	public void setSpon_state(int spon_state) {
		this.spon_state = spon_state;
	}

	public int getHairshop_idx() {
		return hairshop_idx;
	}

	public void setHairshop_idx(int hairshop_idx) {
		this.hairshop_idx = hairshop_idx;
	}

	public HairShopDTO getHairshopDto() {
		return hairshopDto;
	}

	public void setHairshopDto(HairShopDTO hairshopDto) {
		this.hairshopDto = hairshopDto;
	}
}
